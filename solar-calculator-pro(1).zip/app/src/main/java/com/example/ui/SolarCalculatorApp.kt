package com.example.ui

import androidx.compose.animation.*
import androidx.compose.ui.geometry.Offset
import com.example.ui.theme.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.Appliance
import com.example.data.Project
import com.example.network.GeocodingResult
import com.example.network.WeatherResponse
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.ceil
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarCalculatorApp(viewModel: SolarViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val appliances by viewModel.appliances.collectAsStateWithLifecycle()
    val weatherState by viewModel.weatherState.collectAsStateWithLifecycle()
    val citySearchResults by viewModel.citySearchResults.collectAsStateWithLifecycle()
    val citySearchLoading by viewModel.citySearchLoading.collectAsStateWithLifecycle()
    val savedProjects by viewModel.savedProjects.collectAsStateWithLifecycle()
    
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val currencySym by viewModel.currency.collectAsStateWithLifecycle()
    
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Sizing computation shortcuts (Reactively derived from activeProject & appliances)
    val totalRunningLoad = appliances.sumOf { it.powerWatts * it.quantity }
    val totalDailyEnergyWh = appliances.sumOf { it.powerWatts * it.quantity * it.hoursPerDay }
    val totalDailyEnergyKwh = totalDailyEnergyWh / 1000.0
    val monthlyConsumptionKwh = totalDailyEnergyKwh * 30.0
    val annualConsumptionKwh = totalDailyEnergyKwh * 365.0

    // Solar Panel computations
    val requiredSolarCapacityWatts = if (activeProject.peakSunHours > 0 && activeProject.systemEfficiency > 0) {
        totalDailyEnergyWh / (activeProject.peakSunHours * activeProject.systemEfficiency)
    } else 0.0
    val numPanels = ceil(requiredSolarCapacityWatts / activeProject.panelWattage).toInt()
    val finalSolarCapacityWatts = numPanels * activeProject.panelWattage
    val estimatedDailyProdWh = finalSolarCapacityWatts * activeProject.peakSunHours * activeProject.systemEfficiency
    val estimatedDailyProdKwh = estimatedDailyProdWh / 1000.0
    val estimatedMonthlyProdKwh = estimatedDailyProdKwh * 30.0
    val estimatedAnnualProdKwh = estimatedDailyProdKwh * 365.0

    // Battery Sizing
    val requiredBatteryBankEnergyWh = if (activeProject.depthOfDischarge > 0 && activeProject.batteryEfficiency > 0) {
        (totalDailyEnergyWh * activeProject.daysOfBackup) / (activeProject.depthOfDischarge * activeProject.batteryEfficiency)
    } else 0.0
    val requiredBatteryBankCapacityAh = requiredBatteryBankEnergyWh / activeProject.batteryVoltage
    val numBatteries = ceil(requiredBatteryBankCapacityAh / activeProject.batteryCapacityAh).toInt()
    val totalBatteryCapacityAh = numBatteries * activeProject.batteryCapacityAh
    val storedEnergyWh = totalBatteryCapacityAh * activeProject.batteryVoltage * activeProject.depthOfDischarge
    val storedEnergyKwh = storedEnergyWh / 1000.0

    // Inverter Sizing
    val continuousRating = totalRunningLoad
    val surgeRating = totalRunningLoad * 2.0
    val recommendedInverterSize = totalRunningLoad * activeProject.inverterSafetyMargin

    // Charge Controller
    val solarArrayCurrent = if (activeProject.systemVoltage > 0) finalSolarCapacityWatts / activeProject.systemVoltage else 0.0
    val requiredControllerCurrent = solarArrayCurrent * 1.25
    val recommendedMPPTCurrent = ceil(requiredControllerCurrent)
    val recommendedPWMCurrent = ceil(solarArrayCurrent * 1.3)

    // Cable Size
    val cableDropVolts = activeProject.systemVoltage * (activeProject.cableVoltageDropAllowed / 100.0)
    val requiredCableAreaSqMm = if (cableDropVolts > 0) {
        (2.0 * solarArrayCurrent * 0.0172 * activeProject.cableDistance) / cableDropVolts
    } else 0.0

    // Cost Estimator
    val panelCostSum = numPanels * activeProject.solarPanelPrice
    val batteryCostSum = numBatteries * activeProject.batteryPrice
    val equipmentCost = panelCostSum + batteryCostSum + activeProject.inverterPrice + 
            activeProject.chargeControllerPrice + activeProject.mountingPrice + activeProject.accessoriesPrice
    val totalCost = equipmentCost + activeProject.labourPrice
    val annualSavings = estimatedAnnualProdKwh * activeProject.electricityTariff
    val roi = if (totalCost > 0) (annualSavings / totalCost) * 100.0 else 0.0
    val paybackPeriodYears = if (annualSavings > 0) totalCost / annualSavings else 0.0

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = "Solar",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Solar Calculator Pro",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Smart Sizing & Cost Estimator",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    val navigationItems = listOf(
                        Triple(Screen.DASHBOARD, Icons.Default.Dashboard, "Dashboard Hub"),
                        Triple(Screen.LOAD_CALC, Icons.Default.Tv, "Load Calculator"),
                        Triple(Screen.SOLAR_CALC, Icons.Default.WbSunny, "Solar Panel Sizer"),
                        Triple(Screen.BATTERY_CALC, Icons.Default.BatteryChargingFull, "Battery Sizer"),
                        Triple(Screen.INVERTER_CALC, Icons.Default.Power, "Inverter Sizer"),
                        Triple(Screen.CONTROLLER_CALC, Icons.Default.SettingsInputComponent, "Charge Controller"),
                        Triple(Screen.CABLE_CALC, Icons.Default.Cable, "Cable Size Sizer"),
                        Triple(Screen.COST_ESTIMATOR, Icons.Default.AttachMoney, "Cost & ROI Estimator"),
                        Triple(Screen.WEATHER_DASHBOARD, Icons.Default.Cloud, "Weather Hub"),
                        Triple(Screen.REPORTS, Icons.Default.Description, "Project Reports"),
                        Triple(Screen.SAVED_PROJECTS, Icons.Default.Folder, "Saved Projects"),
                        Triple(Screen.SETTINGS, Icons.Default.Settings, "Settings"),
                        Triple(Screen.HELP, Icons.Default.Help, "Terminology & Formulas")
                    )
                    items(navigationItems) { (screen, icon, title) ->
                        NavigationDrawerItem(
                            icon = { Icon(imageVector = icon, contentDescription = title) },
                            label = { Text(text = title) },
                            selected = currentScreen == screen,
                            onClick = {
                                viewModel.navigateTo(screen)
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    ) {
        FrostedGlassBackground {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                text = when (currentScreen) {
                                    Screen.DASHBOARD -> "Solar Calculator Pro"
                                    Screen.LOAD_CALC -> "Load Estimation"
                                    Screen.SOLAR_CALC -> "Solar Panel Sizing"
                                    Screen.BATTERY_CALC -> "Battery Bank Sizing"
                                    Screen.INVERTER_CALC -> "Inverter Sizing"
                                    Screen.CONTROLLER_CALC -> "Charge Controller"
                                    Screen.CABLE_CALC -> "Cable Size Sizing"
                                    Screen.COST_ESTIMATOR -> "Cost & ROI Estimator"
                                    Screen.WEATHER_DASHBOARD -> "Weather Forecast & PSH"
                                    Screen.REPORTS -> "Project Summary Report"
                                    Screen.SAVED_PROJECTS -> "My Saved Projects"
                                    Screen.SETTINGS -> "Application Settings"
                                    Screen.HELP -> "Help & Solar Formula"
                                },
                                fontWeight = FontWeight.Bold
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu")
                            }
                        },
                        actions = {
                            IconButton(onClick = { viewModel.updateDarkMode(!isDark) }) {
                                Icon(
                                    imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Toggle Theme"
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)
                        )
                    )
                },
                bottomBar = {
                    if (currentScreen != Screen.DASHBOARD) {
                        BottomAppBar(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { viewModel.navigateTo(Screen.DASHBOARD) },
                                    modifier = Modifier.padding(start = 16.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Back Dashboard")
                                }
                                Button(
                                    onClick = {
                                        viewModel.saveProjectToDb()
                                    },
                                    modifier = Modifier.padding(end = 16.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Save, contentDescription = "Save")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Save Project")
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        Screen.DASHBOARD -> DashboardScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            totalDailyEnergyKwh = totalDailyEnergyKwh,
                            numPanels = numPanels,
                            numBatteries = numBatteries,
                            recommendedInverterSize = recommendedInverterSize,
                            totalCost = totalCost,
                            roi = roi,
                            currencySym = currencySym
                        )
                        Screen.LOAD_CALC -> LoadCalcScreen(
                            viewModel = viewModel,
                            appliances = appliances,
                            totalRunningLoad = totalRunningLoad,
                            totalDailyEnergyWh = totalDailyEnergyWh,
                            totalDailyEnergyKwh = totalDailyEnergyKwh,
                            monthlyConsumptionKwh = monthlyConsumptionKwh,
                            annualConsumptionKwh = annualConsumptionKwh
                        )
                        Screen.SOLAR_CALC -> SolarCalcScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            requiredSolarCapacityWatts = requiredSolarCapacityWatts,
                            numPanels = numPanels,
                            finalSolarCapacityWatts = finalSolarCapacityWatts,
                            estimatedDailyProdKwh = estimatedDailyProdKwh,
                            estimatedMonthlyProdKwh = estimatedMonthlyProdKwh,
                            estimatedAnnualProdKwh = estimatedAnnualProdKwh,
                            totalDailyEnergyKwh = totalDailyEnergyKwh
                        )
                        Screen.BATTERY_CALC -> BatteryCalcScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            requiredBatteryBankEnergyWh = requiredBatteryBankEnergyWh,
                            requiredBatteryBankCapacityAh = requiredBatteryBankCapacityAh,
                            numBatteries = numBatteries,
                            totalBatteryCapacityAh = totalBatteryCapacityAh,
                            storedEnergyKwh = storedEnergyKwh
                        )
                        Screen.INVERTER_CALC -> InverterCalcScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            continuousRating = continuousRating,
                            surgeRating = surgeRating,
                            recommendedInverterSize = recommendedInverterSize
                        )
                        Screen.CONTROLLER_CALC -> ControllerCalcScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            solarArrayCurrent = solarArrayCurrent,
                            requiredControllerCurrent = requiredControllerCurrent,
                            recommendedMPPTCurrent = recommendedMPPTCurrent,
                            recommendedPWMCurrent = recommendedPWMCurrent
                        )
                        Screen.CABLE_CALC -> CableCalcScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            solarArrayCurrent = solarArrayCurrent,
                            requiredCableAreaSqMm = requiredCableAreaSqMm
                        )
                        Screen.COST_ESTIMATOR -> CostEstimatorScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            numPanels = numPanels,
                            numBatteries = numBatteries,
                            panelCostSum = panelCostSum,
                            batteryCostSum = batteryCostSum,
                            equipmentCost = equipmentCost,
                            totalCost = totalCost,
                            annualSavings = annualSavings,
                            roi = roi,
                            paybackPeriodYears = paybackPeriodYears,
                            currencySym = currencySym
                        )
                        Screen.WEATHER_DASHBOARD -> WeatherScreen(
                            viewModel = viewModel,
                            weatherState = weatherState,
                            citySearchResults = citySearchResults,
                            citySearchLoading = citySearchLoading
                        )
                        Screen.REPORTS -> ReportsScreen(
                            viewModel = viewModel,
                            activeProject = activeProject,
                            appliances = appliances,
                            totalRunningLoad = totalRunningLoad,
                            totalDailyEnergyWh = totalDailyEnergyWh,
                            numPanels = numPanels,
                            numBatteries = numBatteries,
                            recommendedInverterSize = recommendedInverterSize,
                            recommendedMPPTCurrent = recommendedMPPTCurrent,
                            requiredCableAreaSqMm = requiredCableAreaSqMm,
                            totalCost = totalCost,
                            annualSavings = annualSavings,
                            roi = roi,
                            paybackPeriodYears = paybackPeriodYears,
                            currencySym = currencySym
                        )
                        Screen.SAVED_PROJECTS -> SavedProjectsScreen(
                            viewModel = viewModel,
                            savedProjects = savedProjects,
                            currencySym = currencySym
                        )
                        Screen.SETTINGS -> SettingsScreen(
                            viewModel = viewModel
                        )
                        Screen.HELP -> HelpScreen()
                    }
                }
            }
        }
    }
}
}

// ------------------------------------
// COMMON DESIGN SUB-COMPONENTS
// ------------------------------------

@Composable
fun FrostedGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    
    // Ambient backdrops representing the emerald and lavender/blue blobs
    val blob1Color = if (isDark) Color(0x1810B981) else Color(0x2210B981)
    val blob2Color = if (isDark) Color(0x183B82F6) else Color(0x223B82F6)
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Top Left Blob
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(blob1Color, Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.15f),
                    radius = size.width * 0.65f
                )
            )
            // Bottom Right Blob
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(blob2Color, Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.85f),
                    radius = size.width * 0.65f
                )
            )
        }
        
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(24.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val borderColor = if (isDark) Color(0x1BFFFFFF) else Color(0x3B000000)
    val glassBgColor = if (isDark) Color(0x441E293B) else Color(0xAAFFFFFF)
    
    Card(
        modifier = modifier,
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = glassBgColor
        ),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
fun SimpleInputSlider(
    label: String,
    value: Double,
    range: ClosedFloatingPointRange<Double>,
    unit: String,
    steps: Int = 0,
    onValueChange: (Double) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(text = "${String.format(Locale.US, "%.1f", value)} $unit", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toDouble()) },
            valueRange = range.start.toFloat()..range.endInclusive.toFloat(),
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

// ------------------------------------
// SCREEN 1: DASHBOARD
// ------------------------------------
@Composable
fun DashboardScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    totalDailyEnergyKwh: Double,
    numPanels: Int,
    numBatteries: Int,
    recommendedInverterSize: Double,
    totalCost: Double,
    roi: Double,
    currencySym: String
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(20.dp)
    ) {
        // Active project header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Current Design Plan",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeProject.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Button(
                onClick = { viewModel.resetActiveProject() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "New", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Project", style = MaterialTheme.typography.labelMedium)
            }
        }

        // Frosted Glass Premium Solar Prediction Hero Card
        val finalSolarCapacityWatts = numPanels * activeProject.panelWattage
        val estimatedDailyProdWh = finalSolarCapacityWatts * activeProject.peakSunHours * activeProject.systemEfficiency
        val estimatedDailyProdKwh = estimatedDailyProdWh / 1000.0
        val predictedKwh = if (estimatedDailyProdKwh > 0) estimatedDailyProdKwh else 5.24
        val peakSunHoursText = if (activeProject.peakSunHours > 0) "${activeProject.peakSunHours}h Today" else "6.4h Today"
        val uvIndexText = when {
            activeProject.peakSunHours >= 6.0 -> "High (7)"
            activeProject.peakSunHours >= 4.5 -> "Moderate (5)"
            else -> "Low (3)"
        }
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(SolarGradientStart, SolarGradientEnd)
                        )
                    )
                    .padding(24.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "Predicted Production",
                                color = Color.White.copy(alpha = 0.9f),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = String.format(Locale.US, "%.2f", predictedKwh),
                                    color = Color.White,
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Black
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "kWh",
                                    color = Color.White.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.titleLarge,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                            }
                        }
                        
                        // Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.2f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "OPTIMAL DAY",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = Color.White.copy(alpha = 0.2f), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Peak Sun Hours",
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = peakSunHoursText,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "UV Index",
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = uvIndexText,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Quick metrics grid
        Text(
            text = "Key System Metrics",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassCard(
                modifier = Modifier.weight(1f).aspectRatio(1f),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.WbSunny, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Solar Panel", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("$numPanels Units", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Text("${numPanels * activeProject.panelWattage.toInt()}W Max", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                }
            }
            
            GlassCard(
                modifier = Modifier.weight(1f).aspectRatio(1f),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.BatteryChargingFull, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Battery", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("$numBatteries Cells", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Text("${activeProject.batteryVoltage.toInt()}V / ${numBatteries * activeProject.batteryCapacityAh.toInt()}Ah", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                }
            }
            
            GlassCard(
                modifier = Modifier.weight(1f).aspectRatio(1f),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Power, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Inverter", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("${recommendedInverterSize.toInt()} W", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Text("Sized Safe", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassCard(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Daily Load Demand", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${String.format(Locale.US, "%.2f", totalDailyEnergyKwh)} kWh", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                }
            }
            GlassCard(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Est. System Cost", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$currencySym${String.format(Locale.US, "%.0f", totalCost)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Feature tools list
        Text(
            text = "Solar Calculator Tools",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)
        )

        val tools = listOf(
            Triple(Screen.LOAD_CALC, Icons.Default.Tv, "Load Calculator"),
            Triple(Screen.SOLAR_CALC, Icons.Default.WbSunny, "Solar Panel Sizer"),
            Triple(Screen.BATTERY_CALC, Icons.Default.BatteryChargingFull, "Battery Calculator"),
            Triple(Screen.INVERTER_CALC, Icons.Default.Power, "Inverter Recommender"),
            Triple(Screen.CONTROLLER_CALC, Icons.Default.SettingsInputComponent, "Charge Controller Sizer"),
            Triple(Screen.CABLE_CALC, Icons.Default.Cable, "Cable Cross-Section Sizer"),
            Triple(Screen.COST_ESTIMATOR, Icons.Default.AttachMoney, "Cost & ROI Analyzer"),
            Triple(Screen.WEATHER_DASHBOARD, Icons.Default.Cloud, "Weather Prediction"),
            Triple(Screen.SAVED_PROJECTS, Icons.Default.Folder, "Saved Designs"),
            Triple(Screen.REPORTS, Icons.Default.Description, "Export Report & Share"),
            Triple(Screen.SETTINGS, Icons.Default.Settings, "Application Settings"),
            Triple(Screen.HELP, Icons.Default.Help, "Terminology & Help Guide")
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            tools.chunked(2).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { (screen, icon, name) ->
                        GlassCard(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.navigateTo(screen) },
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = name,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                    if (pair.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// ------------------------------------
// SCREEN 2: LOAD CALCULATOR
// ------------------------------------
@Composable
fun LoadCalcScreen(
    viewModel: SolarViewModel,
    appliances: List<Appliance>,
    totalRunningLoad: Double,
    totalDailyEnergyWh: Double,
    totalDailyEnergyKwh: Double,
    monthlyConsumptionKwh: Double,
    annualConsumptionKwh: Double
) {
    var appName by remember { mutableStateOf("") }
    var qtyString by remember { mutableStateOf("1") }
    var wattsString by remember { mutableStateOf("100") }
    var hoursString by remember { mutableStateOf("4") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Load Summary",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Running Load", style = MaterialTheme.typography.bodySmall)
                        Text("${totalRunningLoad.toInt()} W", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Daily Energy", style = MaterialTheme.typography.bodySmall)
                        Text("${String.format(Locale.US, "%.2f", totalDailyEnergyKwh)} kWh", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Monthly Consumption:", style = MaterialTheme.typography.bodySmall)
                    Text("${monthlyConsumptionKwh.toInt()} kWh", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Annual Consumption:", style = MaterialTheme.typography.bodySmall)
                    Text("${annualConsumptionKwh.toInt()} kWh", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preset Quick Add
        Text(
            text = "Appliance Quick Presets",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val presets = listOf(
                PresetAppliance("LED Bulb", 1, 10.0, 6.0),
                PresetAppliance("Ceiling Fan", 1, 75.0, 10.0),
                PresetAppliance("Refrigerator", 1, 150.0, 24.0),
                PresetAppliance("Air Conditioner", 1, 1200.0, 5.0),
                PresetAppliance("Led TV", 1, 100.0, 4.0),
                PresetAppliance("Laptop", 1, 65.0, 6.0)
            )
            presets.forEach { preset ->
                Button(
                    onClick = {
                        appName = preset.name
                        qtyString = preset.qty.toString()
                        wattsString = preset.watts.toString()
                        hoursString = preset.hours.toString()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                ) {
                    Text(preset.name)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Add form
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Add/Edit Appliance",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("Appliance Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyString,
                        onValueChange = { qtyString = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = wattsString,
                        onValueChange = { wattsString = it },
                        label = { Text("Power (Watts)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = hoursString,
                    onValueChange = { hoursString = it },
                    label = { Text("Hours per Day") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val q = qtyString.toIntOrNull() ?: 1
                        val w = wattsString.toDoubleOrNull() ?: 100.0
                        val h = hoursString.toDoubleOrNull() ?: 4.0
                        if (appName.isNotEmpty()) {
                            viewModel.addAppliance(appName, q, w, h)
                            // reset inputs
                            appName = ""
                            qtyString = "1"
                            wattsString = "100"
                            hoursString = "4"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Appliance to Design")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Added appliances list
        Text(
            text = "Appliances in System",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (appliances.isEmpty()) {
            Text(
                text = "No appliances added. Add LED bulbs or fans above to start load calculations.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.padding(vertical = 12.dp)
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                appliances.forEach { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = app.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Qty: ${app.quantity}  |  ${app.powerWatts.toInt()} W  |  ${app.hoursPerDay} Hrs/day",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                val dailyEnergy = app.quantity * app.powerWatts * app.hoursPerDay
                                Text(
                                    text = "Daily Energy: ${dailyEnergy.toInt()} Wh",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            IconButton(onClick = { viewModel.deleteAppliance(app.id) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class PresetAppliance(val name: String, val qty: Int, val watts: Double, val hours: Double)

// ------------------------------------
// SCREEN 3: SOLAR PANEL CALCULATOR
// ------------------------------------
@Composable
fun SolarCalcScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    requiredSolarCapacityWatts: Double,
    numPanels: Int,
    finalSolarCapacityWatts: Double,
    estimatedDailyProdKwh: Double,
    estimatedMonthlyProdKwh: Double,
    estimatedAnnualProdKwh: Double,
    totalDailyEnergyKwh: Double
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Warning if running load is 0
        if (requiredSolarCapacityWatts == 0.0) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = "Warning", tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Your daily load is 0 Wh. Go to 'Load Calculator' to add appliances first!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Required Solar Array Size", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${String.format(Locale.US, "%.1f", requiredSolarCapacityWatts)} Watts",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Recommended: $numPanels Panels of ${activeProject.panelWattage.toInt()}W (${finalSolarCapacityWatts.toInt()}W total)",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Open-Meteo Integration State
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (activeProject.weatherCity.isNotEmpty()) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (activeProject.weatherCity.isNotEmpty()) Icons.Default.CloudQueue else Icons.Default.LocationOff,
                        contentDescription = "Weather",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Peak Sun Hours (PSH) Source",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (activeProject.weatherCity.isNotEmpty()) {
                    Text(
                        text = "Currently using GPS/Geocoded Sun Hours for: ${activeProject.weatherCity}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Shortwave Insolation sum: ${String.format(Locale.US, "%.1f", activeProject.weatherSolarRadiation)} MJ/m² (${String.format(Locale.US, "%.2f", activeProject.weatherPSH)} PSH)",
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    Text(
                        text = "Manual Mode. Go to the 'Weather Hub' tab to pull your exact coordinates' sun values automatically!",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.navigateTo(Screen.WEATHER_DASHBOARD) },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(imageVector = Icons.Default.Cloud, contentDescription = "Weather")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Go Weather Hub")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Manual controls
        Text("Configure Panel Specifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        
        SimpleInputSlider(
            label = "Default Panel Wattage",
            value = activeProject.panelWattage,
            range = 100.0..600.0,
            unit = "W",
            steps = 9
        ) {
            viewModel.updateSolarParams(it, activeProject.systemVoltage, activeProject.systemEfficiency, activeProject.peakSunHours)
        }

        SimpleInputSlider(
            label = "Peak Sun Hours (PSH)",
            value = activeProject.peakSunHours,
            range = 1.0..10.0,
            unit = "Hrs",
            steps = 18
        ) {
            viewModel.updateSolarParams(activeProject.panelWattage, activeProject.systemVoltage, activeProject.systemEfficiency, it)
        }

        SimpleInputSlider(
            label = "System Efficiency Correction",
            value = activeProject.systemEfficiency,
            range = 0.5..1.0,
            unit = "%",
            steps = 10
        ) {
            viewModel.updateSolarParams(activeProject.panelWattage, activeProject.systemVoltage, it, activeProject.peakSunHours)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Production Estimates
        Text("Estimated Sizing Production", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        
        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Daily Solar Yield", style = MaterialTheme.typography.bodySmall)
                Text("${String.format(Locale.US, "%.2f", estimatedDailyProdKwh)} kWh / day", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = if (totalDailyEnergyKwh > 0) (estimatedDailyProdKwh / totalDailyEnergyKwh).toFloat().coerceIn(0f, 1f) else 0f,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )
                Text(
                    text = "Covers ${String.format(Locale.US, "%.1f", if (totalDailyEnergyKwh > 0) (estimatedDailyProdKwh / totalDailyEnergyKwh) * 100.0 else 0.0)}% of your daily appliance load.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Monthly Production Yield", style = MaterialTheme.typography.bodySmall)
                Text("${String.format(Locale.US, "%.0f", estimatedMonthlyProdKwh)} kWh / month", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }

        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Annual Production Yield", style = MaterialTheme.typography.bodySmall)
                Text("${String.format(Locale.US, "%.0f", estimatedAnnualProdKwh)} kWh / year", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------
// SCREEN 4: BATTERY CALCULATOR
// ------------------------------------
@Composable
fun BatteryCalcScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    requiredBatteryBankEnergyWh: Double,
    requiredBatteryBankCapacityAh: Double,
    numBatteries: Int,
    totalBatteryCapacityAh: Double,
    storedEnergyKwh: Double
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Required Battery Bank Capacity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${requiredBatteryBankCapacityAh.toInt()} Ah",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "For ${activeProject.daysOfBackup.toInt()} Days of Backup at ${activeProject.batteryVoltage.toInt()}V.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Battery Specifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        SimpleInputSlider(
            label = "Battery Rated Voltage",
            value = activeProject.batteryVoltage,
            range = 12.0..48.0,
            unit = "V",
            steps = 3
        ) {
            viewModel.updateBatteryParams(it, activeProject.batteryCapacityAh, activeProject.daysOfBackup, activeProject.depthOfDischarge, activeProject.batteryEfficiency)
        }

        SimpleInputSlider(
            label = "Single Battery Capacity",
            value = activeProject.batteryCapacityAh,
            range = 50.0..300.0,
            unit = "Ah",
            steps = 5
        ) {
            viewModel.updateBatteryParams(activeProject.batteryVoltage, it, activeProject.daysOfBackup, activeProject.depthOfDischarge, activeProject.batteryEfficiency)
        }

        SimpleInputSlider(
            label = "Days of Autonomy (Backup)",
            value = activeProject.daysOfBackup,
            range = 1.0..5.0,
            unit = "Days",
            steps = 4
        ) {
            viewModel.updateBatteryParams(activeProject.batteryVoltage, activeProject.batteryCapacityAh, it, activeProject.depthOfDischarge, activeProject.batteryEfficiency)
        }

        SimpleInputSlider(
            label = "Depth of Discharge (DoD)",
            value = activeProject.depthOfDischarge,
            range = 0.2..0.8,
            unit = "",
            steps = 6
        ) {
            viewModel.updateBatteryParams(activeProject.batteryVoltage, activeProject.batteryCapacityAh, activeProject.daysOfBackup, it, activeProject.batteryEfficiency)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Battery Sizing Sizing Report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        MetricCard(
            title = "Cells Required",
            value = "$numBatteries Batteries",
            subtitle = "Connection recommended to match ${activeProject.batteryVoltage.toInt()}V bank",
            icon = Icons.Default.BatteryChargingFull,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        MetricCard(
            title = "Total Battery capacity",
            value = "$totalBatteryCapacityAh Ah",
            subtitle = "Sufficient for specified backup autonomy",
            icon = Icons.Default.Bolt,
            color = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(8.dp))

        MetricCard(
            title = "Stored Usable Energy",
            value = "${String.format(Locale.US, "%.2f", storedEnergyKwh)} kWh",
            subtitle = "Energy usable after DoD limits",
            icon = Icons.Default.OfflineBolt,
            color = MaterialTheme.colorScheme.tertiary
        )
    }
}

// ------------------------------------
// SCREEN 5: INVERTER CALCULATOR
// ------------------------------------
@Composable
fun InverterCalcScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    continuousRating: Double,
    surgeRating: Double,
    recommendedInverterSize: Double
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Recommended Inverter Size", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${recommendedInverterSize.toInt()} Watts",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Includes safety multiplier factor of ${activeProject.inverterSafetyMargin}x.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Configure Inverter Buffer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        SimpleInputSlider(
            label = "Safety Buffer Margin",
            value = activeProject.inverterSafetyMargin,
            range = 1.1..2.0,
            unit = "x",
            steps = 9
        ) {
            viewModel.updateInverterParams(it)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Inverter Sizing Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        MetricCard(
            title = "Continuous Running load",
            value = "${continuousRating.toInt()} W",
            subtitle = "Maximum simultaneous power draw",
            icon = Icons.Default.Power,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        MetricCard(
            title = "Required Surge Rating (Surge)",
            value = "${surgeRating.toInt()} W",
            subtitle = "Temporary current surge (motor startup)",
            icon = Icons.Default.FlashOn,
            color = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Inverter Sizing Pro-Tip", fontWeight = FontWeight.Bold)
                Text(
                    "We always size the inverter slightly larger than your peak continuous load. For inductive loads with high starting current (refrigerators, pumps), choose a pure sine wave inverter with high temporary peak surge capability.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ------------------------------------
// SCREEN 6: CHARGE CONTROLLER CALCULATOR
// ------------------------------------
@Composable
fun ControllerCalcScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    solarArrayCurrent: Double,
    requiredControllerCurrent: Double,
    recommendedMPPTCurrent: Double,
    recommendedPWMCurrent: Double
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Required MPPT Controller Current", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${recommendedMPPTCurrent.toInt()} Amps",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sized using continuous array current + 25% NEC safety margins.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Charge Controller Comparison", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(modifier = Modifier.weight(1.5f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("MPPT Controller (Recommended)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${recommendedMPPTCurrent.toInt()} A", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Up to 30% more efficient. Maximizes panel output voltage mismatch.", style = MaterialTheme.typography.bodyExtraSmall)
                }
            }
            Card(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("PWM Controller (Budget)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${recommendedPWMCurrent.toInt()} A", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Lower cost. Best only when panel voltage matches battery voltage.", style = MaterialTheme.typography.bodyExtraSmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Controller Sizing Metrics", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        MetricCard(
            title = "Continuous Array Current",
            value = "${String.format(Locale.US, "%.1f", solarArrayCurrent)} A",
            subtitle = "Under standard test irradiance conditions",
            icon = Icons.Default.SettingsInputComponent,
            color = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(8.dp))

        MetricCard(
            title = "Required Rating with Buffer",
            value = "${String.format(Locale.US, "%.1f", requiredControllerCurrent)} A",
            subtitle = "1.25x NEC safety multiplier margin",
            icon = Icons.Default.Shield,
            color = MaterialTheme.colorScheme.tertiary
        )
    }
}

// ------------------------------------
// SCREEN 7: CABLE SIZE CALCULATOR
// ------------------------------------
@Composable
fun CableCalcScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    solarArrayCurrent: Double,
    requiredCableAreaSqMm: Double
) {
    val scrollState = rememberScrollState()
    
    // Choose closest standard copper cable size
    val standardSizes = listOf(1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0)
    val recommendedSize = standardSizes.firstOrNull { it >= requiredCableAreaSqMm } ?: 50.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Recommended Copper Cable Area", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$recommendedSize mm²",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Theoretical minimal area: ${String.format(Locale.US, "%.2f", requiredCableAreaSqMm)} mm².",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Cable Configuration Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        SimpleInputSlider(
            label = "Cable Distance (One-way run)",
            value = activeProject.cableDistance,
            range = 1.0..100.0,
            unit = "Meters",
            steps = 99
        ) {
            viewModel.updateCableParams(it, activeProject.cableVoltageDropAllowed)
        }

        SimpleInputSlider(
            label = "Max Allowed Voltage Drop",
            value = activeProject.cableVoltageDropAllowed,
            range = 1.0..5.0,
            unit = "%",
            steps = 4
        ) {
            viewModel.updateCableParams(activeProject.cableDistance, it)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Cable Electrical Sizing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        MetricCard(
            title = "Continuous DC Current",
            value = "${String.format(Locale.US, "%.1f", solarArrayCurrent)} Amps",
            subtitle = "Continuous panel array feed output",
            icon = Icons.Default.ElectricBolt,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        MetricCard(
            title = "Voltage Drop Limit Threshold",
            value = "${String.format(Locale.US, "%.2f", (activeProject.systemVoltage * activeProject.cableVoltageDropAllowed / 100.0))} V",
            subtitle = "Calculated threshold at ${activeProject.systemVoltage.toInt()}V (${activeProject.cableVoltageDropAllowed.toInt()}%)",
            icon = Icons.Default.TrendingDown,
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

// ------------------------------------
// SCREEN 8: COST ESTIMATOR & ROI
// ------------------------------------
@Composable
fun CostEstimatorScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    numPanels: Int,
    numBatteries: Int,
    panelCostSum: Double,
    batteryCostSum: Double,
    equipmentCost: Double,
    totalCost: Double,
    annualSavings: Double,
    roi: Double,
    paybackPeriodYears: Double,
    currencySym: String
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Total Sizing Estimated Cost", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$currencySym${String.format(Locale.US, "%.0f", totalCost)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Equipment: $currencySym${String.format(Locale.US, "%.0f", equipmentCost)} | Labour: $currencySym${String.format(Locale.US, "%.0f", activeProject.labourPrice)}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Financial Feasibility Analysis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Return on Investment (ROI)", style = MaterialTheme.typography.bodyExtraSmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${String.format(Locale.US, "%.1f", roi)}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            Card(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Payback Period", style = MaterialTheme.typography.bodyExtraSmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${String.format(Locale.US, "%.1f", paybackPeriodYears)} Years", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Configure Equipment Prices", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        SimpleInputSlider(
            label = "Solar Panel Unit Price",
            value = activeProject.solarPanelPrice,
            range = 50.0..500.0,
            unit = currencySym,
            steps = 45
        ) {
            viewModel.updateCostParams(it, activeProject.batteryPrice, activeProject.inverterPrice, activeProject.chargeControllerPrice, activeProject.mountingPrice, activeProject.accessoriesPrice, activeProject.labourPrice, activeProject.electricityTariff)
        }

        SimpleInputSlider(
            label = "Battery Cell Unit Price",
            value = activeProject.batteryPrice,
            range = 50.0..800.0,
            unit = currencySym,
            steps = 75
        ) {
            viewModel.updateCostParams(activeProject.solarPanelPrice, it, activeProject.inverterPrice, activeProject.chargeControllerPrice, activeProject.mountingPrice, activeProject.accessoriesPrice, activeProject.labourPrice, activeProject.electricityTariff)
        }

        SimpleInputSlider(
            label = "Inverter Device Price",
            value = activeProject.inverterPrice,
            range = 100.0..2000.0,
            unit = currencySym,
            steps = 190
        ) {
            viewModel.updateCostParams(activeProject.solarPanelPrice, activeProject.batteryPrice, it, activeProject.chargeControllerPrice, activeProject.mountingPrice, activeProject.accessoriesPrice, activeProject.labourPrice, activeProject.electricityTariff)
        }

        SimpleInputSlider(
            label = "Installation/Labour Fee",
            value = activeProject.labourPrice,
            range = 50.0..1500.0,
            unit = currencySym,
            steps = 145
        ) {
            viewModel.updateCostParams(activeProject.solarPanelPrice, activeProject.batteryPrice, activeProject.inverterPrice, activeProject.chargeControllerPrice, activeProject.mountingPrice, activeProject.accessoriesPrice, it, activeProject.electricityTariff)
        }

        SimpleInputSlider(
            label = "Grid Electricity Tariff Price",
            value = activeProject.electricityTariff,
            range = 0.05..0.6,
            unit = "$currencySym/kWh",
            steps = 55
        ) {
            viewModel.updateCostParams(activeProject.solarPanelPrice, activeProject.batteryPrice, activeProject.inverterPrice, activeProject.chargeControllerPrice, activeProject.mountingPrice, activeProject.accessoriesPrice, activeProject.labourPrice, it)
        }
    }
}

// ------------------------------------
// SCREEN 9: WEATHER & prediction
// ------------------------------------
@Composable
fun WeatherScreen(
    viewModel: SolarViewModel,
    weatherState: WeatherState,
    citySearchResults: List<GeocodingResult>,
    citySearchLoading: Boolean
) {
    var searchQuery by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // City search box
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Open-Meteo City Weather Sizer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search City...") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { viewModel.searchCities(searchQuery) }) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                    }
                }
                
                if (citySearchLoading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
                }

                if (citySearchResults.isNotEmpty()) {
                    Text("Select City:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                    Column {
                        citySearchResults.forEach { city ->
                            TextButton(
                                onClick = {
                                    viewModel.fetchWeather(city.latitude, city.longitude, city.name)
                                    searchQuery = ""
                                    viewModel.searchCities("")
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("${city.name}, ${city.country ?: ""}", textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Weather Status
        when (weatherState) {
            is WeatherState.Idle -> {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Search and choose a city above to download real-time local Peak Sun Hours.")
                    }
                }
            }
            is WeatherState.Loading -> {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is WeatherState.Error -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Weather Sizing Error", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        Text(weatherState.message, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
            is WeatherState.Success -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = weatherState.city, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (weatherState.isCached) "Using Cache" else "Live Online",
                                    style = MaterialTheme.typography.bodyExtraSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Temperature", style = MaterialTheme.typography.bodySmall)
                                Text("${weatherState.temp}°C", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Estimated Sun Hours", style = MaterialTheme.typography.bodySmall)
                                Text("${String.format(Locale.US, "%.2f", weatherState.psh)} Hrs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Cloud Cover Ratio:", style = MaterialTheme.typography.bodySmall)
                            Text("${weatherState.cloudCover.toInt()}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Shortwave Insolation sum:", style = MaterialTheme.typography.bodySmall)
                            Text("${String.format(Locale.US, "%.1f", weatherState.solarRadiation)} MJ/m²", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Wind speed:", style = MaterialTheme.typography.bodySmall)
                            Text("${weatherState.windSpeed} km/h", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Cloud-cover based predictions
                Text("Weather-Based Solar Prediction", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                
                val cover = weatherState.cloudCover
                val factor = when {
                    cover <= 20 -> 1.0
                    cover <= 40 -> 0.95
                    cover <= 60 -> 0.85
                    cover <= 80 -> 0.70
                    else -> 0.50
                }

                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.CloudQueue, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Real-time Production Sizing Impact", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Cloud Cover is ${cover.toInt()}%. Output correction factor matches: ${(factor * 100).toInt()}% output yield.")
                        
                        LinearProgressIndicator(
                            progress = factor.toFloat(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------
// SCREEN 10: PROJECT REPORTS
// ------------------------------------
@Composable
fun ReportsScreen(
    viewModel: SolarViewModel,
    activeProject: Project,
    appliances: List<Appliance>,
    totalRunningLoad: Double,
    totalDailyEnergyWh: Double,
    numPanels: Int,
    numBatteries: Int,
    recommendedInverterSize: Double,
    recommendedMPPTCurrent: Double,
    requiredCableAreaSqMm: Double,
    totalCost: Double,
    annualSavings: Double,
    roi: Double,
    paybackPeriodYears: Double,
    currencySym: String
) {
    var custName by remember { mutableStateOf(activeProject.customerName) }
    var custEmail by remember { mutableStateOf(activeProject.customerEmail) }
    var notes by remember { mutableStateOf(activeProject.notes) }

    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Customer & Site Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = custName,
                    onValueChange = { custName = it },
                    label = { Text("Customer Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = custEmail,
                    onValueChange = { custEmail = it },
                    label = { Text("Customer Contact Info") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Site / Project Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.updateCustomerDetails(custName, custEmail, notes)
                        viewModel.saveProjectToDb()
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Apply Details")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Printable report sheet
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SOLAR CALCULATOR PRO - REPORT",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(activeProject.updatedAt)),
                    style = MaterialTheme.typography.bodyExtraSmall,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Divider(modifier = Modifier.padding(vertical = 12.dp))

                Text("Client: ${custName.ifEmpty { "N/A" }}", fontWeight = FontWeight.Bold)
                Text("Contact: ${custEmail.ifEmpty { "N/A" }}")
                Text("Notes: ${notes.ifEmpty { "N/A" }}")

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                Text("System Sizing Summary", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("- Connected running load: ${totalRunningLoad.toInt()} W")
                Text("- Daily energy demand: ${String.format(Locale.US, "%.1f", totalDailyEnergyWh / 1000.0)} kWh")
                Text("- Recommended panels count: $numPanels x ${activeProject.panelWattage.toInt()}W (${numPanels * activeProject.panelWattage.toInt()}W array)")
                Text("- Battery capacity cells: $numBatteries x ${activeProject.batteryCapacityAh.toInt()}Ah (${activeProject.batteryVoltage.toInt()}V Bank)")
                Text("- MPPT controller recommendation: ${recommendedMPPTCurrent.toInt()} Amps")
                Text("- Inverter recommended capacity: ${recommendedInverterSize.toInt()} W")
                Text("- Required minimal copper cable cross area: ${String.format(Locale.US, "%.2f", requiredCableAreaSqMm)} mm²")

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                Text("Financial feasibility Analysis", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                Text("- Total sizing cost: $currencySym${String.format(Locale.US, "%.0f", totalCost)}")
                Text("- Year 1 estimated savings: $currencySym${String.format(Locale.US, "%.0f", annualSavings)}")
                Text("- payback years: ${String.format(Locale.US, "%.1f", paybackPeriodYears)} Years")
                Text("- Estimated internal ROI: ${String.format(Locale.US, "%.1f", roi)}%")

                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = {
                        val reportText = """
                            SOLAR CALCULATOR PRO - SIZING REPORT
                            Generated: ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}
                            
                            CLIENT DETAILS
                            Name: ${custName.ifEmpty { "N/A" }}
                            Contact: ${custEmail.ifEmpty { "N/A" }}
                            
                            SYSTEM RECOMMENDATIONS
                            - Daily Appliance demand: ${String.format(Locale.US, "%.2f", totalDailyEnergyWh / 1000.0)} kWh/day
                            - Recommended Solar array: $numPanels x ${activeProject.panelWattage.toInt()}W
                            - Recommended Battery: $numBatteries x ${activeProject.batteryCapacityAh.toInt()}Ah
                            - Recommended Inverter: ${recommendedInverterSize.toInt()} W
                            - Recommended Copper cable size: ${String.format(Locale.US, "%.2f", requiredCableAreaSqMm)} mm²
                            
                            FINANCIAL ANALYSIS
                            - Grand Sizing Total: $currencySym${String.format(Locale.US, "%.0f", totalCost)}
                            - Estimated Annual Savings: $currencySym${String.format(Locale.US, "%.0f", annualSavings)}
                            - payback Period: ${String.format(Locale.US, "%.1f", paybackPeriodYears)} Years
                            - Est ROI: ${String.format(Locale.US, "%.1f", roi)}%
                        """.trimIndent()
                        
                        val intent = android.content.Intent().apply {
                            action = android.content.Intent.ACTION_SEND
                            putExtra(android.content.Intent.EXTRA_TEXT, reportText)
                            type = "text/plain"
                        }
                        context.startActivity(android.content.Intent.createChooser(intent, "Share Solar Report via"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share/Export Report Text")
                }
            }
        }
    }
}

// ------------------------------------
// SCREEN 11: SAVED PROJECTS
// ------------------------------------
@Composable
fun SavedProjectsScreen(
    viewModel: SolarViewModel,
    savedProjects: List<Project>,
    currencySym: String
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredProjects = savedProjects.filter { it.name.contains(searchQuery, ignoreCase = true) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search saved project name...") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredProjects.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matching saved projects found.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredProjects) { project ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(project.updatedAt)),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Row {
                                    IconButton(onClick = { viewModel.loadProject(project) }) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { viewModel.duplicateProject(project) }) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = MaterialTheme.colorScheme.secondary)
                                    }
                                    IconButton(onClick = { viewModel.deleteProject(project) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------
// SCREEN 12: SETTINGS
// ------------------------------------
@Composable
fun SettingsScreen(viewModel: SolarViewModel) {
    val context = LocalContext.current
    var sysVolt by remember { mutableStateOf(viewModel.defaultSystemVoltage.value.toString()) }
    var panelWatt by remember { mutableStateOf(viewModel.defaultPanelWattage.value.toString()) }
    var battVolt by remember { mutableStateOf(viewModel.defaultBatteryVoltage.value.toString()) }
    var safetyMargin by remember { mutableStateOf(viewModel.defaultSafetyMargin.value.toString()) }
    
    var currency by remember { mutableStateOf(viewModel.currency.value) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Customize Global Sizing Defaults", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = sysVolt,
            onValueChange = { sysVolt = it },
            label = { Text("Default System Voltage (V)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = panelWatt,
            onValueChange = { panelWatt = it },
            label = { Text("Default Panel Wattage (W)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = battVolt,
            onValueChange = { battVolt = it },
            label = { Text("Default Battery Voltage (V)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = safetyMargin,
            onValueChange = { safetyMargin = it },
            label = { Text("Default Safety multiplier margin (x)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text("Display Preferences", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("$", "€", "£", "₹", "¥").forEach { sym ->
                FilterChip(
                    selected = currency == sym,
                    onClick = { currency = sym },
                    label = { Text(sym) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val sysV = sysVolt.toDoubleOrNull() ?: 24.0
                val pW = panelWatt.toDoubleOrNull() ?: 400.0
                val bV = battVolt.toDoubleOrNull() ?: 12.0
                val margin = safetyMargin.toDoubleOrNull() ?: 1.25
                viewModel.updateDefaults(sysV, pW, bV, margin)
                viewModel.updateCurrency(currency)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save Preference Defaults")
        }
    }
}

// ------------------------------------
// SCREEN 13: HELP & TERMINOLOGY
// ------------------------------------
@Composable
fun HelpScreen() {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text("Solar Terminology", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("• PSH (Peak Sun Hours):", fontWeight = FontWeight.Bold)
        Text("The number of hours per day when solar irradiance averages 1,000 W/m². Solar prediction yields are numerically equal to kWh/m²/day of sun exposure.")
        Spacer(modifier = Modifier.height(6.dp))
        Text("• DoD (Depth of Discharge):", fontWeight = FontWeight.Bold)
        Text("The percentage of battery capacity that can be safely discharged. Lead-Acid typically handles 50% DoD, while Lithium-Ion supports up to 80% DoD safely.")
        Spacer(modifier = Modifier.height(6.dp))
        Text("• MPPT vs PWM Controllers:", fontWeight = FontWeight.Bold)
        Text("MPPT (Maximum Power Point Tracking) extracts up to 30% more power from solar arrays by dynamically matching voltage difference. PWM is a simpler budget switch.")

        Spacer(modifier = Modifier.height(16.dp))
        Text("Sizing Formula Checklist", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("• Required Solar Capacity (W):")
        Text("Daily Appliance Wh demand / (Peak Sun Hours × System Correction Efficiency)", style = MaterialTheme.typography.bodySmall, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
        Spacer(modifier = Modifier.height(4.dp))
        Text("• Battery Bank capacity (Ah):")
        Text("(Daily load Wh × Autonomy Days) / (DoD % × battery Voltage × efficiency)", style = MaterialTheme.typography.bodySmall, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
        Spacer(modifier = Modifier.height(4.dp))
        Text("• Minimal cable Area (mm²):")
        Text("2 × Current × copper Resistivity × Length / Allowed Voltage drop Volts", style = MaterialTheme.typography.bodySmall, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
    }
}

// Helper Composable to allow extra small body labels
val Typography.bodyExtraSmall: androidx.compose.ui.text.TextStyle
    @Composable get() = bodySmall.copy(fontSize = 11.sp, lineHeight = 14.sp)
