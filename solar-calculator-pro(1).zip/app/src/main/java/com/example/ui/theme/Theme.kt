package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EcoGreenDark,
    secondary = SolarOrangeDark,
    tertiary = ElectricBlueDark,
    background = BackgroundDark,
    surface = SurfaceDark,
    onPrimary = Color(0xFF064E3B),
    onSecondary = Color(0xFF451A03),
    onTertiary = Color(0xFF172554),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0x22FFFFFF), // Glass outline tint
    onSurfaceVariant = Color(0xFF94A3B8)
)

private val LightColorScheme = lightColorScheme(
    primary = EcoGreenLight,
    secondary = SolarOrangeLight,
    tertiary = ElectricBlueLight,
    background = BackgroundLight,
    surface = SurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF1E293B), // Dark slate text for frosted light glass
    onSurface = Color(0xFF1E293B),
    surfaceVariant = Color(0x33000000), // Glass outline tint
    onSurfaceVariant = Color(0xFF64748B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
