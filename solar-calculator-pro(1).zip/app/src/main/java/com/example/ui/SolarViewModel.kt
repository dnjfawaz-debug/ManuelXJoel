package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Appliance
import com.example.data.JsonUtils
import com.example.data.Project
import com.example.data.ProjectRepository
import com.example.network.GeocodingResult
import com.example.network.OpenMeteoService
import com.example.network.WeatherResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface WeatherState {
    object Idle : WeatherState
    object Loading : WeatherState
    data class Success(
        val city: String,
        val temp: Double,
        val cloudCover: Double,
        val solarRadiation: Double,
        val psh: Double,
        val sunrise: String,
        val sunset: String,
        val windSpeed: Double,
        val isCached: Boolean = false
    ) : WeatherState
    data class Error(val message: String) : WeatherState
}

enum class Screen {
    DASHBOARD,
    LOAD_CALC,
    SOLAR_CALC,
    BATTERY_CALC,
    INVERTER_CALC,
    CONTROLLER_CALC,
    CABLE_CALC,
    COST_ESTIMATOR,
    WEATHER_DASHBOARD,
    REPORTS,
    SAVED_PROJECTS,
    SETTINGS,
    HELP
}

class SolarViewModel(
    application: Application,
    private val repository: ProjectRepository
) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("solar_calc_prefs", Context.MODE_PRIVATE)

    // Current screen navigation
    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Active project under editing
    private val _activeProject = MutableStateFlow(Project(name = "New Solar Sizing"))
    val activeProject: StateFlow<Project> = _activeProject.asStateFlow()

    // Active appliance list for the load calculator
    private val _appliances = MutableStateFlow<List<Appliance>>(emptyList())
    val appliances: StateFlow<List<Appliance>> = _appliances.asStateFlow()

    // Weather API service
    private val openMeteoService = OpenMeteoService.create()

    // Weather UI State
    private val _weatherState = MutableStateFlow<WeatherState>(WeatherState.Idle)
    val weatherState: StateFlow<WeatherState> = _weatherState.asStateFlow()

    // Geocoding city search results
    private val _citySearchResults = MutableStateFlow<List<GeocodingResult>>(emptyList())
    val citySearchResults: StateFlow<List<GeocodingResult>> = _citySearchResults.asStateFlow()

    private val _citySearchLoading = MutableStateFlow(false)
    val citySearchLoading: StateFlow<Boolean> = _citySearchLoading.asStateFlow()

    // List of saved projects
    val savedProjects: StateFlow<List<Project>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Global settings loaded from SharedPreferences
    val isDarkMode = MutableStateFlow(sharedPrefs.getBoolean("dark_mode", true))
    val currency = MutableStateFlow(sharedPrefs.getString("currency", "$") ?: "$")
    val language = MutableStateFlow(sharedPrefs.getString("language", "English") ?: "English")
    val defaultSystemVoltage = MutableStateFlow(sharedPrefs.getFloat("default_system_voltage", 24f).toDouble())
    val defaultPanelWattage = MutableStateFlow(sharedPrefs.getFloat("default_panel_wattage", 400f).toDouble())
    val defaultBatteryVoltage = MutableStateFlow(sharedPrefs.getFloat("default_battery_voltage", 12f).toDouble())
    val defaultSafetyMargin = MutableStateFlow(sharedPrefs.getFloat("default_safety_margin", 1.25f).toDouble())

    init {
        // Initialize active project with current default settings
        resetActiveProject()
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun resetActiveProject() {
        val newProj = Project(
            name = "Project - ${System.currentTimeMillis() % 10000}",
            systemVoltage = defaultSystemVoltage.value,
            panelWattage = defaultPanelWattage.value,
            batteryVoltage = defaultBatteryVoltage.value,
            inverterSafetyMargin = defaultSafetyMargin.value
        )
        _activeProject.value = newProj
        _appliances.value = emptyList()
        _weatherState.value = WeatherState.Idle
    }

    fun loadProject(project: Project) {
        _activeProject.value = project
        _appliances.value = JsonUtils.fromJson(project.applianceListJson)
        if (project.weatherCity.isNotEmpty()) {
            _weatherState.value = WeatherState.Success(
                city = project.weatherCity,
                temp = project.weatherTemp,
                cloudCover = project.weatherCloudCover,
                solarRadiation = project.weatherSolarRadiation,
                psh = project.weatherPSH,
                sunrise = project.weatherSunrise,
                sunset = project.weatherSunset,
                windSpeed = project.weatherWindSpeed,
                isCached = true
            )
        } else {
            _weatherState.value = WeatherState.Idle
        }
    }

    // Settings modifiers
    fun updateDarkMode(enabled: Boolean) {
        isDarkMode.value = enabled
        sharedPrefs.edit().putBoolean("dark_mode", enabled).apply()
    }

    fun updateCurrency(value: String) {
        currency.value = value
        sharedPrefs.edit().putString("currency", value).apply()
    }

    fun updateLanguage(value: String) {
        language.value = value
        sharedPrefs.edit().putString("language", value).apply()
    }

    fun updateDefaults(sysVolt: Double, panelWatt: Double, battVolt: Double, safety: Double) {
        defaultSystemVoltage.value = sysVolt
        defaultPanelWattage.value = panelWatt
        defaultBatteryVoltage.value = battVolt
        defaultSafetyMargin.value = safety
        
        sharedPrefs.edit()
            .putFloat("default_system_voltage", sysVolt.toFloat())
            .putFloat("default_panel_wattage", panelWatt.toFloat())
            .putFloat("default_battery_voltage", battVolt.toFloat())
            .putFloat("default_safety_margin", safety.toFloat())
            .apply()
    }

    // Active project parameter updates
    fun updateProjectName(name: String) {
        _activeProject.update { it.copy(name = name, updatedAt = System.currentTimeMillis()) }
    }

    fun updateCustomerDetails(name: String, email: String, notes: String) {
        _activeProject.update { 
            it.copy(
                customerName = name, 
                customerEmail = email, 
                notes = notes, 
                updatedAt = System.currentTimeMillis()
            ) 
        }
    }

    fun updateSolarParams(panelWatt: Double, sysVolt: Double, sysEff: Double, psh: Double) {
        _activeProject.update {
            it.copy(
                panelWattage = panelWatt,
                systemVoltage = sysVolt,
                systemEfficiency = sysEff,
                peakSunHours = psh,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    fun updateBatteryParams(battVolt: Double, battCap: Double, backupDays: Double, dod: Double, battEff: Double) {
        _activeProject.update {
            it.copy(
                batteryVoltage = battVolt,
                batteryCapacityAh = battCap,
                daysOfBackup = backupDays,
                depthOfDischarge = dod,
                batteryEfficiency = battEff,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    fun updateInverterParams(safetyMargin: Double) {
        _activeProject.update {
            it.copy(
                inverterSafetyMargin = safetyMargin,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    fun updateCableParams(distance: Double, vDropAllowed: Double) {
        _activeProject.update {
            it.copy(
                cableDistance = distance,
                cableVoltageDropAllowed = vDropAllowed,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    fun updateCostParams(
        panelPrice: Double,
        battPrice: Double,
        invPrice: Double,
        ctrlPrice: Double,
        mountPrice: Double,
        accPrice: Double,
        labPrice: Double,
        tariff: Double
    ) {
        _activeProject.update {
            it.copy(
                solarPanelPrice = panelPrice,
                batteryPrice = battPrice,
                inverterPrice = invPrice,
                chargeControllerPrice = ctrlPrice,
                mountingPrice = mountPrice,
                accessoriesPrice = accPrice,
                labourPrice = labPrice,
                electricityTariff = tariff,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    // Appliance Load operations
    fun addAppliance(name: String, qty: Int, watts: Double, hours: Double) {
        val newApp = Appliance(
            id = UUID.randomUUID().toString(),
            name = name,
            quantity = qty,
            powerWatts = watts,
            hoursPerDay = hours
        )
        val updatedList = _appliances.value + newApp
        _appliances.value = updatedList
        saveAppliancesToProject(updatedList)
    }

    fun deleteAppliance(applianceId: String) {
        val updatedList = _appliances.value.filter { it.id != applianceId }
        _appliances.value = updatedList
        saveAppliancesToProject(updatedList)
    }

    fun updateAppliance(applianceId: String, name: String, qty: Int, watts: Double, hours: Double) {
        val updatedList = _appliances.value.map {
            if (it.id == applianceId) {
                it.copy(name = name, quantity = qty, powerWatts = watts, hoursPerDay = hours)
            } else {
                it
            }
        }
        _appliances.value = updatedList
        saveAppliancesToProject(updatedList)
    }

    private fun saveAppliancesToProject(list: List<Appliance>) {
        val json = JsonUtils.toJson(list)
        _activeProject.update {
            it.copy(
                applianceListJson = json,
                updatedAt = System.currentTimeMillis()
            )
        }
    }

    // Weather Open-Meteo methods
    fun searchCities(query: String) {
        if (query.trim().isEmpty()) {
            _citySearchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            _citySearchLoading.value = true
            try {
                val response = openMeteoService.searchCity(name = query)
                _citySearchResults.value = response.results ?: emptyList()
            } catch (e: Exception) {
                _citySearchResults.value = emptyList()
            } finally {
                _citySearchLoading.value = false
            }
        }
    }

    fun fetchWeather(latitude: Double, longitude: Double, cityName: String) {
        viewModelScope.launch {
            _weatherState.value = WeatherState.Loading
            try {
                val weather = openMeteoService.getWeatherForecast(latitude = latitude, longitude = longitude)
                
                val current = weather.current
                val daily = weather.daily
                
                val temp = current?.temperature_2m ?: 25.0
                val cloudCover = current?.cloud_cover ?: 0.0
                val windSpeed = current?.wind_speed_10m ?: 0.0
                
                // Get sunrise and sunset (formatted beautifully, stripping dates if any)
                val rawSunrise = daily?.sunrise?.firstOrNull() ?: ""
                val rawSunset = daily?.sunset?.firstOrNull() ?: ""
                val sunrise = if (rawSunrise.contains("T")) rawSunrise.substringAfter("T") else "06:00"
                val sunset = if (rawSunset.contains("T")) rawSunset.substringAfter("T") else "18:00"
                
                // Estimate peak sun hours: daily shortwave_radiation_sum (MJ/m^2) / 3.6 = kWh/m^2/day = PSH
                val radiationMJ = daily?.shortwave_radiation_sum?.firstOrNull() ?: 18.0
                val computedPSH = radiationMJ / 3.6
                
                _weatherState.value = WeatherState.Success(
                    city = cityName,
                    temp = temp,
                    cloudCover = cloudCover,
                    solarRadiation = radiationMJ,
                    psh = computedPSH,
                    sunrise = sunrise,
                    sunset = sunset,
                    windSpeed = windSpeed,
                    isCached = false
                )

                // Update active project with weather details
                _activeProject.update {
                    it.copy(
                        weatherCity = cityName,
                        weatherLatitude = latitude,
                        weatherLongitude = longitude,
                        weatherTemp = temp,
                        weatherCloudCover = cloudCover,
                        weatherSolarRadiation = radiationMJ,
                        weatherPSH = computedPSH,
                        weatherSunrise = sunrise,
                        weatherSunset = sunset,
                        weatherWindSpeed = windSpeed,
                        peakSunHours = computedPSH, // Automatically use computed PSH in sizing!
                        updatedAt = System.currentTimeMillis()
                    )
                }

            } catch (e: Exception) {
                // If offline or failed, check if active project has cached values
                val proj = _activeProject.value
                if (proj.weatherCity.isNotEmpty()) {
                    _weatherState.value = WeatherState.Success(
                        city = proj.weatherCity,
                        temp = proj.weatherTemp,
                        cloudCover = proj.weatherCloudCover,
                        solarRadiation = proj.weatherSolarRadiation,
                        psh = proj.weatherPSH,
                        sunrise = proj.weatherSunrise,
                        sunset = proj.weatherSunset,
                        windSpeed = proj.weatherWindSpeed,
                        isCached = true
                    )
                } else {
                    _weatherState.value = WeatherState.Error(
                        "Failed to fetch weather. Offline or API error. Manual peak sun hours will be used."
                    )
                }
            }
        }
    }

    // Room persistence methods
    fun saveProjectToDb() {
        viewModelScope.launch {
            val proj = _activeProject.value
            val savedId = repository.insert(proj)
            // Load the saved project back to preserve Room's autogenerated ID
            if (proj.id == 0) {
                _activeProject.update { it.copy(id = savedId.toInt()) }
            }
        }
    }

    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val duplicated = project.copy(
                id = 0, // Reset ID to let Room autogenerate
                name = "${project.name} (Copy)",
                updatedAt = System.currentTimeMillis()
            )
            repository.insert(duplicated)
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch {
            repository.delete(project)
            if (_activeProject.value.id == project.id) {
                resetActiveProject()
            }
        }
    }
}

class SolarViewModelFactory(
    private val application: Application,
    private val repository: ProjectRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SolarViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SolarViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
