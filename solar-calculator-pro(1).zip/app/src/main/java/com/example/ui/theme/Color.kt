package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Solar Calculator Pro Palette (Eco Green, Solar Orange, Electric Blue)
// Infused with the "Frosted Glass" glassmorphism aesthetic

// Dark Theme Colors (Obsidian Glass)
val EcoGreenDark = Color(0xFF4ADE80) // Emerald mint
val EcoGreenDarkSecondary = Color(0xFF86EFAC)
val SolarOrangeDark = Color(0xFFFBBF24) // Gold solar orange
val ElectricBlueDark = Color(0xFF60A5FA) // Electric sky blue
val SurfaceDark = Color(0x551E293B) // Translucent glass slate
val BackgroundDark = Color(0xFF0F172A) // Dark slate backdrop

// Light Theme Colors (Crystal Glass)
val EcoGreenLight = Color(0xFF059669) // Forest emerald
val EcoGreenLightSecondary = Color(0xFF10B981)
val SolarOrangeLight = Color(0xFFF27D26) // Solar orange
val ElectricBlueLight = Color(0xFF2563EB) // Electric cobalt
val SurfaceLight = Color(0xB2FFFFFF) // Translucent ice white (70% opacity for frosted blur look)
val BackgroundLight = Color(0xFFF0F4F8) // Muted blue-grey backdrop

// Gradients from the "Frosted Glass" design spec
val SolarGradientStart = Color(0xFFF27D26)
val SolarGradientEnd = Color(0xFFFBBF24)

val IceGradientStart = Color(0xFFE0F2FE)
val IceGradientEnd = Color(0xFFBAE6FD)

val MintGradientStart = Color(0xFFD1FAE5)
val MintGradientEnd = Color(0xA16EE7B7)

