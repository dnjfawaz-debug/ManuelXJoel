package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val customerName: String = "",
    val customerEmail: String = "",
    val notes: String = "",
    
    // Appliance JSON serialization
    val applianceListJson: String = "[]",
    
    // Solar Panel parameters
    val panelWattage: Double = 400.0,
    val systemVoltage: Double = 24.0,
    val systemEfficiency: Double = 0.75,
    val peakSunHours: Double = 5.0,
    
    // Battery parameters
    val batteryVoltage: Double = 12.0,
    val batteryCapacityAh: Double = 200.0,
    val daysOfBackup: Double = 2.0,
    val depthOfDischarge: Double = 0.5,
    val batteryEfficiency: Double = 0.85,
    
    // Inverter parameters
    val inverterSafetyMargin: Double = 1.25,
    
    // Cable Sizing parameters
    val cableDistance: Double = 10.0,
    val cableVoltageDropAllowed: Double = 3.0, // 3%
    
    // Cost Estimator parameters
    val solarPanelPrice: Double = 150.0,
    val batteryPrice: Double = 250.0,
    val inverterPrice: Double = 400.0,
    val chargeControllerPrice: Double = 100.0,
    val mountingPrice: Double = 150.0,
    val accessoriesPrice: Double = 100.0,
    val labourPrice: Double = 300.0,
    val electricityTariff: Double = 0.15, // Cost per kWh
    
    // Weather Cached parameters
    val weatherCity: String = "",
    val weatherLatitude: Double = 0.0,
    val weatherLongitude: Double = 0.0,
    val weatherTemp: Double = 0.0,
    val weatherCloudCover: Double = 0.0,
    val weatherSolarRadiation: Double = 0.0,
    val weatherPSH: Double = 0.0,
    val weatherSunrise: String = "",
    val weatherSunset: String = "",
    val weatherWindSpeed: Double = 0.0,
    
    val updatedAt: Long = System.currentTimeMillis()
)

data class Appliance(
    val id: String,
    val name: String,
    val quantity: Int,
    val powerWatts: Double,
    val hoursPerDay: Double
)
