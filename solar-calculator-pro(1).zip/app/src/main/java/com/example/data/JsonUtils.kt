package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object JsonUtils {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
        
    private val listType = Types.newParameterizedType(List::class.java, Appliance::class.java)
    private val adapter = moshi.adapter<List<Appliance>>(listType)

    fun toJson(appliances: List<Appliance>): String {
        return try {
            adapter.toJson(appliances)
        } catch (e: Exception) {
            "[]"
        }
    }

    fun fromJson(json: String): List<Appliance> {
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
