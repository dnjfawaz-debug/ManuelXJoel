package com.example.data

import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<Project>> = projectDao.getAllProjects()

    fun getProjectById(id: Int): Flow<Project?> {
        return projectDao.getProjectById(id)
    }

    suspend fun insert(project: Project): Long {
        return projectDao.insertProject(project)
    }

    suspend fun update(project: Project) {
        projectDao.updateProject(project)
    }

    suspend fun delete(project: Project) {
        projectDao.deleteProject(project)
    }

    suspend fun deleteById(id: Int) {
        projectDao.deleteProjectById(id)
    }
}
