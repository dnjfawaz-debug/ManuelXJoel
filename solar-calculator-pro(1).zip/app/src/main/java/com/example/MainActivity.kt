package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppDatabase
import com.example.data.ProjectRepository
import com.example.ui.SolarCalculatorApp
import com.example.ui.SolarViewModel
import com.example.ui.SolarViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Room Database and Repository
        val database = AppDatabase.getDatabase(this)
        val repository = ProjectRepository(database.projectDao())
        
        // Instantiate Solar ViewModel using custom Factory
        val factory = SolarViewModelFactory(application, repository)
        val viewModel = ViewModelProvider(this, factory)[SolarViewModel::class.java]
        
        enableEdgeToEdge()
        
        setContent {
            val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = isDark) {
                SolarCalculatorApp(viewModel = viewModel)
            }
        }
    }
}
