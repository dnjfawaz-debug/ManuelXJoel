import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getDatabase, ref, onValue, set, off, Database } from 'firebase/database';
import { FirebaseConfig, SensorData, ESP32Device } from '../types';

let appInstance: FirebaseApp | null = null;
let dbInstance: Database | null = null;

// Initialize Firebase dynamically
export function initFirebase(config: FirebaseConfig): { success: boolean; error?: string } {
  try {
    // Validate configuration structure
    if (!config || !config.apiKey || !config.databaseURL) {
      throw new Error('Firebase Config requires at least apiKey and databaseURL.');
    }

    // Check if app already initialized
    const existingApps = getApps();
    if (existingApps.length > 0) {
      // Delete previous app to re-initialize with new config
      // In web, we can just initialize a secondary app or overwrite
      appInstance = initializeApp(config, 'SmartFloodApp-' + Date.now());
    } else {
      appInstance = initializeApp(config);
    }
    
    dbInstance = getDatabase(appInstance);
    return { success: true };
  } catch (error: any) {
    console.error('Firebase dynamic init failed:', error);
    return { success: false, error: error.message || String(error) };
  }
}

// Check if Firebase is initialized
export function isFirebaseReady(): boolean {
  return appInstance !== null && dbInstance !== null;
}

// Test Firebase Realtime Database connection by doing a read on a test path
export async function testFirebaseConnection(config: FirebaseConfig): Promise<{ success: boolean; error?: string }> {
  return new Promise((resolve) => {
    try {
      const tempApp = initializeApp(config, 'TestApp-' + Date.now());
      const tempDb = getDatabase(tempApp);
      const testRef = ref(tempDb, '.info/connected');
      
      const unsubscribe = onValue(
        testRef,
        (snapshot) => {
          const connected = snapshot.val();
          unsubscribe();
          if (connected === true || connected === false) {
            resolve({ success: true });
          } else {
            resolve({ success: false, error: 'Could not fetch connection status.' });
          }
        },
        (error) => {
          unsubscribe();
          resolve({ success: false, error: error.message || String(error) });
        }
      );

      // Timeout connection test after 6 seconds
      setTimeout(() => {
        try {
          unsubscribe();
        } catch (e) {}
        resolve({ success: false, error: 'Connection test timed out (6 seconds).' });
      }, 6000);
    } catch (error: any) {
      resolve({ success: false, error: error.message || String(error) });
    }
  });
}

// Subscribe to Live Sensor Data
export function subscribeToSensorData(
  path: string = 'drainage_system/sensors',
  onData: (data: Partial<SensorData>) => void,
  onError?: (err: any) => void
): () => void {
  if (!dbInstance) {
    if (onError) onError(new Error('Firebase DB is not initialized.'));
    return () => {};
  }

  const sensorRef = ref(dbInstance, path);
  const unsubscribe = onValue(
    sensorRef,
    (snapshot) => {
      const val = snapshot.val();
      if (val) {
        onData(val);
      }
    },
    (err) => {
      if (onError) onError(err);
    }
  );

  return () => {
    off(sensorRef, 'value', unsubscribe);
  };
}

// Subscribe to ESP32 Devices list
export function subscribeToDevices(
  path: string = 'drainage_system/devices',
  onData: (devices: ESP32Device[]) => void,
  onError?: (err: any) => void
): () => void {
  if (!dbInstance) {
    if (onError) onError(new Error('Firebase DB is not initialized.'));
    return () => {};
  }

  const devicesRef = ref(dbInstance, path);
  const unsubscribe = onValue(
    devicesRef,
    (snapshot) => {
      const val = snapshot.val();
      if (val) {
        if (Array.isArray(val)) {
          onData(val);
        } else if (typeof val === 'object') {
          // If stored as key-value pairs, convert to array
          const arr = Object.keys(val).map((key) => ({
            id: key,
            ...val[key]
          }));
          onData(arr);
        }
      }
    },
    (err) => {
      if (onError) onError(err);
    }
  );

  return () => {
    off(devicesRef, 'value', unsubscribe);
  };
}

// Helper to push mock data to the database (for testing integration)
export async function seedFirebaseMockData(
  sensors: SensorData,
  devices: ESP32Device[]
): Promise<{ success: boolean; error?: string }> {
  if (!dbInstance) {
    return { success: false, error: 'Firebase is not initialized.' };
  }

  try {
    const sensorsRef = ref(dbInstance, 'drainage_system/sensors');
    const devicesRef = ref(dbInstance, 'drainage_system/devices');

    await set(sensorsRef, sensors);
    
    // Write devices list
    const devicesObj: Record<string, any> = {};
    devices.forEach(d => {
      devicesObj[d.id] = d;
    });
    await set(devicesRef, devicesObj);

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || String(err) };
  }
}
