import { WeatherData, MonitoringLocation, ForecastItem } from '../types';

// Fetch live weather data from OpenWeather
export async function fetchWeatherData(
  apiKey: string,
  loc: MonitoringLocation
): Promise<WeatherData> {
  if (!apiKey) {
    throw new Error('API key is missing.');
  }

  const { latitude: lat, longitude: lon } = loc;

  // Fetch current weather
  const currentUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
  const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

  try {
    const currentRes = await fetch(currentUrl);
    if (!currentRes.ok) {
      const errorText = await currentRes.text();
      throw new Error(`Current Weather API error: ${currentRes.status} - ${errorText}`);
    }
    const currentData = await currentRes.json();

    const forecastRes = await fetch(forecastUrl);
    if (!forecastRes.ok) {
      const errorText = await forecastRes.text();
      throw new Error(`Forecast API error: ${forecastRes.status} - ${errorText}`);
    }
    const forecastData = await forecastRes.json();

    // Parse Sunrise and Sunset
    const formatTime = (timestamp: number) => {
      const date = new Date(timestamp * 1000);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    // Calculate rainfall (if any)
    let rainfall = 0;
    if (currentData.rain) {
      rainfall = currentData.rain['1h'] || currentData.rain['3h'] || 0;
    }

    // Process 5-day forecast
    // OpenWeather 5-day / 3-hour forecast returns 40 intervals. Let's take 1 reading per day (e.g. at 12:00 PM)
    const forecastItems: ForecastItem[] = [];
    const processedDays = new Set<string>();

    for (const item of forecastData.list) {
      const date = new Date(item.dt * 1000);
      const dayName = date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
      const hours = date.getHours();

      // Take standard reading around midday, or the first reading if we don't have this day yet
      if (!processedDays.has(dayName) && (hours >= 11 && hours <= 15 || iItemIsLast(item, forecastData.list, dayName))) {
        processedDays.add(dayName);
        forecastItems.push({
          time: dayName,
          temp: Math.round(item.main.temp),
          icon: item.weather[0].icon,
          description: item.weather[0].description
        });
      }
      
      // Limit to 5 days
      if (forecastItems.length >= 5) break;
    }

    // Fallback if forecast processing produced fewer items
    if (forecastItems.length < 5) {
      // just take some intervals
      for (let i = 0; i < forecastData.list.length && forecastItems.length < 5; i += 8) {
        const item = forecastData.list[i];
        const date = new Date(item.dt * 1000);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
        
        if (!forecastItems.some(f => f.time === dayName)) {
          forecastItems.push({
            time: dayName,
            temp: Math.round(item.main.temp),
            icon: item.weather[0].icon,
            description: item.weather[0].description
          });
        }
      }
    }

    return {
      temp: parseFloat(currentData.main.temp.toFixed(1)),
      humidity: currentData.main.humidity,
      pressure: currentData.main.pressure,
      windSpeed: parseFloat((currentData.wind.speed * 3.6).toFixed(1)), // convert m/s to km/h
      windDirection: currentData.wind.deg || 0,
      clouds: currentData.clouds.all,
      description: currentData.weather[0].description,
      icon: currentData.weather[0].icon,
      rainfall,
      sunrise: formatTime(currentData.sys.sunrise),
      sunset: formatTime(currentData.sys.sunset),
      forecast: forecastItems
    };
  } catch (error: any) {
    console.error('Weather API fetch failed:', error);
    throw error;
  }
}

function iItemIsLast(item: any, list: any[], dayName: string): boolean {
  // Find last index of this day to avoid missing days
  const lastIndex = list.map(x => new Date(x.dt * 1000).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })).lastIndexOf(dayName);
  return list[lastIndex]?.dt === item.dt;
}

// Test OpenWeather connection with a quick query
export async function testWeatherApi(apiKey: string): Promise<{ success: boolean; error?: string }> {
  const testUrl = `https://api.openweathermap.org/data/2.5/weather?q=Lagos&appid=${apiKey}`;
  try {
    const res = await fetch(testUrl);
    if (res.ok) {
      return { success: true };
    } else {
      const errorData = await res.json();
      return { success: false, error: errorData.message || 'API verification failed.' };
    }
  } catch (err: any) {
    return { success: false, error: err.message || String(err) };
  }
}
