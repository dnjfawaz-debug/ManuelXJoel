import React, { useState, useEffect, useRef } from 'react';
import { 
  SystemConfig, 
  SensorData, 
  ESP32Device, 
  Alert, 
  WeatherData, 
  HistoricalRecord 
} from './types';
import { 
  initialSensorData, 
  initialDevices, 
  initialAlerts, 
  defaultWeatherData, 
  getFormattedTime,
  getFormattedDate
} from './utils/simulation';
import { calculateFloodRisk } from './utils/floodRisk';
import { fetchWeatherData } from './services/weatherService';
import { 
  initFirebase, 
  subscribeToSensorData, 
  subscribeToDevices, 
  seedFirebaseMockData,
  isFirebaseReady 
} from './services/firebaseService';

// Import modular screens
import SetupWizard from './components/SetupWizard';
import DashboardOverview from './components/DashboardOverview';
import WeatherOverview from './components/WeatherOverview';
import InteractiveMap from './components/InteractiveMap';
import HistoricalCharts from './components/HistoricalCharts';
import AlertsLog from './components/AlertsLog';
import ConnectedDevices from './components/ConnectedDevices';
import ReportsSection from './components/ReportsSection';
import SettingsPanel from './components/SettingsPanel';
import AboutContact from './components/AboutContact';

// Lucide Icons
import { 
  Cpu, 
  Activity, 
  CloudRain, 
  Map, 
  LineChart, 
  ShieldAlert, 
  Smartphone, 
  FileSpreadsheet, 
  Settings, 
  Info,
  Layers,
  Menu,
  X,
  RefreshCw,
  Bell,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

export default function App() {
  // Configurations & Setup Status
  const [config, setConfig] = useState<SystemConfig>({
    openWeatherApiKey: '',
    firebaseConfig: null,
    location: {
      city: 'Ojo',
      state: 'Lagos',
      country: 'Nigeria',
      latitude: 6.4628,
      longitude: 3.1970
    },
    useSimulation: true,
    isConfigured: false
  });

  // Navigation Tab State
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core Telemetry Sensor state
  const [sensorData, setSensorData] = useState<SensorData>(initialSensorData);
  const [devices, setDevices] = useState<ESP32Device[]>(initialDevices);
  const [alerts, setAlerts] = useState<Alert[]>(initialAlerts);
  const [weather, setWeather] = useState<WeatherData | null>(defaultWeatherData);

  // Risk Calibration parameters
  const [waterWarningThreshold, setWaterWarningThreshold] = useState<number>(75);
  const [waterCriticalThreshold, setWaterCriticalThreshold] = useState<number>(90);

  // States for live polling
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);
  const [isRefreshingSensor, setIsRefreshingSensor] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  // Firebase unsubscribe registers
  const sensorUnsubscribeRef = useRef<(() => void) | null>(null);
  const devicesUnsubscribeRef = useRef<(() => void) | null>(null);

  // 1. Load configuration from localStorage on boot
  useEffect(() => {
    const saved = localStorage.getItem('smart_flood_config');
    if (saved) {
      try {
        const parsed: SystemConfig = JSON.parse(saved);
        setConfig(parsed);
        if (parsed.firebaseConfig) {
          initFirebase(parsed.firebaseConfig);
        }
      } catch (e) {
        console.error('Failed to parse saved config:', e);
      }
    }
  }, []);

  // 2. Initialize Telemetry Listeners & Polling on Config changes
  useEffect(() => {
    if (!config.isConfigured) return;

    // Clear any existing subscriptions first
    if (sensorUnsubscribeRef.current) sensorUnsubscribeRef.current();
    if (devicesUnsubscribeRef.current) devicesUnsubscribeRef.current();

    // A. Setup Live Weather Polling
    const syncWeather = async () => {
      if (config.openWeatherApiKey) {
        setIsLoadingWeather(true);
        setWeatherError(null);
        try {
          const liveWeather = await fetchWeatherData(config.openWeatherApiKey, config.location);
          setWeather(liveWeather);
        } catch (err: any) {
          setWeatherError(err.message || 'Weather fetch failure');
          // Keep using simulated/default weather as fallback
        } finally {
          setIsLoadingWeather(false);
        }
      } else {
        // Use simulation weather
        setWeather(defaultWeatherData);
      }
    };

    syncWeather();
    const weatherInterval = setInterval(syncWeather, 600000); // 10 minutes

    // B. Setup IoT Telemetry Subscriptions (Firebase vs. Cyclic Simulation)
    if (!config.useSimulation && isFirebaseReady()) {
      // Connect Live Firebase Listeners
      sensorUnsubscribeRef.current = subscribeToSensorData(
        'drainage_system/sensors',
        (liveData) => {
          setSensorData(prev => ({
            ...prev,
            ...liveData,
            lastUpdated: getFormattedTime()
          }));
        },
        (err) => console.error('Firebase sensor channel error:', err)
      );

      devicesUnsubscribeRef.current = subscribeToDevices(
        'drainage_system/devices',
        (liveDevices) => {
          if (liveDevices && liveDevices.length > 0) {
            setDevices(liveDevices);
          }
        },
        (err) => console.error('Firebase devices channel error:', err)
      );

    } else {
      // Use Simulation Engine (fluctuate values dynamically every 3 seconds)
      const simulationInterval = setInterval(() => {
        setSensorData(prev => {
          // Dynamic simulation values based on rainfall probability
          const isRaining = prev.rainDetected;
          let newRainIntensity = prev.rainIntensity;

          // Occasionally toggle raining state in simulation mode for live alerts demo!
          const rainOdds = Math.random();
          let newRainDetected = prev.rainDetected;
          if (rainOdds > 0.95) {
            newRainDetected = !prev.rainDetected;
            newRainIntensity = newRainDetected ? Math.round(40 + Math.random() * 50) : 0;
            
            // Log new alert for rain transition
            const alertId = `alt-${Date.now()}`;
            const newAlert: Alert = {
              id: alertId,
              type: newRainDetected ? 'warning' : 'info',
              message: newRainDetected 
                ? `Precipitation Alert: Rain detected at Ojo Main Inlet. Intensity: ${newRainIntensity}%.`
                : 'Precipitation Clear: Rainfall has ceased across Ojo Drainage Grid.',
              timestamp: `${getFormattedDate()} ${getFormattedTime()}`,
              acknowledged: false,
              category: 'rain'
            };
            setAlerts(prevAl => [newAlert, ...prevAl].slice(0, 40));
            triggerDesktopNotification(newAlert.message);
          }

          // Fluctuating Water Level
          let waterChange = (Math.random() * 4 - 2); // default slight drift
          if (isRaining) {
            waterChange += 2.5; // Rise continuously when raining
          } else {
            waterChange -= 1.0; // Recede when dry
          }

          const nextWaterLevel = Math.max(15, Math.min(100, Math.round(prev.waterLevel + waterChange)));

          // Fluctuating Flow Rate (corresponds with depth)
          const nextFlowRate = parseFloat(
            Math.max(5, Math.min(180, prev.flowRate + (nextWaterLevel / 20) + (Math.random() * 4 - 2))).toFixed(1)
          );

          // Fluctuating Atmosphere
          const nextTemp = parseFloat((28 + Math.sin(Date.now() / 60000) * 2 + Math.random() * 0.2).toFixed(1));
          const nextHum = Math.max(50, Math.min(100, Math.round(80 + Math.cos(Date.now() / 60000) * 10 + Math.random() * 2)));

          // Real-time automatic alert generator inside cyclic loop
          const updatedSensor: SensorData = {
            waterLevel: nextWaterLevel,
            rainDetected: newRainDetected,
            rainIntensity: newRainIntensity,
            flowRate: nextFlowRate,
            temperature: nextTemp,
            humidity: nextHum,
            wifiSignal: prev.wifiSignal,
            deviceStatus: prev.deviceStatus,
            lastUpdated: getFormattedTime()
          };

          // Trigger Water level warnings based on thresholds
          if (nextWaterLevel >= waterCriticalThreshold && prev.waterLevel < waterCriticalThreshold) {
            const warningId = `alt-${Date.now()}`;
            const alertMsg: Alert = {
              id: warningId,
              type: 'critical',
              message: `CRITICAL LEVEL BREACH! Water level registered ${nextWaterLevel}% at Ojo Main Inlet. Overflows active!`,
              timestamp: `${getFormattedDate()} ${getFormattedTime()}`,
              acknowledged: false,
              category: 'water_level'
            };
            setAlerts(prevAl => [alertMsg, ...prevAl].slice(0, 40));
            triggerDesktopNotification(alertMsg.message);
          } else if (nextWaterLevel >= waterWarningThreshold && prev.waterLevel < waterWarningThreshold && nextWaterLevel < waterCriticalThreshold) {
            const warningId = `alt-${Date.now()}`;
            const alertMsg: Alert = {
              id: warningId,
              type: 'warning',
              message: `High Water Warning: Ojo Main Inlet has reached ${nextWaterLevel}% capacity. Drainage flow is near limits.`,
              timestamp: `${getFormattedDate()} ${getFormattedTime()}`,
              acknowledged: false,
              category: 'water_level'
            };
            setAlerts(prevAl => [alertMsg, ...prevAl].slice(0, 40));
            triggerDesktopNotification(alertMsg.message);
          }

          return updatedSensor;
        });
      }, 3000);

      return () => {
        clearInterval(simulationInterval);
        clearInterval(weatherInterval);
      };
    }

    return () => {
      clearInterval(weatherInterval);
      if (sensorUnsubscribeRef.current) sensorUnsubscribeRef.current();
      if (devicesUnsubscribeRef.current) devicesUnsubscribeRef.current();
    };
  }, [config.isConfigured, config.useSimulation, config.openWeatherApiKey, waterWarningThreshold, waterCriticalThreshold]);

  // Desktop warning notification dispatcher
  const triggerDesktopNotification = (message: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('Smart Flood System Warning', {
        body: message,
        icon: '/favicon.ico'
      });
    }
  };

  // 3. User configuration save handler (Wizard / Settings)
  const handleSaveConfig = (updatedConfig: SystemConfig) => {
    setConfig(updatedConfig);
    localStorage.setItem('smart_flood_config', JSON.stringify(updatedConfig));
    if (updatedConfig.firebaseConfig) {
      initFirebase(updatedConfig.firebaseConfig);
    }
  };

  // Reset local configurations to launch Wizard setup again
  const handleResetConfig = () => {
    if (window.confirm('Wipe current config database and relaunch initialization Wizard?')) {
      localStorage.removeItem('smart_flood_config');
      setConfig({
        openWeatherApiKey: '',
        firebaseConfig: null,
        location: {
          city: 'Ojo',
          state: 'Lagos',
          country: 'Nigeria',
          latitude: 6.4628,
          longitude: 3.1970
        },
        useSimulation: true,
        isConfigured: false
      });
      setActiveTab('dashboard');
    }
  };

  // Launch Demo mode directly from Wizard Setup
  const handleLaunchDemo = () => {
    const demoConfig: SystemConfig = {
      openWeatherApiKey: '',
      firebaseConfig: null,
      location: {
        city: 'Ojo',
        state: 'Lagos',
        country: 'Nigeria',
        latitude: 6.4628,
        longitude: 3.1970
      },
      useSimulation: true,
      isConfigured: true
    };
    handleSaveConfig(demoConfig);
  };

  // Seed simulated gateway nodes to Firebase RTDB for easy developer sandbox testing
  const handleSeedFirebase = async () => {
    if (!config.firebaseConfig) return;
    setIsSeeding(true);
    const result = await seedFirebaseMockData(sensorData, devices);
    setIsSeeding(false);
    if (result.success) {
      alert('Mock telemetry arrays successfully written to Firebase Realtime Database!');
    } else {
      alert(`Database write failed: ${result.error}`);
    }
  };

  // Alert acknowledge triggers
  const handleAcknowledgeAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
  };

  const handleClearAllAlerts = () => {
    setAlerts([]);
  };

  // Device online toggle for simulated states
  const handleToggleDeviceStatus = (id: string) => {
    setDevices(prev => prev.map(dev => {
      if (dev.id === id) {
        const nextStatus = dev.status === 'online' ? 'offline' : 'online';
        
        // Push an alert when a node status changes!
        const alertId = `alt-${Date.now()}`;
        const newAlert: Alert = {
          id: alertId,
          type: nextStatus === 'offline' ? 'critical' : 'info',
          message: nextStatus === 'offline' 
            ? `GATEWAY DISCONNECTED: ${dev.name} is unreachable. Telemetry suspended.`
            : `GATEWAY CONNECTED: ${dev.name} has registered on primary gateway socket.`,
          timestamp: `${getFormattedDate()} ${getFormattedTime()}`,
          acknowledged: false,
          category: 'system'
        };
        setAlerts(prevAl => [newAlert, ...prevAl].slice(0, 40));
        triggerDesktopNotification(newAlert.message);

        return { ...dev, status: nextStatus };
      }
      return dev;
    }));
  };

  // Quick refresh pull triggers
  const handleRefreshSensorData = () => {
    setIsRefreshingSensor(true);
    setTimeout(() => {
      setSensorData(prev => ({
        ...prev,
        lastUpdated: getFormattedTime()
      }));
      setIsRefreshingSensor(false);
    }, 1000);
  };

  // Determine Overall system status
  const assessment = calculateFloodRisk(sensorData.waterLevel, sensorData.rainIntensity);

  // Switch layouts based on tab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardOverview 
            data={sensorData} 
            onRefresh={handleRefreshSensorData} 
            isRefreshing={isRefreshingSensor} 
          />
        );
      case 'weather':
        return (
          <WeatherOverview 
            weather={weather} 
            location={config.location} 
            isLoading={isLoadingWeather} 
            error={weatherError} 
            onRefresh={async () => {
              if (config.openWeatherApiKey) {
                setIsLoadingWeather(true);
                try {
                  const data = await fetchWeatherData(config.openWeatherApiKey, config.location);
                  setWeather(data);
                } catch (e) {}
                setIsLoadingWeather(false);
              }
            }}
            isSimulated={!config.openWeatherApiKey}
          />
        );
      case 'map':
        return <InteractiveMap sensors={sensorData} devices={devices} />;
      case 'history':
        return <HistoricalCharts />;
      case 'alerts':
        return (
          <AlertsLog 
            alerts={alerts} 
            onAcknowledgeAlert={handleAcknowledgeAlert} 
            onClearAllAlerts={handleClearAllAlerts}
            waterWarningThreshold={waterWarningThreshold}
            waterCriticalThreshold={waterCriticalThreshold}
            setWaterWarningThreshold={setWaterWarningThreshold}
            setWaterCriticalThreshold={setWaterCriticalThreshold}
          />
        );
      case 'devices':
        return (
          <ConnectedDevices 
            devices={devices} 
            onToggleDeviceStatus={handleToggleDeviceStatus} 
          />
        );
      case 'reports':
        return <ReportsSection />;
      case 'settings':
        return (
          <SettingsPanel 
            config={config} 
            onSaveConfig={handleSaveConfig} 
            onResetConfig={handleResetConfig} 
            onSeedFirebase={handleSeedFirebase}
            isSeeding={isSeeding}
          />
        );
      case 'about':
        return <AboutContact />;
      default:
        return <DashboardOverview data={sensorData} />;
    }
  };

  // If not configured, block and show Setup Wizard
  if (!config.isConfigured) {
    return <SetupWizard onComplete={handleSaveConfig} onLaunchDemo={handleLaunchDemo} />;
  }

  // Sidebar navigation configuration
  const navigationItems = [
    { id: 'dashboard', label: 'Live Status', icon: Activity },
    { id: 'weather', label: 'Weather Feed', icon: CloudRain },
    { id: 'map', label: 'GIS Flood Map', icon: Map },
    { id: 'history', label: 'Historical Data', icon: LineChart },
    { id: 'alerts', label: 'System Alerts', icon: ShieldAlert, badge: alerts.filter(a => !a.acknowledged).length },
    { id: 'devices', label: 'Node Devices', icon: Smartphone },
    { id: 'reports', label: 'Report logs', icon: FileSpreadsheet },
    { id: 'settings', label: 'Configurations', icon: Settings },
    { id: 'about', label: 'Architecture', icon: Info }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col relative select-none">
      
      {/* Immersive radial glowing visual overlays */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-3xl pointer-events-none z-0"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-3xl pointer-events-none z-0"></div>

      {/* 1. LARGE TOP ANIMATED WARNING BANNER (For High/Critical Risk values) */}
      {(assessment.level === 'High' || assessment.level === 'Critical') && (
        <div className={`w-full z-40 py-3.5 px-6 border-b font-mono text-xs flex flex-col sm:flex-row justify-between items-center gap-3 relative shadow-2xl ${assessment.bannerClass}`}>
          <div className="flex items-center gap-2.5 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
            <AlertTriangle className="w-4 h-4 text-white" />
            <span className="tracking-wider uppercase">MUNICIPAL EMERGENCY BROADCAST</span>
          </div>
          <span className="text-center sm:text-left font-sans font-medium text-[11px] opacity-90 max-w-2xl leading-normal">
            {assessment.level === 'Critical' 
              ? 'CRITICAL WARNING: Watershed breaching limits detected at Ojo Drainage Stations. Initiate localized evac actions.' 
              : 'HIGH WARNING: Rising runoff levels and heavy downpour patterns active. Monitor drainage channels and stay alert.'}
          </span>
          <span className="text-[10px] bg-white/10 border border-white/20 py-0.5 px-2 rounded-md uppercase font-bold tracking-widest">
            Level: {assessment.level}
          </span>
        </div>
      )}

      {/* Main Core Full-Width Layout Wrapper */}
      <div className="flex flex-1 relative z-10">
        
        {/* SIDEBAR NAVIGATION (Large screens) */}
        <aside className="w-64 bg-[#0A1120]/50 border-r border-cyan-900/20 p-5 flex flex-col justify-between shrink-0 hidden lg:flex">
          <div className="space-y-8">
            {/* App brand logo header */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-cyan-500/20 border border-cyan-400/50 rounded-lg flex items-center justify-center">
                <Cpu className="w-5 h-5 text-cyan-400 stroke-[2]" />
              </div>
              <div>
                <h1 className="text-sm font-display font-bold tracking-tight text-white uppercase leading-none">SmartFlood <span className="text-cyan-400">v2.4</span></h1>
                <p className="text-[9px] text-cyan-500/70 font-mono tracking-widest uppercase mt-1">IoT Cluster Control</p>
              </div>
            </div>

            {/* Navigation links stack */}
            <nav className="space-y-1">
              <div className="text-[10px] text-slate-500 font-mono font-bold uppercase mb-2 ml-2">Core Navigation</div>
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg font-medium transition-all text-left border ${
                      isActive 
                        ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20 font-bold' 
                        : 'text-slate-400 border-transparent hover:text-cyan-400 hover:bg-cyan-500/5'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                      <span className="text-xs tracking-tight">{item.label}</span>
                    </div>

                    {item.badge && item.badge > 0 ? (
                      <span className="py-0.5 px-1.5 bg-red-500/15 border border-red-500/25 text-red-400 font-mono text-[9px] font-bold rounded-md animate-pulse">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Footer Metadata */}
          <div className="border-t border-cyan-900/20 pt-4 mt-6">
            <div className="p-4 bg-cyan-950/20 border border-cyan-800/30 rounded-xl">
              <div className="flex justify-between items-center mb-2">
                <span className="text-[10px] text-cyan-500 font-mono font-bold uppercase tracking-wider">System Cluster Load</span>
                <span className="text-[10px] font-mono text-cyan-400 font-bold">14%</span>
              </div>
              <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 w-[14%]"></div>
              </div>
              <div className="mt-3 text-center">
                <span className="font-mono text-[8px] text-slate-500 uppercase tracking-widest block leading-none">Node: {config.location.city}, NG</span>
                <span className="font-mono text-[8px] text-cyan-400 uppercase mt-1 block leading-none">
                  {config.useSimulation ? 'SIMULATION' : 'RTDB GATEWAY'}
                </span>
              </div>
            </div>
          </div>
        </aside>

        {/* MOBILE DRAWER NAVIGATION MENU */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex flex-col p-6 lg:hidden">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-6">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <span className="font-bold text-white uppercase tracking-wider text-sm">Command Index</span>
              </div>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 bg-slate-900 border border-slate-850 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <nav className="space-y-1 flex-1 overflow-y-auto">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between p-3.5 rounded-2xl transition ${
                      isActive 
                        ? 'bg-slate-900 border border-cyan-500/25 text-cyan-400 font-bold' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4" />
                      <span className="text-xs">{item.label}</span>
                    </div>

                    {item.badge && item.badge > 0 ? (
                      <span className="py-0.5 px-2 bg-red-500/20 text-red-400 font-mono text-[10px] font-bold rounded-lg">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </nav>

            <div className="border-t border-slate-800 pt-4 mt-4 text-center">
              <button 
                onClick={handleResetConfig}
                className="w-full py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs rounded-xl font-mono uppercase font-bold"
              >
                Reset Configuration Wizard
              </button>
            </div>
          </div>
        )}

        {/* MAIN BODY WORKSPACE */}
        <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
          
          {/* Top header navigation row (Mobile menu toggler + system status indicators) */}
          <header className="h-16 border-b border-cyan-900/30 bg-[#0A1120] px-6 flex items-center justify-between shrink-0 relative z-10 shadow-lg shadow-cyan-950/20">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setMobileMenuOpen(true)}
                className="p-2 bg-[#0A1120] border border-cyan-900/30 rounded-xl text-slate-400 hover:text-white lg:hidden"
              >
                <Menu className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest font-bold">
                  SYS_TELEMETRY: {activeTab.replace('_', ' ').toUpperCase()}
                </span>
              </div>
            </div>

            {/* Overall status parameters */}
            <div className="flex items-center gap-4 sm:gap-6">
              <div className="text-right hidden sm:block">
                <p className="text-[10px] text-slate-500 uppercase font-mono font-bold tracking-tighter">Monitoring Cluster</p>
                <p className="text-xs font-mono text-cyan-400 font-bold">{config.location.city}, NG</p>
              </div>

              {/* Status Indicator circle */}
              <div className={`flex gap-2 items-center px-3.5 py-1.5 border rounded-full ${
                assessment.level === 'Critical' 
                  ? 'bg-red-950/30 border-red-500/50 text-red-400' 
                  : assessment.level === 'High'
                  ? 'bg-amber-950/30 border-amber-500/50 text-amber-400'
                  : 'bg-cyan-950/30 border-cyan-500/40 text-cyan-400'
              }`}>
                <div className={`w-2 h-2 rounded-full animate-pulse ${
                  assessment.level === 'Critical' ? 'bg-red-500 animate-ping' :
                  assessment.level === 'High' ? 'bg-amber-500' : 'bg-cyan-400'
                }`}></div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wide">
                  {assessment.level} Risk
                </span>
              </div>

              <div className="text-right border-l border-cyan-900/30 pl-4 sm:pl-6 font-mono hidden md:block">
                <p className="text-[10px] text-slate-500 leading-none">{getFormattedDate()}</p>
                <p className="text-sm text-cyan-400 font-bold mt-1 leading-none">{getFormattedTime()}</p>
              </div>
            </div>
          </header>

          {/* Active Panel View Workstation */}
          <div className="p-6 md:p-8 space-y-6 flex-1 max-w-7xl w-full mx-auto pb-16">
            {renderTabContent()}
          </div>

          {/* Footer content block */}
          <footer className="h-10 bg-[#050B14] border-t border-cyan-900/20 px-6 flex items-center justify-between shrink-0 text-[10px] font-mono text-slate-500">
            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${config.useSimulation ? 'bg-amber-500' : 'bg-green-500'}`}></div>
                <span className="text-[9px] text-slate-500 font-mono uppercase">
                  Telemetry Source: {config.useSimulation ? 'Simulation Model' : 'Firebase Ready'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-[9px] text-slate-500 font-mono uppercase">OpenWeather API: {config.openWeatherApiKey ? 'Connected' : 'Simulated'}</span>
              </div>
            </div>
            <div className="text-[9px] text-slate-600 font-mono uppercase tracking-wider hidden sm:block">
              &copy; 2026 Smart City Infrastructure • Secure Management System
            </div>
          </footer>

        </main>

      </div>
    </div>
  );
}
