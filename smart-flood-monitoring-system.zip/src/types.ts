export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  databaseURL: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  measurementId?: string;
}

export interface MonitoringLocation {
  city: string;
  state: string;
  country: string;
  latitude: number;
  longitude: number;
}

export interface SystemConfig {
  openWeatherApiKey: string;
  firebaseConfig: FirebaseConfig | null;
  location: MonitoringLocation;
  useSimulation: boolean;
  isConfigured: boolean;
}

export interface SensorData {
  waterLevel: number; // percentage (0-100)
  rainDetected: boolean;
  rainIntensity: number; // percentage (0-100)
  flowRate: number; // L/min
  temperature: number; // °C
  humidity: number; // %
  wifiSignal: number; // dBm (e.g., -65)
  deviceStatus: 'online' | 'offline';
  lastUpdated: string;
}

export interface ESP32Device {
  id: string;
  name: string;
  status: 'online' | 'offline';
  wifiSignal: number; // dBm
  lastCommunication: string;
  battery: number; // percentage or voltage
  ipAddress: string;
  firmwareVersion: string;
  uptime: string; // e.g., "3 days, 4 hours"
}

export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'critical';
  message: string;
  timestamp: string;
  acknowledged: boolean;
  category: 'water_level' | 'rain' | 'system' | 'flow_rate';
}

export interface ForecastItem {
  time: string;
  temp: number;
  icon: string;
  description: string;
}

export interface WeatherData {
  temp: number;
  humidity: number;
  pressure: number;
  windSpeed: number;
  windDirection: number;
  clouds: number;
  description: string;
  icon: string;
  rainfall: number;
  sunrise: string;
  sunset: string;
  forecast: ForecastItem[];
}

export type FloodRiskLevel = 'Low' | 'Moderate' | 'High' | 'Critical';

export interface HistoricalRecord {
  timestamp: string; // formatted date or time
  waterLevel: number;
  rainfall: number;
  flowRate: number;
  temperature: number;
  humidity: number;
}
