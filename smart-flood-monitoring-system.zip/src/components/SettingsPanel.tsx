import React, { useState } from 'react';
import { SystemConfig, FirebaseConfig, MonitoringLocation } from '../types';
import { testWeatherApi } from '../services/weatherService';
import { testFirebaseConnection, seedFirebaseMockData } from '../services/firebaseService';
import { Settings, Save, ShieldAlert, Key, Cpu, MapPin, Database, RefreshCw, CheckCircle2, AlertTriangle, Eye, EyeOff } from 'lucide-react';

interface SettingsPanelProps {
  config: SystemConfig;
  onSaveConfig: (updatedConfig: SystemConfig) => void;
  onResetConfig: () => void;
  onSeedFirebase: () => void;
  isSeeding: boolean;
}

export default function SettingsPanel({
  config,
  onSaveConfig,
  onResetConfig,
  onSeedFirebase,
  isSeeding
}: SettingsPanelProps) {
  const [openWeatherKey, setOpenWeatherKey] = useState(config.openWeatherApiKey);
  const [showKey, setShowKey] = useState(false);
  const [useSimulation, setUseSimulation] = useState(config.useSimulation);

  // Location details
  const [location, setLocation] = useState<MonitoringLocation>({ ...config.location });

  // Firebase configurations
  const [firebaseConfig, setFirebaseConfig] = useState<FirebaseConfig>({
    apiKey: config.firebaseConfig?.apiKey || '',
    authDomain: config.firebaseConfig?.authDomain || '',
    databaseURL: config.firebaseConfig?.databaseURL || '',
    projectId: config.firebaseConfig?.projectId || '',
    storageBucket: config.firebaseConfig?.storageBucket || '',
    messagingSenderId: config.firebaseConfig?.messagingSenderId || '',
    appId: config.firebaseConfig?.appId || '',
    measurementId: config.firebaseConfig?.measurementId || ''
  });

  // Action status indicators
  const [isValidatingWeather, setIsValidatingWeather] = useState(false);
  const [weatherStatus, setWeatherStatus] = useState<{ success?: boolean; error?: string } | null>(null);

  const [isValidatingFirebase, setIsValidatingFirebase] = useState(false);
  const [firebaseStatus, setFirebaseStatus] = useState<{ success?: boolean; error?: string } | null>(null);

  const [saveStatus, setSaveStatus] = useState(false);

  // Preset regions in Lagos to auto-load coordinates
  const lagosPresets = [
    { city: 'Ojo', state: 'Lagos', country: 'Nigeria', lat: 6.4628, lng: 3.1970, label: 'Ojo Station (Default)' },
    { city: 'Ikeja', state: 'Lagos', country: 'Nigeria', lat: 6.6018, lng: 3.3515, label: 'Ikeja Drain Grid' },
    { city: 'Apapa', state: 'Lagos', country: 'Nigeria', lat: 6.4428, lng: 3.3644, label: 'Apapa Ports Canal' },
    { city: 'Victoria Island', state: 'Lagos', country: 'Nigeria', lat: 6.4281, lng: 3.4219, label: 'VI Waterfront Outlet' }
  ];

  const selectPreset = (p: typeof lagosPresets[0]) => {
    setLocation({
      city: p.city,
      state: p.state,
      country: p.country,
      latitude: p.lat,
      longitude: p.lng
    });
  };

  const handleTestWeather = async () => {
    if (!openWeatherKey.trim()) {
      setWeatherStatus({ error: 'Please enter a key.' });
      return;
    }
    setIsValidatingWeather(true);
    setWeatherStatus(null);
    const result = await testWeatherApi(openWeatherKey.trim());
    setIsValidatingWeather(false);
    setWeatherStatus(result);
  };

  const handleTestFirebase = async () => {
    if (!firebaseConfig.apiKey || !firebaseConfig.databaseURL) {
      setFirebaseStatus({ error: 'API Key and Database URL are required.' });
      return;
    }
    setIsValidatingFirebase(true);
    setFirebaseStatus(null);
    const result = await testFirebaseConnection(firebaseConfig);
    setIsValidatingFirebase(false);
    setFirebaseStatus(result);
  };

  const handleSaveChanges = () => {
    const updated: SystemConfig = {
      openWeatherApiKey: openWeatherKey.trim(),
      firebaseConfig: firebaseConfig.apiKey.trim() ? firebaseConfig : null,
      location,
      useSimulation,
      isConfigured: true
    };
    onSaveConfig(updated);
    setSaveStatus(true);
    setTimeout(() => setSaveStatus(false), 2500);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0A1120] p-6 border border-cyan-900/30 rounded-2xl shadow-lg shadow-cyan-950/10">
        <div className="space-y-1">
          <h2 className="text-2xl font-display font-bold text-white tracking-tight">System Controls</h2>
          <p className="text-slate-400 text-sm">Update secret credentials, adjust coordinate benchmarks, or reset parameters.</p>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onResetConfig}
            className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 border border-red-500/20 rounded-xl font-mono text-xs font-bold transition duration-200"
          >
            Reset Setup Wizard
          </button>
          
          <button
            onClick={handleSaveChanges}
            className="flex items-center gap-2 px-5 py-2.5 bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-mono text-xs font-bold rounded-xl transition duration-200 uppercase tracking-widest shadow-lg shadow-cyan-500/10"
          >
            <Save className="w-4 h-4 stroke-[2.5]" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Save Success Alert Banner */}
      {saveStatus && (
        <div className="p-4 bg-cyan-500/15 border border-cyan-500/20 text-cyan-400 text-xs font-bold rounded-xl flex items-center gap-2 animate-pulse">
          <CheckCircle2 className="w-5 h-5 text-cyan-400" />
          <span>System Parameters Saved and Synchronized successfully!</span>
        </div>
      )}

      {/* Grid of panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* PANEL 1: SECRETS & INTEGRATIONS */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 space-y-6">
          <div className="border-b border-cyan-900/20 pb-3 flex items-center gap-2.5">
            <Key className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-display font-bold text-white">Integrations & Credentials</h3>
          </div>

          {/* OpenWeather Secret Key */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">OpenWeather API Key</label>
              <button 
                onClick={() => setShowKey(!showKey)}
                className="text-slate-500 hover:text-slate-300 font-mono text-[10px] flex items-center gap-1 transition font-bold"
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                {showKey ? 'Hide key' : 'Reveal key'}
              </button>
            </div>
            
            <div className="flex gap-2">
              <input
                type={showKey ? 'text' : 'password'}
                value={openWeatherKey}
                onChange={(e) => setOpenWeatherKey(e.target.value)}
                placeholder="No key provided - Simulated Weather active"
                className="flex-1 bg-slate-950/80 border border-cyan-900/30 focus:border-cyan-500 rounded-lg px-4 py-2.5 text-xs text-slate-100 font-mono focus:outline-none transition-all"
              />
              <button
                onClick={handleTestWeather}
                disabled={isValidatingWeather || !openWeatherKey}
                className="px-3 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-xs font-mono font-bold rounded-lg transition border border-cyan-500/20 disabled:opacity-30"
              >
                {isValidatingWeather ? 'testing...' : 'Verify'}
              </button>
            </div>

            {weatherStatus && (
              <div className={`p-3 border rounded-lg text-xs font-mono flex items-start gap-2 ${
                weatherStatus.success ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
              }`}>
                {weatherStatus.success ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />}
                <span>{weatherStatus.success ? 'API Connection Verified! Service Live.' : `Verification Failed: ${weatherStatus.error}`}</span>
              </div>
            )}
          </div>

          {/* Operation Engine mode switcher */}
          <div className="space-y-3 pt-3 border-t border-cyan-900/20">
            <span className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">Core telemetry mode</span>
            
            <div className="flex items-center justify-between p-4 bg-slate-950/60 border border-cyan-900/20 rounded-xl">
              <div>
                <span className="font-display font-bold text-slate-100 text-sm">Simulation Engine Override</span>
                <p className="text-[11px] text-slate-400 max-w-sm mt-1 leading-relaxed">
                  Locks telemetry lines to pre-loaded high-fidelity cyclic loops. Perfect for demonstrating live dashboard alarms without external setups.
                </p>
              </div>

              <div className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={useSimulation} 
                  onChange={(e) => setUseSimulation(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500 peer-checked:after:bg-slate-950"></div>
              </div>
            </div>
          </div>

          {/* Seed Firebase Integration Helpers */}
          {config.firebaseConfig && (
            <div className="p-4 bg-cyan-500/5 border border-cyan-500/10 rounded-xl space-y-2">
              <span className="font-mono text-[10px] text-cyan-400 font-bold uppercase tracking-widest block">Firebase Live Sandbox Seeding</span>
              <p className="text-xs text-slate-400 leading-normal">
                Connected to a live Firebase Database URL! Click below to automatically seed initial database directories (drainage paths, simulated devices) so your gateway registers immediately.
              </p>
              <button
                onClick={onSeedFirebase}
                disabled={isSeeding}
                className="w-full py-2 bg-slate-950 hover:bg-slate-900 text-cyan-400 border border-cyan-500/20 hover:border-cyan-500/45 text-xs font-mono font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
              >
                <Database className="w-4 h-4" />
                {isSeeding ? 'Writing to Firebase RTDB...' : 'Push Live Seeds to Firebase'}
              </button>
            </div>
          )}

        </div>

        {/* PANEL 2: STATION GEOGRAPHY PRESETS */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 space-y-6">
          <div className="border-b border-cyan-900/20 pb-3 flex items-center gap-2.5">
            <MapPin className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-display font-bold text-white">Monitoring Coordinates</h3>
          </div>

          <div className="space-y-4">
            <span className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">City Coordinates Benchmarks</span>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1 font-bold">Station City Name</label>
                <input
                  type="text"
                  value={location.city}
                  onChange={(e) => setLocation({ ...location, city: e.target.value })}
                  className="w-full bg-slate-950 border border-cyan-900/10 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1 font-bold">Territory Country</label>
                <input
                  type="text"
                  value={location.country}
                  onChange={(e) => setLocation({ ...location, country: e.target.value })}
                  className="w-full bg-slate-950 border border-cyan-900/10 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1 font-bold">Latitude Benchmark (Decimal)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={location.latitude}
                  onChange={(e) => setLocation({ ...location, latitude: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-cyan-900/10 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500 transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1 font-bold">Longitude Benchmark (Decimal)</label>
                <input
                  type="number"
                  step="0.0001"
                  value={location.longitude}
                  onChange={(e) => setLocation({ ...location, longitude: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-slate-950 border border-cyan-900/10 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500 transition-all"
                />
              </div>
            </div>

            {/* Presets block */}
            <div className="space-y-2 pt-3 border-t border-cyan-900/20">
              <span className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1.5 font-bold">Quick presets (Lagos State Watersheds)</span>
              <div className="grid grid-cols-2 gap-2">
                {lagosPresets.map((preset) => (
                  <button
                    key={preset.city}
                    onClick={() => selectPreset(preset)}
                    className={`p-2.5 bg-slate-950 hover:bg-slate-900 border text-[10px] font-mono rounded-lg transition-all text-left ${
                      location.city === preset.city ? 'border-cyan-500/50 text-cyan-400 font-bold' : 'border-cyan-900/10 text-slate-400'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* PANEL 3: FIREBASE SECRETS (COLUMNS-SPAN-FULL) */}
        <div className="lg:col-span-2 bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 space-y-5">
          <div className="border-b border-cyan-900/20 pb-3 flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-display font-bold text-white">Firebase IoT Configuration Credentials</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'API Key', key: 'apiKey', placeholder: 'AIzaSy...' },
              { label: 'Auth Domain', key: 'authDomain', placeholder: 'project-id.firebaseapp.com' },
              { label: 'Database URL', key: 'databaseURL', placeholder: 'https://project-id-rtdb.firebaseio.com' },
              { label: 'Project ID', key: 'projectId', placeholder: 'project-id' },
              { label: 'Storage Bucket', key: 'storageBucket', placeholder: 'project-id.appspot.com' },
              { label: 'Messaging Sender ID', key: 'messagingSenderId', placeholder: '1234567890' },
              { label: 'App ID', key: 'appId', placeholder: '1:1234:web:abcd' },
              { label: 'Measurement ID', key: 'measurementId', placeholder: 'G-XXXXXX' }
            ].map((input) => (
              <div key={input.key}>
                <label className="block text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1 font-bold">{input.label}</label>
                <input
                  type="text"
                  placeholder={input.placeholder}
                  value={firebaseConfig[input.key as keyof FirebaseConfig] || ''}
                  onChange={(e) => setFirebaseConfig({ ...firebaseConfig, [input.key]: e.target.value })}
                  className="w-full bg-slate-950 border border-cyan-900/15 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none transition-all"
                />
              </div>
            ))}
          </div>

          <div className="flex gap-3 pt-3 border-t border-cyan-900/20 justify-between items-center">
            <span className="text-[10px] font-mono text-slate-500 max-w-md font-bold">
              Leave API Key blank if you wish to completely disconnect Firebase subscription and utilize local cyclic simulations.
            </span>
            
            <div className="flex gap-2">
              <button
                onClick={handleTestFirebase}
                disabled={isValidatingFirebase}
                className="px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 text-xs font-mono font-bold rounded-lg transition border border-cyan-500/20 disabled:opacity-40"
              >
                {isValidatingFirebase ? 'Testing...' : 'Test Connection'}
              </button>
            </div>
          </div>

          {firebaseStatus && (
            <div className={`p-3 border rounded-lg text-xs font-mono flex items-start gap-2 ${
              firebaseStatus.success ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
            }`}>
              {firebaseStatus.success ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />}
              <span>{firebaseStatus.success ? 'Firebase Database Connected Successfully!' : `Firebase Failure: ${firebaseStatus.error}`}</span>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
