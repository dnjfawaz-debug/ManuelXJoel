import React from 'react';
import { SensorData, FloodRiskLevel } from '../types';
import { calculateFloodRisk } from '../utils/floodRisk';
import { Droplet, Wind, Thermometer, CloudRain, Activity, Wifi, ShieldAlert, CheckCircle, RefreshCw } from 'lucide-react';

interface DashboardOverviewProps {
  data: SensorData;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export default function DashboardOverview({ data, onRefresh, isRefreshing }: DashboardOverviewProps) {
  const assessment = calculateFloodRisk(data.waterLevel, data.rainIntensity);

  // Helper to determine drainage state based on water level
  const getDrainageStatus = (level: number) => {
    if (level >= 90) return { label: 'CRITICAL OVERFLOW', color: 'text-red-500', bg: 'bg-red-500/10 border-red-500/20' };
    if (level >= 80) return { label: 'HIGH SURGE INLET', color: 'text-amber-500', bg: 'bg-amber-500/10 border-amber-500/20' };
    if (level >= 50) return { label: 'MODERATE RETENTION', color: 'text-yellow-500', bg: 'bg-yellow-500/10 border-yellow-500/20' };
    return { label: 'SAFE CLEAR DRAINAGE', color: 'text-cyan-400', bg: 'bg-cyan-500/10 border-cyan-500/20' };
  };

  const drainage = getDrainageStatus(data.waterLevel);

  return (
    <div className="space-y-6">
      
      {/* Flood Risk Banner at top */}
      <div className={`border border-cyan-900/30 p-6 rounded-2xl bg-[#0A1120] transition-all duration-500 relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl shadow-cyan-950/20 ${assessment.bgClass}`}>
        {/* Animated fluid pulse in back */}
        <div className={`absolute -right-20 -bottom-20 w-64 h-64 rounded-full blur-3xl opacity-20 ${assessment.level === 'Critical' ? 'bg-red-600' : 'bg-cyan-600'}`}></div>
        
        <div className="space-y-2 relative z-10">
          <div className="flex items-center gap-3">
            <span className={`w-3.5 h-3.5 rounded-full ${assessment.pulseClass}`}></span>
            <span className="font-mono text-xs uppercase tracking-widest text-cyan-500/80 font-bold">INTELLIGENT RISK ENGINE</span>
          </div>
          <h2 className="text-3xl font-display font-bold text-white tracking-tight flex flex-wrap items-center gap-2">
            Current Assessment: 
            <span className={`${assessment.colorClass} font-extrabold`}>{assessment.level} Risk</span>
          </h2>
          <p className="text-slate-300 text-sm max-w-3xl leading-relaxed">
            {assessment.description}
          </p>
        </div>

        <div className="md:text-right shrink-0 relative z-10 w-full md:w-auto">
          <div className="p-4 bg-slate-950/80 border border-cyan-900/20 rounded-xl max-w-sm space-y-1">
            <span className="font-mono text-[10px] text-cyan-500/80 uppercase tracking-widest font-bold">EMERGENCY PROTOCOL</span>
            <p className="text-xs text-slate-300 leading-normal font-sans">{assessment.recommendation}</p>
          </div>
        </div>
      </div>

      {/* Grid of Dashboard Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* 1. WATER LEVEL CARD (With custom glass fluid wave simulation) */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 group flex flex-col justify-between min-h-[220px]">
          {/* Wave background shifting dynamically with water level percentage */}
          <div 
            className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-950/40 to-cyan-500/10 transition-all duration-1000 ease-out z-0"
            style={{ height: `${data.waterLevel}%` }}
          >
            {/* Animated SVG water ripple wave */}
            <div className="absolute top-0 left-0 right-0 h-4 overflow-hidden -mt-3.5">
              <svg viewBox="0 0 120 28" className="w-[200%] h-full text-cyan-500/20 animate-[wave_6s_infinite_linear] fill-current">
                <path d="M0 15 Q 30 0, 60 15 T 120 15 T 180 15 T 240 15 L 240 28 L 0 28 Z" />
              </svg>
            </div>
          </div>

          <div className="relative z-10 flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Telemetry</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Water Level</h3>
            </div>
            <div className="p-3 bg-cyan-500/10 rounded-xl border border-cyan-500/20 text-cyan-400">
              <Droplet className="w-5 h-5" />
            </div>
          </div>

          <div className="relative z-10 my-4 flex items-baseline gap-2">
            <span className="text-6xl font-display font-extrabold text-white tracking-tight">{data.waterLevel}</span>
            <span className="text-xl font-mono text-cyan-400 font-bold">%</span>
          </div>

          <div className="relative z-10 flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3">
            <span className="text-slate-500">Status:</span>
            <span className={data.waterLevel >= 80 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
              {data.waterLevel >= 90 ? 'CRITICAL LIMIT' : data.waterLevel >= 80 ? 'HIGH SEVERITY' : 'SAFE CAP'}
            </span>
          </div>
        </div>

        {/* 2. RAIN DETECTION */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 flex flex-col justify-between min-h-[220px]">
          {/* Storm ambient aura */}
          <div className={`absolute -right-12 -top-12 w-32 h-32 rounded-full blur-3xl opacity-20 transition-all duration-500 ${data.rainDetected ? 'bg-blue-500' : 'bg-slate-500'}`}></div>

          <div className="flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Precipitation</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Rain Detection</h3>
            </div>
            <div className={`p-3 rounded-xl border transition-all ${data.rainDetected ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' : 'bg-slate-800/80 border-slate-700/50 text-slate-500'}`}>
              <CloudRain className="w-5 h-5" />
            </div>
          </div>

          <div className="my-4">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-display font-extrabold text-white tracking-tight">{data.rainDetected ? 'DETECTED' : 'DRY'}</span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-1">
              Rain intensity: <span className="text-cyan-400 font-bold">{data.rainIntensity}%</span>
            </p>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-blue-500 h-full transition-all duration-1000 ease-out"
              style={{ width: `${data.rainIntensity}%` }}
            ></div>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3 mt-1">
            <span className="text-slate-500">Sensor Value:</span>
            <span className="text-slate-300 font-medium">{data.rainDetected ? 'Analog low trigger' : 'No conductive feedback'}</span>
          </div>
        </div>

        {/* 3. WATER FLOW RATE */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 flex flex-col justify-between min-h-[220px]">
          <div className="flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Dynamic Flow</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Water Flow Rate</h3>
            </div>
            <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400">
              <Wind className="w-5 h-5 animate-spin-slow" />
            </div>
          </div>

          <div className="my-4 flex items-baseline gap-2">
            <span className="text-5xl font-display font-extrabold text-white tracking-tight">{data.flowRate}</span>
            <span className="text-lg font-mono text-emerald-400 font-bold">L/min</span>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3">
            <span className="text-slate-500">System State:</span>
            <span className="text-emerald-400 font-bold">FLOW STEADY</span>
          </div>
        </div>

        {/* 4. TEMPERATURE & HUMIDITY */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 flex flex-col justify-between min-h-[220px]">
          <div className="flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Atmospheric</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Temp & Humidity</h3>
            </div>
            <div className="p-3 bg-yellow-500/10 rounded-xl border border-yellow-500/20 text-yellow-400">
              <Thermometer className="w-5 h-5" />
            </div>
          </div>

          <div className="my-4 grid grid-cols-2 gap-4">
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Temperature</span>
              <p className="text-2xl font-bold text-white mt-1">{data.temperature}°C</p>
            </div>
            <div className="border-l border-cyan-900/20 pl-4">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Humidity</span>
              <p className="text-2xl font-bold text-white mt-1">{data.humidity}%</p>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3">
            <span className="text-slate-500">Vapor Pressure:</span>
            <span className="text-yellow-400 font-medium">Saturated</span>
          </div>
        </div>

        {/* 5. DRAINAGE STATUS & RISK LEVEL */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 flex flex-col justify-between min-h-[220px]">
          <div className="flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Capacity</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Drainage Status</h3>
            </div>
            <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Activity className="w-5 h-5" />
            </div>
          </div>

          <div className="my-4">
            <div className={`inline-block py-2 px-4 rounded-xl text-xs font-bold font-mono tracking-wider border border-cyan-500/10 ${drainage.bg} ${drainage.color}`}>
              {drainage.label}
            </div>
            <p className="text-xs text-slate-400 font-mono mt-2">
              Retention level: <span className="text-white">{data.waterLevel}%</span>
            </p>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3">
            <span className="text-slate-500">Alert Line:</span>
            <span className="text-indigo-400 font-medium">Auto-Switch pumps</span>
          </div>
        </div>

        {/* 6. SYSTEM STRENGTH & STATUS */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 relative overflow-hidden shadow-lg shadow-cyan-950/15 flex flex-col justify-between min-h-[220px]">
          <div className="flex justify-between items-start">
            <div>
              <span className="font-mono text-xs text-cyan-500/70 uppercase tracking-widest">Gateway</span>
              <h3 className="text-lg font-display font-bold text-white mt-1">Device Status</h3>
            </div>
            <div className={`p-3 rounded-xl border ${data.deviceStatus === 'online' ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' : 'bg-red-500/10 border-red-500/20 text-red-500'}`}>
              <Wifi className="w-5 h-5" />
            </div>
          </div>

          <div className="my-4">
            <div className="flex items-center gap-2.5">
              <span className={`w-3 h-3 rounded-full ${data.deviceStatus === 'online' ? 'bg-cyan-400 animate-pulse' : 'bg-red-500'}`}></span>
              <span className="text-3xl font-display font-extrabold text-white tracking-tight uppercase">{data.deviceStatus}</span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-2">
              Signal strength: <span className="text-cyan-400 font-bold">{data.wifiSignal} dBm</span>
            </p>
          </div>

          <div className="flex justify-between items-center text-xs font-mono border-t border-cyan-905/30 pt-3">
            <span className="text-slate-500">Last Telemetry:</span>
            <span className="text-cyan-400 font-semibold">{data.lastUpdated}</span>
          </div>
        </div>

      </div>

      {/* Manual Refresh / Heartbeat indicator */}
      <div className="flex justify-between items-center p-4 bg-[#0A1120] border border-cyan-900/30 rounded-2xl text-xs text-slate-400 shadow-md shadow-cyan-950/10">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span className="font-mono uppercase text-[10px] text-slate-400">Listening to ESP32 gateway telemetry queue</span>
        </div>
        {onRefresh && (
          <button 
            onClick={onRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 font-mono font-semibold transition py-1.5 px-4 bg-cyan-950/20 rounded-xl border border-cyan-500/30"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            Force Pull
          </button>
        )}
      </div>

    </div>
  );
}
