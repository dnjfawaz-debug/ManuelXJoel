import React, { useState, useEffect } from 'react';
import { generateHistoricalData } from '../utils/simulation';
import { HistoricalRecord } from '../types';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Calendar, Droplet, Wind, CloudRain, Thermometer, RefreshCw } from 'lucide-react';

interface HistoricalChartsProps {
  // Option to pass live historical data if needed
  liveHistory?: HistoricalRecord[];
}

export default function HistoricalCharts({ liveHistory }: HistoricalChartsProps) {
  const [filter, setFilter] = useState<'today' | '7days' | '30days'>('today');
  const [activeMetric, setActiveMetric] = useState<'waterLevel' | 'rainfall' | 'flowRate' | 'atmosphere'>('waterLevel');
  const [data, setData] = useState<HistoricalRecord[]>([]);
  const [isRegenerating, setIsRegenerating] = useState(false);

  useEffect(() => {
    setIsRegenerating(true);
    // Generate new high-fidelity simulated historical records
    const simulated = generateHistoricalData(filter);
    setData(simulated);
    
    const timer = setTimeout(() => setIsRegenerating(false), 300);
    return () => clearTimeout(timer);
  }, [filter]);

  // Combine live records if provided and matching length
  const chartData = liveHistory && liveHistory.length > 0 ? liveHistory : data;

  const metricsInfo = {
    waterLevel: {
      title: 'Drainage Water Level',
      strokeColor: '#06b6d4', // cyan-500
      fillColor: 'rgba(6, 182, 212, 0.1)',
      yUnit: '%',
      icon: Droplet
    },
    rainfall: {
      title: 'Precipitation/Rainfall',
      strokeColor: '#3b82f6', // blue-500
      fillColor: 'rgba(59, 130, 246, 0.1)',
      yUnit: 'mm',
      icon: CloudRain
    },
    flowRate: {
      title: 'Water Flow Velocity',
      strokeColor: '#10b981', // emerald-500
      fillColor: 'rgba(16, 185, 129, 0.1)',
      yUnit: 'L/min',
      icon: Wind
    },
    atmosphere: {
      title: 'Ambient Temperature & Humidity',
      strokeColor: '#eab308', // yellow-500
      fillColor: 'rgba(234, 179, 8, 0.1)',
      yUnit: '°C / %',
      icon: Thermometer
    }
  };

  const currentMetric = metricsInfo[activeMetric];

  // Custom tooltip for matching visual theme
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-950/95 border border-cyan-900/30 p-4 rounded-xl shadow-2xl font-mono text-xs">
          <p className="text-slate-400 mb-2 font-bold flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
            {label}
          </p>
          {payload.map((p: any) => (
            <p key={p.name} style={{ color: p.color }} className="font-bold flex justify-between gap-6 py-0.5">
              <span>{p.name}:</span>
              <span>{p.value} {p.name === 'Temperature' ? '°C' : p.name === 'Humidity' ? '%' : p.name === 'Rainfall' ? 'mm' : p.name === 'Water Level' ? '%' : 'L/min'}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      
      {/* Header Controls */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 bg-[#0A1120] p-6 border border-cyan-900/30 rounded-2xl shadow-lg shadow-cyan-950/10">
        <div className="space-y-1">
          <h2 className="text-2xl font-display font-bold text-white tracking-tight">Analytical Logging</h2>
          <p className="text-slate-400 text-sm">Review historical drainage and meteorology sensors telemetry logs.</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
          {(['today', '7days', '30days'] as const).map((opt) => (
            <button
              key={opt}
              onClick={() => setFilter(opt)}
              className={`flex-1 xl:flex-none px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all duration-200 ${
                filter === opt 
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' 
                  : 'bg-slate-950 border border-cyan-900/20 text-slate-400 hover:text-slate-200'
              }`}
            >
              {opt === 'today' ? 'Today (Hourly)' : opt === '7days' ? 'Last 7 Days' : 'Last 30 Days'}
            </button>
          ))}
        </div>
      </div>

      {/* Metric Selector Rail */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { key: 'waterLevel', label: 'Water Level', icon: Droplet, color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' },
          { key: 'rainfall', label: 'Rainfall', icon: CloudRain, color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
          { key: 'flowRate', label: 'Flow Rate', icon: Wind, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
          { key: 'atmosphere', label: 'Atmosphere', icon: Thermometer, color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' }
        ].map((btn) => {
          const Icon = btn.icon;
          const isSelected = activeMetric === btn.key;
          return (
            <button
              key={btn.key}
              onClick={() => setActiveMetric(btn.key as any)}
              className={`flex items-center gap-3 p-4 rounded-xl border transition-all duration-300 text-left ${
                isSelected 
                  ? 'bg-[#0A1120] border-cyan-500/50 shadow-md ring-1 ring-cyan-500/20' 
                  : 'bg-[#0A1120]/60 border-cyan-900/20 hover:bg-[#0A1120] hover:border-cyan-900/40'
              }`}
            >
              <div className={`p-2 rounded-xl shrink-0 ${isSelected ? btn.color : 'bg-slate-950 text-slate-400 border border-cyan-900/10'}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">sensor Type</span>
                <span className={`text-sm font-display font-bold block ${isSelected ? 'text-white' : 'text-slate-400'}`}>{btn.label}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Chart Card */}
      <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 relative min-h-[400px]">
        {isRegenerating && (
          <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm z-20 flex items-center justify-center rounded-2xl">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
        )}

        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
            <currentMetric.icon className="w-5 h-5 text-cyan-400" />
            {currentMetric.title} Trends
          </h3>
          <span className="font-mono text-xs text-slate-500 uppercase font-bold">Unit: {currentMetric.yUnit}</span>
        </div>

        {/* Charts implementation using Recharts */}
        <div className="w-full h-[320px] select-none">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorMetric" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={currentMetric.strokeColor} stopOpacity={0.2}/>
                  <stop offset="95%" stopColor={currentMetric.strokeColor} stopOpacity={0}/>
                </linearGradient>
                {activeMetric === 'atmosphere' && (
                  <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#eab308" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                  </linearGradient>
                )}
                {activeMetric === 'atmosphere' && (
                  <linearGradient id="colorHum" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d946ef" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#d946ef" stopOpacity={0}/>
                  </linearGradient>
                )}
              </defs>
              <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="timestamp" 
                stroke="#64748b" 
                fontSize={10} 
                fontFamily="JetBrains Mono, monospace" 
                dy={10}
                tickLine={false}
              />
              <YAxis 
                stroke="#64748b" 
                fontSize={10} 
                fontFamily="JetBrains Mono, monospace" 
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              
              {activeMetric === 'atmosphere' ? (
                <>
                  <Area 
                    type="monotone" 
                    name="Temperature"
                    dataKey="temperature" 
                    stroke="#eab308" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorTemp)" 
                  />
                  <Area 
                    type="monotone" 
                    name="Humidity"
                    dataKey="humidity" 
                    stroke="#d946ef" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorHum)" 
                  />
                </>
              ) : (
                <Area 
                  type="monotone" 
                  name={
                    activeMetric === 'waterLevel' ? 'Water Level' :
                    activeMetric === 'rainfall' ? 'Rainfall' : 'Flow Rate'
                  }
                  dataKey={
                    activeMetric === 'waterLevel' ? 'waterLevel' :
                    activeMetric === 'rainfall' ? 'rainfall' : 'flowRate'
                  } 
                  stroke={currentMetric.strokeColor} 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorMetric)" 
                />
              )}
              <Legend verticalAlign="top" height={36} iconType="circle" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
