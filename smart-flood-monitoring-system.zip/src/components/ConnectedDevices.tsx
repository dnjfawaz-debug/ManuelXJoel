import React, { useState } from 'react';
import { ESP32Device } from '../types';
import { Cpu, Wifi, Battery, RefreshCw, Radio, HardDrive, CheckCircle2, AlertCircle } from 'lucide-react';

interface ConnectedDevicesProps {
  devices: ESP32Device[];
  onToggleDeviceStatus: (id: string) => void;
}

export default function ConnectedDevices({ devices, onToggleDeviceStatus }: ConnectedDevicesProps) {
  // Helper to resolve RSSI visual signal bars
  const getSignalStrength = (rssi: number) => {
    if (rssi >= -67) return { label: 'Excellent', color: 'text-cyan-400', pct: 90 };
    if (rssi >= -75) return { label: 'Good', color: 'text-emerald-400', pct: 70 };
    if (rssi >= -85) return { label: 'Fair', color: 'text-yellow-500', pct: 45 };
    return { label: 'Poor', color: 'text-red-500', pct: 20 };
  };

  const getBatteryStyle = (bat: number) => {
    if (bat > 70) return { text: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' };
    if (bat > 30) return { text: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' };
    return { text: 'text-red-400 animate-pulse', bg: 'bg-red-500/10 border-red-500/20' };
  };

  return (
    <div className="space-y-6">
      
      {/* Overview Block */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0A1120] p-6 border border-cyan-900/30 rounded-2xl shadow-lg shadow-cyan-950/10">
        <div className="space-y-1">
          <h2 className="text-2xl font-display font-bold text-white tracking-tight">Connected IoT Gateways</h2>
          <p className="text-slate-400 text-sm">Review real-time status and hardware diagnostics for all ESP32 nodes.</p>
        </div>
        
        {/* Device summary stats */}
        <div className="flex gap-4 font-mono text-xs">
          <div className="p-3 bg-slate-950 border border-cyan-900/20 rounded-xl">
            <span className="text-slate-500 block font-bold">TOTAL NODES</span>
            <span className="text-white font-bold text-lg mt-0.5 block">{devices.length}</span>
          </div>
          <div className="p-3 bg-slate-950 border border-cyan-900/20 rounded-xl">
            <span className="text-slate-500 block font-bold">ONLINE</span>
            <span className="text-cyan-400 font-bold text-lg mt-0.5 block">
              {devices.filter(d => d.status === 'online').length}
            </span>
          </div>
        </div>
      </div>

      {/* Grid of Devices */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {devices.map((device) => {
          const signal = getSignalStrength(device.wifiSignal);
          const battery = getBatteryStyle(device.battery);
          const isOnline = device.status === 'online';

          return (
            <div 
              key={device.id} 
              className={`bg-[#0A1120] border rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between transition-all duration-300 shadow-cyan-950/15 ${
                isOnline ? 'border-cyan-900/30' : 'border-red-500/20 hover:border-red-500/30'
              }`}
            >
              {/* Inner Status Aura */}
              <div className={`absolute -right-12 -top-12 w-28 h-28 rounded-full blur-3xl opacity-10 ${
                isOnline ? 'bg-cyan-500' : 'bg-red-500'
              }`}></div>

              <div>
                {/* Device Title & Quick Toggle */}
                <div className="flex justify-between items-start mb-4 border-b border-cyan-905/20 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-xl border ${
                      isOnline ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' : 'bg-red-500/10 border-red-500/20 text-red-500'
                    }`}>
                      <Cpu className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-display font-bold text-white tracking-tight">{device.name}</h3>
                      <span className="font-mono text-[9px] text-slate-500 uppercase">MAC: {device.id.toUpperCase()}</span>
                    </div>
                  </div>
                  
                  {/* Status Indicator Pill */}
                  <span className={`inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                    isOnline ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30' : 'bg-red-500/15 text-red-500 border border-red-500/30'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-cyan-400 animate-pulse' : 'bg-red-500'}`}></span>
                    {device.status}
                  </span>
                </div>

                {/* Technical diagnostics metrics list */}
                <div className="space-y-3 font-mono text-xs">
                  
                  {/* Wi-Fi Telemetry */}
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500 flex items-center gap-1.5">
                        <Wifi className="w-3.5 h-3.5 text-slate-500" />
                        Wireless Signal:
                      </span>
                      <span className={`${signal.color} font-bold`}>{device.wifiSignal} dBm ({signal.label})</span>
                    </div>
                    {isOnline ? (
                      <div className="w-full bg-slate-950 rounded-full h-1">
                        <div 
                          className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${signal.pct}%` }}
                        ></div>
                      </div>
                    ) : (
                      <div className="w-full bg-slate-950 rounded-full h-1">
                        <div className="bg-red-500 h-full rounded-full" style={{ width: '5%' }}></div>
                      </div>
                    )}
                  </div>

                  {/* Battery Telemetry */}
                  <div className="flex justify-between items-center py-1">
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <Battery className="w-3.5 h-3.5 text-slate-500" />
                      Backup Battery:
                    </span>
                    <span className={`font-semibold py-0.5 px-2 rounded-md border ${battery.text} ${battery.bg}`}>
                      {device.battery}%
                    </span>
                  </div>

                  {/* Uptime */}
                  <div className="flex justify-between items-center border-t border-cyan-905/20 pt-2 pb-1">
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-slate-500" />
                      Uptime Status:
                    </span>
                    <span className="text-slate-300">{isOnline ? device.uptime : 'Offline'}</span>
                  </div>

                  {/* Firmware & IP */}
                  <div className="flex justify-between items-center border-t border-cyan-905/20 pt-2">
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <HardDrive className="w-3.5 h-3.5 text-slate-500" />
                      FW / IP:
                    </span>
                    <span className="text-slate-400 text-[10px] text-right">
                      {device.firmwareVersion} <br />
                      <span className="text-slate-500">{device.ipAddress}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Simulation triggers: Connect/Disconnect device manually to let the user test Alerts system */}
              <div className="mt-5 pt-3 border-t border-cyan-905/20 flex gap-2">
                <button
                  onClick={() => onToggleDeviceStatus(device.id)}
                  className={`w-full py-2 px-3 rounded-xl font-mono text-[10px] font-bold uppercase tracking-wider transition-all border flex items-center justify-center gap-1.5 ${
                    isOnline 
                      ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border-red-500/20' 
                      : 'bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border-cyan-500/20'
                  }`}
                >
                  {isOnline ? (
                    <>
                      <AlertCircle className="w-3.5 h-3.5" />
                      Simulate Node Disconnect
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Connect Node Gateway
                    </>
                  )}
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
