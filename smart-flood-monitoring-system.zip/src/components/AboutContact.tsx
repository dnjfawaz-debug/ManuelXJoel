import React from 'react';
import { Cpu, Server, Globe, Smartphone, HelpCircle, Mail, MapPin, ExternalLink, ShieldCheck, Zap } from 'lucide-react';

export default function AboutContact() {
  return (
    <div className="space-y-6">
      
      {/* Hero Header */}
      <div className="bg-[#0A1120] border border-cyan-900/30 p-6 rounded-2xl space-y-1 shadow-lg shadow-cyan-950/10">
        <h2 className="text-2xl font-display font-bold text-white tracking-tight">System Architecture & Contact</h2>
        <p className="text-slate-400 text-sm">Understanding the physical IoT pipeline and development logs.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Columns: Interactive Pipeline Architecture diagram */}
        <div className="lg:col-span-2 bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/10 space-y-6">
          <div>
            <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block font-bold">System blueprint</span>
            <h3 className="text-lg font-display font-bold text-white mt-1">Under the Hood: Arduino & ESP32 Drainage Loops</h3>
            <p className="text-slate-400 text-xs leading-relaxed mt-1">
              Review how physical sensors map to cloud gateways. Water levels fluctuate dynamically and calculate real-time forecasts.
            </p>
          </div>

          {/* Interactive CSS Schema diagram representation */}
          <div className="p-4 bg-slate-950/60 border border-cyan-900/20 rounded-xl relative overflow-hidden">
            
            {/* Diagram grid nodes */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10 items-stretch font-mono text-center">
              
              {/* NODE 1: PHYSICAL ARDUINO SENSORS */}
              <div className="bg-[#0A1120] border border-cyan-900/20 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto mb-3 text-cyan-400 font-bold text-xs">01</div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">01. Drainage Sensors</h4>
                  <p className="text-[9px] text-slate-500 leading-normal mt-1.5">
                    Ultrasonic Depth HC-SR04, Conductive rain array, and YF-S201 Water flow sensors gather physical logs.
                  </p>
                </div>
                <div className="mt-4 pt-2.5 border-t border-cyan-900/20 text-[9px] text-slate-400">
                  ⚡ 5V Analog Signals
                </div>
              </div>

              {/* NODE 2: GATEWAY ESP32 MICROCONTROLLER */}
              <div className="bg-[#0A1120] border border-cyan-900/20 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto mb-3 text-cyan-400 font-bold text-xs">02</div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">02. ESP32 NodeMCU</h4>
                  <p className="text-[9px] text-slate-500 leading-normal mt-1.5">
                    Parses analog sensor arrays and formats payloads. Encrypts and transmits telemetries via Local Wi-Fi router.
                  </p>
                </div>
                <div className="mt-4 pt-2.5 border-t border-cyan-900/20 text-[9px] text-cyan-400 font-bold">
                  📶 Wi-Fi SSL Protocol
                </div>
              </div>

              {/* NODE 3: FIREBASE REALTIME CLOUD */}
              <div className="bg-[#0A1120] border border-cyan-900/20 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto mb-3 text-cyan-400 font-bold text-xs">03</div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">03. Firebase Cloud</h4>
                  <p className="text-[9px] text-slate-500 leading-normal mt-1.5">
                    Realtime Database registers JSON streams. Stores values instantly and opens active WebSockets to browsers.
                  </p>
                </div>
                <div className="mt-4 pt-2.5 border-t border-cyan-900/20 text-[9px] text-amber-400 font-bold">
                  🔥 RTDB WebSocket
                </div>
              </div>

              {/* NODE 4: CORE REACT DASHBOARD */}
              <div className="bg-[#0A1120] border border-cyan-900/20 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto mb-3 text-cyan-400 font-bold text-xs">04</div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">04. React Website</h4>
                  <p className="text-[9px] text-slate-500 leading-normal mt-1.5">
                    Listens and updates charts in real-time. Pulls OpenWeather forecasts to calculate municipal flood risks.
                  </p>
                </div>
                <div className="mt-4 pt-2.5 border-t border-cyan-900/20 text-[9px] text-emerald-400 font-bold">
                  💻 Client View Render
                </div>
              </div>

            </div>

            {/* Glowing connecting line in back (simulated) */}
            <div className="absolute top-[68px] left-[15%] right-[15%] h-0.5 bg-gradient-to-r from-cyan-500/20 via-blue-500/40 to-cyan-500/20 hidden md:block z-0"></div>
          </div>

          {/* Project description list */}
          <div className="space-y-3.5 pt-2">
            <h4 className="text-sm font-display font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              Primary Watershed Operations
            </h4>
            
            <p className="text-slate-300 text-xs leading-relaxed">
              Ojo and surrounding Lagos coastal systems are highly susceptible to major flash flood events due to sudden tropical downpours and low-lying coastal sand bars. Traditional drainage networks lack active telemetry, requiring manual inspections during heavy storms. 
            </p>
            <p className="text-slate-300 text-xs leading-relaxed">
              Our <strong>Smart Drainage Monitoring array</strong> introduces automatic telemetry nodes. Combining depth measurement (ultrasonic waves reflecting off runoff water surface), velocity (impeller flow sensors inside subterranean culverts), and live rainfall detection, we produce an automated, real-time assessment model that saves lives and prevents municipal property damage.
            </p>
          </div>

        </div>

        {/* Right Panel: Developer Contacts */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/10 flex flex-col justify-between space-y-6">
          
          <div className="space-y-4">
            <div>
              <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block font-bold">Operational Contact</span>
              <h3 className="text-lg font-display font-bold text-white tracking-tight mt-1">Smart City Control Hub</h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1">
                Have questions or need technical support regarding ESP32 firmware flashes? Reach our engineering team.
              </p>
            </div>

            <div className="space-y-3.5 font-mono text-xs">
              
              {/* Location */}
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-500 uppercase block text-[9px] font-bold">Headquarters</span>
                  <p className="text-slate-200 text-xs mt-0.5 font-sans leading-normal">Ojo Central Secretariat Road,<br />Lagos State, Nigeria</p>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-3 border-t border-cyan-900/20 pt-3">
                <Mail className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-500 uppercase block text-[9px] font-bold">Support Desk</span>
                  <a href="mailto:dnjfawaz@gmail.com" className="text-cyan-400 hover:underline text-xs mt-0.5">dnjfawaz@gmail.com</a>
                </div>
              </div>

              {/* GitHub */}
              <div className="flex items-start gap-3 border-t border-cyan-900/20 pt-3">
                <Globe className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-500 uppercase block text-[9px] font-bold">Source Code Hub</span>
                  <span className="text-slate-400 text-xs mt-0.5 flex items-center gap-1">
                    github.com/ojo-smart-drainage
                    <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>

            </div>
          </div>

          {/* Core system metrics check */}
          <div className="p-4 bg-slate-950/80 border border-cyan-900/25 rounded-xl flex items-center gap-3 font-mono">
            <Zap className="w-5 h-5 text-yellow-400 animate-pulse shrink-0" />
            <div>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest block font-bold">System Latency</span>
              <span className="text-xs text-slate-200 font-bold block mt-0.5">&lt; 340ms average dispatch</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
