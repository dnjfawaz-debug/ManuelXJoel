import React, { useState } from 'react';
import { Alert } from '../types';
import { ShieldAlert, BellRing, Check, CheckSquare, Trash, Bell, AlertTriangle, ShieldCheck, Thermometer } from 'lucide-react';

interface AlertsLogProps {
  alerts: Alert[];
  onAcknowledgeAlert: (id: string) => void;
  onClearAllAlerts: () => void;
  waterWarningThreshold: number;
  waterCriticalThreshold: number;
  setWaterWarningThreshold: (v: number) => void;
  setWaterCriticalThreshold: (v: number) => void;
}

export default function AlertsLog({
  alerts,
  onAcknowledgeAlert,
  onClearAllAlerts,
  waterWarningThreshold,
  waterCriticalThreshold,
  setWaterWarningThreshold,
  setWaterCriticalThreshold
}: AlertsLogProps) {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>(
    typeof window !== 'undefined' ? Notification.permission : 'default'
  );

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setPermissionStatus(permission);
      if (permission === 'granted') {
        new Notification('Flood Alerts Enabled', {
          body: 'You will receive desktop warnings when water limits reach critical bounds.',
          icon: '/favicon.ico'
        });
      }
    }
  };

  const getAlertStyle = (type: 'info' | 'warning' | 'critical') => {
    switch (type) {
      case 'critical':
        return {
          border: 'border-red-500/30',
          bg: 'bg-red-950/20',
          text: 'text-red-400',
          icon: ShieldAlert,
          shadow: 'shadow-red-950/20'
        };
      case 'warning':
        return {
          border: 'border-amber-500/30',
          bg: 'bg-amber-950/20',
          text: 'text-amber-400',
          icon: AlertTriangle,
          shadow: 'shadow-amber-950/20'
        };
      default:
        return {
          border: 'border-cyan-500/20',
          bg: 'bg-cyan-950/20',
          text: 'text-cyan-400',
          icon: Bell,
          shadow: 'shadow-cyan-950/20'
        };
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Upper Grid: Permissions and Custom threshold control */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Browser Notification request Panel */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 flex flex-col justify-between">
          <div>
            <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block font-bold">System Dispatch</span>
            <h3 className="text-lg font-display font-bold text-white mt-1">Browser Notifications</h3>
            <p className="text-slate-400 text-xs leading-relaxed mt-2">
              Enable real-time push dispatches directly to your computer screen, even when the dashboard tab is in the background.
            </p>
          </div>

          <div className="mt-5 space-y-3">
            <div className="flex items-center gap-2 font-mono text-[11px]">
              <span className="text-slate-500 font-bold">Status:</span>
              <span className={`font-bold ${
                permissionStatus === 'granted' ? 'text-cyan-400' : permissionStatus === 'denied' ? 'text-red-400' : 'text-slate-400'
              }`}>
                {permissionStatus.toUpperCase()}
              </span>
            </div>

            <button
              onClick={requestNotificationPermission}
              disabled={permissionStatus === 'granted'}
              className="w-full bg-cyan-500/10 border border-cyan-400/30 hover:bg-cyan-500/20 disabled:opacity-50 text-cyan-400 font-mono font-bold py-2.5 px-4 rounded-xl transition-all text-xs flex items-center justify-center gap-2"
            >
              <BellRing className="w-4 h-4" />
              {permissionStatus === 'granted' ? 'Notifications Active' : 'Grant Permissions'}
            </button>
          </div>
        </div>

        {/* Custom threshold configurations - Water Levels */}
        <div className="lg:col-span-2 bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 space-y-4">
          <div>
            <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block font-bold">Security parameters</span>
            <h3 className="text-lg font-display font-bold text-white mt-1">Custom Flood Risk Thresholds</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Dynamically calibrate risk engine water levels. Adjusting sliders instantly updates risk color indices and alerts!
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            
            {/* Warning Level limit */}
            <div className="space-y-2">
              <div className="flex justify-between font-mono text-xs">
                <span className="text-amber-400 font-bold">Warning Level limit:</span>
                <span className="text-white font-bold">{waterWarningThreshold}%</span>
              </div>
              <input 
                type="range" 
                min="40" 
                max="85"
                value={waterWarningThreshold}
                onChange={(e) => setWaterWarningThreshold(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded-lg appearance-none cursor-pointer border border-cyan-900/20"
              />
              <span className="text-[10px] font-mono text-slate-500 block">Standard triggers: 60% - 80% capacity</span>
            </div>

            {/* Critical Level limit */}
            <div className="space-y-2">
              <div className="flex justify-between font-mono text-xs">
                <span className="text-red-400 font-bold">Critical Level limit:</span>
                <span className="text-white font-bold">{waterCriticalThreshold}%</span>
              </div>
              <input 
                type="range" 
                min="70" 
                max="98"
                value={waterCriticalThreshold}
                onChange={(e) => setWaterCriticalThreshold(parseInt(e.target.value))}
                className="w-full accent-red-500 bg-slate-950 h-1.5 rounded-lg appearance-none cursor-pointer border border-cyan-900/20"
              />
              <span className="text-[10px] font-mono text-slate-500 block">Standard triggers: 85% - 95% capacity</span>
            </div>

          </div>
        </div>

      </div>

      {/* Main Alerts Log Panel */}
      <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15">
        <div className="flex justify-between items-center mb-6 border-b border-cyan-900/20 pb-4">
          <div className="space-y-1">
            <h3 className="text-lg font-display font-bold text-white">System Alert Registers</h3>
            <p className="text-slate-500 text-xs font-mono">Telemetry dispatch logs containing warning registers and reports.</p>
          </div>

          <button
            onClick={onClearAllAlerts}
            disabled={alerts.length === 0}
            className="px-3.5 py-1.5 bg-red-950/10 hover:bg-red-950/20 border border-red-900/30 text-red-400 hover:text-red-300 transition text-[11px] font-mono font-bold rounded-lg flex items-center gap-1.5 disabled:opacity-30"
          >
            <Trash className="w-3.5 h-3.5" />
            Wipe Logs
          </button>
        </div>

        {alerts.length === 0 ? (
          <div className="py-12 text-center text-slate-500 flex flex-col items-center justify-center space-y-2">
            <div className="p-3 bg-cyan-500/5 rounded-full border border-cyan-500/10 text-cyan-400 mb-2 animate-pulse">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <p className="font-display font-bold text-white text-sm">System Operations Clear</p>
            <p className="text-xs max-w-sm font-sans text-slate-400 mt-1">No active alerts, warnings, or hardware failures logged on current gateway threads.</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1 custom-scrollbar">
            {alerts.map((alert) => {
              const style = getAlertStyle(alert.type);
              const AlertIcon = style.icon;

              return (
                <div
                  key={alert.id}
                  className={`border ${style.border} ${style.bg} ${style.shadow} p-4 rounded-xl flex items-start justify-between gap-4 transition-all duration-300 relative ${
                    alert.acknowledged ? 'opacity-60' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 bg-slate-950 border border-cyan-900/20 rounded-xl ${style.text} shrink-0 mt-0.5`}>
                      <AlertIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-100 font-sans">{alert.message}</p>
                      <div className="flex items-center gap-3 mt-1.5 font-mono text-[10px] text-slate-500">
                        <span>{alert.timestamp}</span>
                        <span>•</span>
                        <span className="uppercase text-cyan-500/80 font-bold">{alert.category.replace('_', ' ')}</span>
                        {alert.acknowledged && (
                          <>
                            <span>•</span>
                            <span className="text-emerald-400 font-bold uppercase">Acknowledged</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {!alert.acknowledged && (
                    <button
                      onClick={() => onAcknowledgeAlert(alert.id)}
                      className="px-2.5 py-1.5 bg-cyan-950/30 hover:bg-cyan-950/50 border border-cyan-500/30 text-cyan-400 hover:text-cyan-300 transition-colors text-[10px] font-mono font-bold rounded-lg shrink-0 flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Acknowledge
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
