import React, { useState } from 'react';
import { mockReportEvents, ReportEvent } from '../utils/simulation';
import { FileText, Download, Calendar, Search, Filter, Printer, Loader2, CheckCircle } from 'lucide-react';

export default function ReportsSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadSuccessId, setDownloadSuccessId] = useState<string | null>(null);

  const handleDownloadPDF = (id: string) => {
    setDownloadingId(id);
    setDownloadSuccessId(null);
    // Simulate a high-fidelity PDF compile and download process
    setTimeout(() => {
      setDownloadingId(null);
      setDownloadSuccessId(id);
      
      // Trigger native browser printing as a backup or open PDF representation
      const report = mockReportEvents.find(r => r.id === id);
      if (report) {
        // Simple printable simulation
        const printWindow = window.open('', '_blank');
        if (printWindow) {
          printWindow.document.write(`
            <html>
              <head>
                <title>Smart Flood System - Report ${report.id}</title>
                <style>
                  body { font-family: monospace; padding: 40px; color: #1e293b; background: white; }
                  .header { border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 30px; }
                  .title { font-size: 24px; font-weight: bold; }
                  .subtitle { color: #64748b; font-size: 12px; margin-top: 5px; }
                  .meta { display: grid; grid-template-cols: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
                  .meta-item { border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; }
                  .label { font-size: 10px; color: #94a3b8; text-transform: uppercase; }
                  .val { font-size: 14px; font-weight: bold; margin-top: 4px; }
                  .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                  .table th, .table td { border: 1px solid #cbd5e1; padding: 12px; text-align: left; }
                  .table th { background: #f1f5f9; font-size: 11px; text-transform: uppercase; }
                  .footer { border-top: 1px solid #e2e8f0; margin-top: 50px; padding-top: 20px; font-size: 10px; color: #94a3b8; text-align: center; }
                </style>
              </head>
              <body>
                <div class="header">
                  <div class="title">SMART FLOOD SYSTEM LOG REPORT</div>
                  <div class="subtitle">Ojo Municipal Drainage Interceptor System &bull; Generated: ${new Date().toLocaleString()}</div>
                </div>
                <div class="meta">
                  <div class="meta-item">
                    <div class="label">Report Identifier</div>
                    <div class="val">${report.id}</div>
                  </div>
                  <div class="meta-item">
                    <div class="label">Logging Date</div>
                    <div class="val">${report.date}</div>
                  </div>
                </div>
                <table class="table">
                  <thead>
                    <tr>
                      <th>Station Location</th>
                      <th>Peak Level reached</th>
                      <th>Total Precipitation</th>
                      <th>Max Flow velocity</th>
                      <th>Risk Rating</th>
                      <th>System status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>${report.location}</td>
                      <td>${report.peakWaterLevel}%</td>
                      <td>${report.totalRainfall}</td>
                      <td>${report.maxFlowRate} L/min</td>
                      <td><strong>${report.riskRating} Risk</strong></td>
                      <td>${report.status}</td>
                    </tr>
                  </tbody>
                </table>
                <div class="footer">
                  This is a certified digital report compiled from ESP32 live node telemetry logs. Saved on Cloud/Local Database.
                </div>
                <script>window.print();</script>
              </body>
            </html>
          `);
          printWindow.document.close();
        }
      }

      setTimeout(() => setDownloadSuccessId(null), 3000);
    }, 1500);
  };

  const filteredEvents = mockReportEvents.filter((ev) => {
    const matchesSearch = ev.location.toLowerCase().includes(searchTerm.toLowerCase()) || ev.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = dateFilter ? ev.date === dateFilter : true;
    return matchesSearch && matchesDate;
  });

  return (
    <div className="space-y-6">
      
      {/* Search and Filters panel */}
      <div className="bg-[#0A1120] border border-cyan-900/30 p-6 rounded-2xl shadow-lg shadow-cyan-950/10 space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1">
            <h2 className="text-2xl font-display font-bold text-white tracking-tight">Municipal Reporting Suite</h2>
            <p className="text-slate-400 text-sm">Download and filter structured logs from historical flood events.</p>
          </div>
        </div>

        {/* Filters grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          {/* Search by station/id */}
          <div className="relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-500">
              <Search className="w-4 h-4 text-cyan-400/80" />
            </div>
            <input
              type="text"
              placeholder="Search by ID or Station location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950/80 border border-cyan-900/30 focus:border-cyan-500 rounded-lg pl-10 pr-4 py-2.5 text-xs text-slate-100 font-mono focus:outline-none transition-all"
            />
          </div>

          {/* Filter by date */}
          <div className="relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-500">
              <Calendar className="w-4 h-4 text-cyan-400/80" />
            </div>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full bg-slate-950/80 border border-cyan-900/30 focus:border-cyan-500 rounded-lg pl-10 pr-4 py-2.5 text-xs text-slate-100 font-mono focus:outline-none transition-all"
            />
          </div>

          {/* Reset button */}
          <button
            onClick={() => {
              setSearchTerm('');
              setDateFilter('');
            }}
            className="px-4 py-2.5 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 font-mono text-xs font-bold rounded-lg transition-all border border-cyan-900/20"
          >
            Clear Search Filters
          </button>
        </div>
      </div>

      {/* Reports Listing Table */}
      <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl overflow-hidden shadow-xl shadow-cyan-950/15">
        <div className="p-6 border-b border-cyan-900/20">
          <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            Historical Flood Events Logs
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-cyan-900/20 bg-slate-950/60 font-mono text-[10px] text-slate-400 uppercase tracking-widest font-bold">
                <th className="p-4 pl-6">Report ID</th>
                <th className="p-4">Incident Date</th>
                <th className="p-4">Location Outlet</th>
                <th className="p-4">Peak Level reached</th>
                <th className="p-4">Total Rainfall</th>
                <th className="p-4">Risk Rating</th>
                <th className="p-4">System status</th>
                <th className="p-4 pr-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cyan-900/10 font-mono text-xs text-slate-300">
              {filteredEvents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 font-bold">
                    No incident reports match current search parameters.
                  </td>
                </tr>
              ) : (
                filteredEvents.map((report) => (
                  <tr key={report.id} className="hover:bg-cyan-950/10 transition-colors">
                    <td className="p-4 pl-6 font-bold text-white">{report.id}</td>
                    <td className="p-4 text-slate-400">{report.date}</td>
                    <td className="p-4 text-white font-sans">{report.location}</td>
                    <td className="p-4 text-cyan-400 font-bold">{report.peakWaterLevel}%</td>
                    <td className="p-4 text-blue-400">{report.totalRainfall}</td>
                    <td className="p-4">
                      <span className={`inline-block py-0.5 px-2 rounded font-bold text-[10px] ${
                        report.riskRating === 'Critical' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                        report.riskRating === 'High' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                      }`}>
                        {report.riskRating}
                      </span>
                    </td>
                    <td className="p-4 text-slate-400">{report.status}</td>
                    <td className="p-4 pr-6 text-right">
                      <button
                        onClick={() => handleDownloadPDF(report.id)}
                        disabled={downloadingId === report.id}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 border border-cyan-500/25 rounded-lg font-bold text-[10px] transition-all disabled:opacity-50"
                      >
                        {downloadingId === report.id ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Compiling...
                          </>
                        ) : downloadSuccessId === report.id ? (
                          <>
                            <CheckCircle className="w-3 h-3 text-emerald-400" />
                            Printed!
                          </>
                        ) : (
                          <>
                            <Printer className="w-3 h-3" />
                            Export PDF
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
