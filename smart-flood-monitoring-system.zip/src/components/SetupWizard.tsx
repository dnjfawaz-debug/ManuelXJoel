import React, { useState } from 'react';
import { FirebaseConfig, SystemConfig } from '../types';
import { testWeatherApi } from '../services/weatherService';
import { testFirebaseConnection } from '../services/firebaseService';
import { Cpu, Cloud, MapPin, CheckCircle, AlertTriangle, Play, HelpCircle } from 'lucide-react';

interface SetupWizardProps {
  onComplete: (config: SystemConfig) => void;
  onLaunchDemo: () => void;
}

export default function SetupWizard({ onComplete, onLaunchDemo }: SetupWizardProps) {
  const [step, setStep] = useState(1);
  const [openWeatherKey, setOpenWeatherKey] = useState('');
  const [isValidatingWeather, setIsValidatingWeather] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);
  const [weatherSuccess, setWeatherSuccess] = useState(false);

  // Firebase Inputs
  const [firebaseConfig, setFirebaseConfig] = useState<FirebaseConfig>({
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: ''
  });
  const [isValidatingFirebase, setIsValidatingFirebase] = useState(false);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);
  const [firebaseSuccess, setFirebaseSuccess] = useState(false);

  // Monitoring Location Pre-filled
  const defaultLocation = {
    city: 'Ojo',
    state: 'Lagos',
    country: 'Nigeria',
    latitude: 6.4628,
    longitude: 3.1970
  };

  const handleValidateWeather = async () => {
    if (!openWeatherKey.trim()) {
      setWeatherError('Please enter an API Key.');
      return;
    }
    setIsValidatingWeather(true);
    setWeatherError(null);
    setWeatherSuccess(false);

    const result = await testWeatherApi(openWeatherKey.trim());
    setIsValidatingWeather(false);
    if (result.success) {
      setWeatherSuccess(true);
      setTimeout(() => setStep(2), 1200);
    } else {
      setWeatherError(result.error || 'Validation failed. Please verify your key.');
    }
  };

  const handleValidateFirebase = async () => {
    if (!firebaseConfig.apiKey || !firebaseConfig.databaseURL) {
      setFirebaseError('API Key and Database URL are required.');
      return;
    }
    setIsValidatingFirebase(true);
    setFirebaseError(null);
    setFirebaseSuccess(false);

    const result = await testFirebaseConnection(firebaseConfig);
    setIsValidatingFirebase(false);
    if (result.success) {
      setFirebaseSuccess(true);
      setTimeout(() => setStep(3), 1200);
    } else {
      setFirebaseError(result.error || 'Could not connect. Verify configuration.');
    }
  };

  const handleFinishSetup = () => {
    const finalConfig: SystemConfig = {
      openWeatherApiKey: openWeatherKey,
      firebaseConfig: firebaseConfig.apiKey ? firebaseConfig : null,
      location: defaultLocation,
      useSimulation: !firebaseConfig.apiKey,
      isConfigured: true
    };
    onComplete(finalConfig);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col items-center justify-center relative p-4 overflow-hidden select-none">
      {/* Immersive Cyber Rain Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#080e1b_1px,transparent_1px),linear-gradient(to_bottom,#080e1b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-50"></div>
      
      {/* Decorative Cyan Radial Glows */}
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-blue-500/5 blur-3xl"></div>

      <div className="w-full max-w-2xl bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-8 shadow-2xl relative z-10 overflow-hidden shadow-cyan-950/20">
        
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-cyan-900/20 pb-5 mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-xl shadow-lg shadow-cyan-500/20">
              <Cpu className="w-6 h-6 text-slate-900 stroke-[2.5]" />
            </div>
            <div>
              <h1 className="font-display font-bold text-xl tracking-tight text-white">SMART FLOOD SYSTEM</h1>
              <p className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest font-bold">Initialization Protocol</p>
            </div>
          </div>
          <button 
            onClick={onLaunchDemo}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 hover:text-cyan-300 font-mono text-xs font-bold rounded-xl transition duration-200 border border-cyan-500/20"
          >
            <Play className="w-4 h-4 fill-cyan-400 text-cyan-400" />
            Launch Demo Mode
          </button>
        </div>

        {/* Setup Progress Indicators */}
        <div className="flex items-center justify-between mb-8 gap-2">
          {[
            { num: 1, label: 'OpenWeather', icon: Cloud },
            { num: 2, label: 'Firebase IoT', icon: Cpu },
            { num: 3, label: 'Location Target', icon: MapPin },
            { num: 4, label: 'Finalize', icon: CheckCircle }
          ].map((item) => (
            <div key={item.num} className="flex-1 flex flex-col items-center relative">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                step === item.num 
                  ? 'bg-cyan-500 text-slate-950 ring-4 ring-cyan-500/20 font-bold scale-110' 
                  : step > item.num 
                    ? 'bg-slate-950 text-cyan-400 border border-cyan-500/30' 
                    : 'bg-slate-950 text-slate-500 border border-cyan-900/15'
              }`}>
                <item.icon className="w-5 h-5" />
              </div>
              <span className={`text-[10px] font-mono mt-2 text-center tracking-tight font-bold hidden sm:inline ${
                step === item.num ? 'text-white' : 'text-slate-500'
              }`}>{item.label}</span>
              {item.num < 4 && (
                <div className={`hidden sm:block absolute top-5 left-[calc(50%+20px)] w-[calc(100%-40px)] h-[1px] ${
                  step > item.num ? 'bg-cyan-500/30' : 'bg-cyan-900/20'
                }`}></div>
              )}
            </div>
          ))}
        </div>

        {/* STEP 1: OPENWEATHER CONFIGURATION */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-display font-bold text-white mb-2 flex items-center gap-2">
                <Cloud className="w-5 h-5 text-cyan-400" />
                Step 1 – OpenWeather API Key
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                This key is required to fetch real-time weather conditions and forecast metrics for flood probability prediction.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-2 font-bold">API KEY</label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="Paste your 32-character OpenWeather API Key"
                    value={openWeatherKey}
                    onChange={(e) => setOpenWeatherKey(e.target.value)}
                    className="w-full bg-slate-950/80 border border-cyan-900/30 focus:border-cyan-500 rounded-lg px-4 py-3 text-sm text-slate-100 font-mono placeholder:text-slate-600 focus:outline-none transition duration-200"
                  />
                </div>
              </div>

              {weatherError && (
                <div className="flex items-start gap-2 p-3 bg-red-950/20 border border-red-500/30 text-red-400 text-xs rounded-xl">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                  <span>{weatherError}</span>
                </div>
              )}

              {weatherSuccess && (
                <div className="flex items-center gap-2 p-3 bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 text-xs rounded-xl">
                  <CheckCircle className="w-4 h-4 text-cyan-400" />
                  <span>API Key Verified Successfully! Access granted.</span>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 font-semibold py-3 px-4 rounded-xl transition duration-200 text-sm border border-cyan-900/10"
                >
                  Skip for Now (Demo Mode)
                </button>
                <button
                  onClick={handleValidateWeather}
                  disabled={isValidatingWeather}
                  className="flex-1 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold py-3 px-4 rounded-xl transition duration-200 text-sm shadow-lg shadow-cyan-500/10"
                >
                  {isValidatingWeather ? 'Verifying Key...' : 'Validate API Key'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: FIREBASE REALTIME DB CONFIGURATION */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-display font-bold text-white mb-2 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                Step 2 – Firebase Configuration
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                Paste your Firebase project credentials below to enable live WebSocket streams from physical ESP32 telemetry nodes directly to the dashboard.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[250px] overflow-y-auto pr-2 custom-scrollbar">
              {[
                { label: 'API Key', key: 'apiKey', placeholder: 'AIzaSy...' },
                { label: 'Auth Domain', key: 'authDomain', placeholder: 'project-id.firebaseapp.com' },
                { label: 'Database URL', key: 'databaseURL', placeholder: 'https://project-id-rtdb.firebaseio.com' },
                { label: 'Project ID', key: 'projectId', placeholder: 'project-id' },
                { label: 'Storage Bucket', key: 'storageBucket', placeholder: 'project-id.appspot.com' },
                { label: 'Messaging Sender ID', key: 'messagingSenderId', placeholder: '1234567890' },
                { label: 'App ID', key: 'appId', placeholder: '1:1234:web:abcd' },
                { label: 'Measurement ID (Optional)', key: 'measurementId', placeholder: 'G-XXXXXX' }
              ].map((input) => (
                <div key={input.key}>
                  <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-widest mb-1 font-bold">{input.label}</label>
                  <input
                    type="text"
                    placeholder={input.placeholder}
                    value={firebaseConfig[input.key as keyof FirebaseConfig] || ''}
                    onChange={(e) => setFirebaseConfig({ ...firebaseConfig, [input.key]: e.target.value })}
                    className="w-full bg-slate-950/80 border border-cyan-900/15 focus:border-cyan-500 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono placeholder:text-slate-700 focus:outline-none transition-all"
                  />
                </div>
              ))}
            </div>

            {firebaseError && (
              <div className="flex items-start gap-2 p-3 bg-red-950/20 border border-red-500/30 text-red-400 text-xs rounded-xl">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                <span>{firebaseError}</span>
              </div>
            )}

            {firebaseSuccess && (
              <div className="flex items-center gap-2 p-3 bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 text-xs rounded-xl">
                <CheckCircle className="w-4 h-4 text-cyan-400" />
                <span>Connection Established with Firebase DB!</span>
              </div>
            )}

            <div className="flex gap-3 pt-3 border-t border-cyan-900/20">
              <button
                onClick={() => setStep(3)}
                className="flex-1 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 font-semibold py-2.5 px-4 rounded-xl transition text-sm border border-cyan-900/10"
              >
                Skip (Run Simulated App)
              </button>
              <button
                onClick={handleValidateFirebase}
                disabled={isValidatingFirebase}
                className="flex-1 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold py-2.5 px-4 rounded-xl transition text-sm shadow-lg shadow-cyan-500/10"
              >
                {isValidatingFirebase ? 'Testing Connection...' : 'Test Firebase Connection'}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: DEFAULT LOCATION TARGET */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-display font-bold text-white mb-2 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-cyan-400" />
                Step 3 – Default Monitoring Station Location
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                The drainage networks and sensor grid arrays are set up at Ojo, Lagos State, Nigeria. Standard geographical boundaries are preloaded.
              </p>
            </div>

            <div className="bg-slate-950/80 border border-cyan-900/20 rounded-xl p-5 space-y-4 font-mono text-sm">
              <div className="flex justify-between items-center border-b border-cyan-900/10 pb-2">
                <span className="text-slate-500">Target Area:</span>
                <span className="text-white font-semibold">Ojo, Lagos, Nigeria</span>
              </div>
              <div className="flex justify-between items-center border-b border-cyan-900/10 pb-2">
                <span className="text-slate-500">Latitude:</span>
                <span className="text-cyan-400">6.4628° N</span>
              </div>
              <div className="flex justify-between items-center border-b border-cyan-900/10 pb-2">
                <span className="text-slate-500">Longitude:</span>
                <span className="text-cyan-400">3.1970° E</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Primary Watershed:</span>
                <span className="text-slate-300">Badagry Lagoon Basin</span>
              </div>
            </div>

            <div className="p-3 bg-cyan-500/5 border border-cyan-500/10 rounded-xl text-xs text-cyan-400 flex items-start gap-2 leading-relaxed">
              <HelpCircle className="w-4 h-4 shrink-0 mt-0.5 text-cyan-400" />
              <span>You can adjust custom locations later within the Settings section of your dashboard. Default targets remain Ojo for initial predictions.</span>
            </div>

            <button
              onClick={() => setStep(4)}
              className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition duration-200 text-sm shadow-lg shadow-cyan-500/10"
            >
              Confirm Coordinates & Proceed
            </button>
          </div>
        )}

        {/* STEP 4: FINALIZE */}
        {step === 4 && (
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 bg-cyan-500/10 border border-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
              <CheckCircle className="w-8 h-8 text-cyan-400" />
            </div>

            <div>
              <h2 className="text-xl font-display font-bold text-white mb-2">System Initialized Successfully</h2>
              <p className="text-slate-400 text-sm max-w-md mx-auto leading-relaxed">
                Your Smart Flood Monitoring config is compiled. All services are ready to register, analyze, and dispatch real-time alerts.
              </p>
            </div>

            <div className="bg-slate-950/60 border border-cyan-900/20 rounded-xl p-4 text-left space-y-2 max-w-md mx-auto text-xs font-mono text-slate-400">
              <div className="flex justify-between">
                <span>Weather API Integration:</span>
                <span className={openWeatherKey ? 'text-emerald-400' : 'text-amber-400'}>
                  {openWeatherKey ? 'LIVE CONNECTIONS' : 'SIMULATION DRIVEN'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Firebase Realtime Database:</span>
                <span className={firebaseConfig.apiKey ? 'text-emerald-400' : 'text-amber-400'}>
                  {firebaseConfig.apiKey ? 'CONNECTED' : 'SIMULATION ACTIVE'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Location Target:</span>
                <span className="text-white">Ojo, Lagos, NG</span>
              </div>
            </div>

            <button
              onClick={handleFinishSetup}
              className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition duration-200 text-sm shadow-lg shadow-cyan-500/20 uppercase tracking-widest font-mono font-bold"
            >
              Launch Core Operations
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
