import React from 'react';
import { WeatherData, MonitoringLocation } from '../types';
import { Sun, CloudRain, Cloud, Wind, Compass, Sunrise, Sunset, Droplets, Gauge, AlertCircle, RefreshCw } from 'lucide-react';

interface WeatherOverviewProps {
  weather: WeatherData | null;
  location: MonitoringLocation;
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
  isSimulated: boolean;
}

export default function WeatherOverview({
  weather,
  location,
  isLoading,
  error,
  onRefresh,
  isSimulated
}: WeatherOverviewProps) {
  
  // Helper to map OpenWeather icon strings to SVG icons or styled images
  const getWeatherIconUrl = (iconId: string) => {
    return `https://openweathermap.org/img/wn/${iconId}@4x.png`;
  };

  return (
    <div className="space-y-6">
      
      {/* Upper Status Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0A1120] p-6 border border-cyan-900/30 rounded-2xl shadow-lg shadow-cyan-950/10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-display font-bold text-white tracking-tight">Meteorology Forecasting</h2>
            {isSimulated && (
              <span className="py-0.5 px-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono text-[9px] font-bold uppercase rounded">
                Simulated Data Active
              </span>
            )}
          </div>
          <p className="text-slate-400 text-sm">
            Live atmospheric coordinates synchronized with OpenWeather telemetry at <span className="text-white font-semibold">{location.city}, {location.state}, {location.country}</span>.
          </p>
        </div>

        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center gap-2 px-4 py-2.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-xl font-mono text-xs font-bold transition-all disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          Force Sync Weather
        </button>
      </div>

      {/* Error banner */}
      {error && (
        <div className="p-4 bg-red-950/20 border border-red-500/30 text-red-400 text-xs rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-red-500" />
          <div className="space-y-1">
            <span className="font-display font-bold block">OpenWeather Connection Offline</span>
            <p className="leading-relaxed text-slate-400">
              {error}. Verify your OpenWeather API Key in the Settings panel. Standard pre-compiled simulation arrays have loaded to maintain system assessment uptime.
            </p>
          </div>
        </div>
      )}

      {weather ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Panel: Current Weather in Ojo */}
          <div className="lg:col-span-2 bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[380px] shadow-cyan-950/15">
            {/* Background Solar Flare effect */}
            <div className="absolute -right-24 -top-24 w-72 h-72 rounded-full bg-yellow-500/5 blur-3xl"></div>

            <div className="flex justify-between items-start border-b border-cyan-900/20 pb-4 mb-4">
              <div>
                <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block font-bold">Current Conditions</span>
                <h3 className="text-2xl font-display font-bold text-white tracking-tight mt-1">{location.city} Station</h3>
                <span className="font-mono text-xs text-cyan-400 mt-1 block uppercase font-bold">{weather.description}</span>
              </div>
              
              {/* Weather icon visual */}
              <img 
                src={getWeatherIconUrl(weather.icon)} 
                alt={weather.description} 
                className="w-20 h-20 -my-4 shrink-0 filter drop-shadow-[0_0_15px_rgba(250,204,21,0.2)]"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Main Temperature Displays */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
              <div className="flex items-baseline gap-2">
                <span className="text-7xl font-display font-bold text-white tracking-tighter">{weather.temp}</span>
                <span className="text-3xl font-mono text-yellow-400 font-bold">°C</span>
              </div>

              {/* Multi-sensory layout parameters */}
              <div className="grid grid-cols-2 gap-4 border-l border-cyan-900/20 pl-6">
                <div>
                  <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block font-bold">Rainfall</span>
                  <p className="text-white text-sm font-bold mt-0.5">{weather.rainfall} mm</p>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block font-bold">Cloudiness</span>
                  <p className="text-white text-sm font-bold mt-0.5">{weather.clouds}%</p>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block font-bold">Sunrise</span>
                  <p className="text-cyan-400 font-bold text-xs mt-0.5 flex items-center gap-1 font-mono">
                    <Sunrise className="w-3.5 h-3.5" />
                    {weather.sunrise}
                  </p>
                </div>
                <div>
                  <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block font-bold">Sunset</span>
                  <p className="text-yellow-400 font-bold text-xs mt-0.5 flex items-center gap-1 font-mono">
                    <Sunset className="w-3.5 h-3.5" />
                    {weather.sunset}
                  </p>
                </div>
              </div>
            </div>

            {/* Dials & Gauges Block */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-cyan-900/20 pt-6 mt-6">
              
              {/* Humidity dial */}
              <div className="bg-slate-950/60 border border-cyan-900/20 p-4 rounded-xl flex items-center gap-3">
                <div className="p-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 shrink-0">
                  <Droplets className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Humidity</span>
                  <p className="text-sm font-bold text-slate-200 mt-0.5 font-mono">{weather.humidity}%</p>
                </div>
              </div>

              {/* Barometric Pressure dial */}
              <div className="bg-slate-950/60 border border-cyan-900/20 p-4 rounded-xl flex items-center gap-3">
                <div className="p-2 bg-cyan-500/10 border border-cyan-500/20 rounded-lg text-cyan-400 shrink-0">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Pressure</span>
                  <p className="text-sm font-bold text-slate-200 mt-0.5 font-mono">{weather.pressure} hPa</p>
                </div>
              </div>

              {/* Wind Dial */}
              <div className="bg-slate-950/60 border border-cyan-900/20 p-4 rounded-xl flex items-center gap-3">
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 shrink-0">
                  <Wind className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Wind Velocity</span>
                  <p className="text-xs font-bold text-slate-200 mt-0.5 truncate font-mono">{weather.windSpeed} km/h</p>
                </div>
              </div>

            </div>
          </div>

          {/* Right Panel: 5-Day Forecast Column */}
          <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 flex flex-col justify-between">
            <div>
              <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block font-bold">Future Outlook</span>
              <h3 className="text-lg font-display font-bold text-white tracking-tight mt-1 mb-4">5-Day Meteorological Forecast</h3>
            </div>

            <div className="space-y-3">
              {weather.forecast.map((fc, idx) => (
                <div 
                  key={idx} 
                  className="bg-slate-950/40 hover:bg-slate-950/80 border border-cyan-900/10 hover:border-cyan-900/30 p-3 rounded-xl flex items-center justify-between gap-4 transition-all duration-200"
                >
                  <div className="flex items-center gap-2.5">
                    <img 
                      src={getWeatherIconUrl(fc.icon)} 
                      alt={fc.description} 
                      className="w-10 h-10 shrink-0 filter drop-shadow-[0_0_8px_rgba(6,182,212,0.15)]"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-100 block">{fc.time}</span>
                      <span className="font-mono text-[9px] text-slate-500 block uppercase truncate max-w-[120px]">{fc.description}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 font-mono">
                    <span className="text-sm font-bold text-yellow-400">{fc.temp}°C</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3.5 border-t border-cyan-900/20 text-[10px] font-mono text-slate-500 leading-normal text-center font-bold">
              Forecast telemetry feeds updated automatically every 10 minutes.
            </div>
          </div>

        </div>
      ) : (
        <div className="py-24 text-center">
          <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto mb-4" />
          <p className="font-mono text-xs text-slate-400 font-bold">Compiling meteorology metrics...</p>
        </div>
      )}

    </div>
  );
}
