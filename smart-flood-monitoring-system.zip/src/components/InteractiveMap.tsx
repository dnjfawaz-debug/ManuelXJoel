import React, { useState } from 'react';
import { SensorData, ESP32Device } from '../types';
import { MapPin, ShieldAlert, Navigation, Layers, ZoomIn, ZoomOut, Database } from 'lucide-react';

interface InteractiveMapProps {
  sensors: SensorData;
  devices: ESP32Device[];
}

interface MapNode {
  id: string;
  name: string;
  lat: number;
  lng: number;
  x: number; // Percent position on SVG map
  y: number;
  type: 'active' | 'future' | 'outlet';
  area: string;
  riskRating: 'Low' | 'Moderate' | 'High' | 'Critical';
}

export default function InteractiveMap({ sensors, devices }: InteractiveMapProps) {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-ojo');
  const [mapLayer, setMapLayer] = useState<'vector' | 'satellite'>('vector');

  // Hardcoded node positions representing Ojo drainage arrays
  const nodes: MapNode[] = [
    {
      id: 'node-ojo',
      name: 'Ojo Main Inlet Station (A1)',
      lat: 6.4628,
      lng: 3.1970,
      x: 35,
      y: 42,
      type: 'active',
      area: 'Badagry Expressway Drainage Hub',
      riskRating: sensors.waterLevel >= 90 ? 'Critical' : sensors.waterLevel >= 80 ? 'High' : sensors.waterLevel >= 50 ? 'Moderate' : 'Low'
    },
    {
      id: 'node-lasu',
      name: 'LASU Campus Drainage Node (B3)',
      lat: 6.4655,
      lng: 3.2012,
      x: 65,
      y: 30,
      type: 'active',
      area: 'LASU Gate Interceptor Canal',
      riskRating: 'Moderate'
    },
    {
      id: 'node-alaba',
      name: 'Alaba Int\'l Market Culvert (C2)',
      lat: 6.4601,
      lng: 3.1934,
      x: 20,
      y: 68,
      type: 'active',
      area: 'Alaba Electronics Segment Trench',
      riskRating: 'High'
    },
    {
      id: 'node-future1',
      name: 'Iyana-Iba Interceptor Grid (Proposed)',
      lat: 6.4712,
      lng: 3.2050,
      x: 82,
      y: 18,
      type: 'future',
      area: 'Planned - Iyana-Iba Roundabout Sector',
      riskRating: 'Low'
    },
    {
      id: 'node-outlet',
      name: 'Ojo Lagoon Discharge Canal (D1)',
      lat: 6.4520,
      lng: 3.1905,
      x: 48,
      y: 85,
      type: 'outlet',
      area: 'Primary Discharge Mouth to Badagry Lagoon',
      riskRating: 'Low'
    }
  ];

  const selectedNode = nodes.find(n => n.id === selectedNodeId) || nodes[0];

  // Helper to resolve node colors
  const getRiskColor = (rating: 'Low' | 'Moderate' | 'High' | 'Critical') => {
    switch (rating) {
      case 'Critical': return { bg: 'bg-red-500', pulse: 'bg-red-500', text: 'text-red-400', border: 'border-red-500/50' };
      case 'High': return { bg: 'bg-amber-500', pulse: 'bg-amber-500', text: 'text-amber-400', border: 'border-amber-500/50' };
      case 'Moderate': return { bg: 'bg-yellow-500', pulse: 'bg-yellow-500', text: 'text-yellow-400', border: 'border-yellow-500/30' };
      default: return { bg: 'bg-cyan-500', pulse: 'bg-cyan-400', text: 'text-cyan-400', border: 'border-cyan-500/30' };
    }
  };

  const getOverlayLabel = (type: string) => {
    if (type === 'future') return 'PROPOSED GATE';
    if (type === 'outlet') return 'LAGU DISCHARGE';
    return 'TELEMETRY NODE';
  };

  return (
    <div className="space-y-6">
      
      {/* Header and Controller */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#0A1120] p-6 border border-cyan-900/30 rounded-2xl shadow-lg shadow-cyan-950/10">
        <div className="space-y-1">
          <h2 className="text-2xl font-display font-bold text-white tracking-tight">Interactive GIS Map</h2>
          <p className="text-slate-400 text-sm">Geospatial telemetry layers across Ojo Municipal drainage channels.</p>
        </div>

        {/* Layer selector */}
        <div className="flex gap-2 p-1 bg-slate-950 rounded-xl border border-cyan-900/20">
          <button 
            onClick={() => setMapLayer('vector')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[10px] font-bold uppercase tracking-wider transition-all duration-200 ${
              mapLayer === 'vector' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Digital Grid
          </button>
          <button 
            onClick={() => setMapLayer('satellite')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[10px] font-bold uppercase tracking-wider transition-all duration-200 ${
              mapLayer === 'satellite' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            Satellite Mesh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side: Interactive Map Grid SVG Layout */}
        <div className="lg:col-span-2 bg-[#0A1120] border border-cyan-900/30 rounded-2xl overflow-hidden shadow-2xl relative min-h-[460px] flex items-center justify-center p-4">
          
          {/* Subtle matrix-style scanlines overlay */}
          <div className="absolute inset-0 bg-scanlines pointer-events-none opacity-[0.03]"></div>

          {/* SATELLITE LAYER BACKGROUND */}
          {mapLayer === 'satellite' ? (
            <div className="absolute inset-0 z-0 overflow-hidden opacity-50 bg-[#020617]">
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950 z-10"></div>
              {/* Fake satellite stylized image/pattern */}
              <div className="w-full h-full bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-20"></div>
              {/* Lagoon SVG block */}
              <svg className="absolute inset-0 w-full h-full fill-blue-950/40">
                <path d="M 0,380 Q 250,340 450,420 T 900,390 L 900,600 L 0,600 Z" />
              </svg>
            </div>
          ) : null}

          {/* MAIN VECTOR MAP SVG */}
          <svg viewBox="0 0 500 400" className="w-full h-full max-w-lg relative z-10 transition duration-500">
            {/* Roads & Infrastructure Channels Grid lines (Cyan & Purple Slate) */}
            <g stroke="#1e293b" strokeWidth="2" fill="none" opacity="0.6">
              {/* Expressway (Badagry Express) */}
              <path d="M 0,150 Q 250,160 500,140" stroke="#334155" strokeWidth="4" />
              <path d="M 0,150 Q 250,160 500,140" stroke="#0ea5e9" strokeWidth="0.8" strokeDasharray="5,5" />
              
              {/* Secondary avenues */}
              <path d="M 100,0 Q 120,200 80,400" />
              <path d="M 350,0 Q 300,180 380,400" />
              <path d="M 220,150 L 250,400" />
              
              {/* Drainage waterways networks */}
              <path d="M 350,160 Q 340,250 250,300 T 240,400" stroke="#1e3a5f" strokeWidth="5" />
              <path d="M 100,150 Q 120,250 180,330 T 240,400" stroke="#1e3a5f" strokeWidth="4" />
            </g>

            {/* Badagry Lagoon Boundary (SVG visual path) */}
            <path 
              d="M -10,340 Q 180,300 240,350 T 510,320 L 510,410 L -10,410 Z" 
              fill={mapLayer === 'satellite' ? 'rgba(30, 41, 59, 0.4)' : 'rgba(6, 182, 212, 0.05)'} 
              stroke="#0891b2" 
              strokeWidth="1.5"
              strokeOpacity="0.4"
            />
            {/* Water flow indicator arrows on Lagoon */}
            <path d="M 120,355 L 140,352" stroke="#0891b2" strokeWidth="1" strokeDasharray="2,2" />
            <path d="M 380,350 L 400,352" stroke="#0891b2" strokeWidth="1" strokeDasharray="2,2" />

            {/* Risk / Flood-Prone Areas overlays (soft color zones) */}
            <g opacity="0.3">
              {/* Low elevation flood sector (Alaba Segment) */}
              <circle cx="100" cy="270" r="45" fill="rgba(245, 158, 11, 0.2)" stroke="#f59e0b" strokeWidth="1" strokeDasharray="4,4" />
              {/* Low elevation sector (LASU exit grid) */}
              <circle cx="360" cy="220" r="35" fill="rgba(234, 179, 8, 0.15)" stroke="#eab308" strokeWidth="1" strokeDasharray="4,4" />
            </g>

            {/* Interactive Node markers mapping */}
            {nodes.map((node) => {
              const rColor = getRiskColor(node.riskRating);
              const isSelected = node.id === selectedNodeId;
              
              return (
                <g 
                  key={node.id} 
                  className="cursor-pointer"
                  onClick={() => setSelectedNodeId(node.id)}
                >
                  {/* Outer ripple ring (only for active, selected nodes) */}
                  {node.type === 'active' && (
                    <circle 
                      cx={`${node.x}%`} 
                      cy={`${node.y}%`} 
                      r={isSelected ? 16 : 8} 
                      className={`${rColor.pulse} fill-none opacity-30 animate-ping`} 
                      style={{ transformOrigin: `${node.x}% ${node.y}%` }}
                    />
                  )}

                  {/* Core Pin Anchor */}
                  <circle 
                    cx={`${node.x}%`} 
                    cy={`${node.y}%`} 
                    r={isSelected ? 7 : 5} 
                    className={`${node.type === 'future' ? 'bg-slate-600 fill-slate-700 stroke-slate-500' : `${rColor.bg} fill-current stroke-slate-950`} stroke-2 shadow-xl transition-all duration-300`} 
                  />

                  {/* Icon pins visual alignment */}
                  <g transform={`translate(${node.x * 5 - 12}, ${node.y * 4 - 32})`}>
                    {isSelected && (
                      <path 
                        d="M12 0 C5.37 0 0 5.37 0 12 C0 21 12 32 12 32 C12 32 24 21 24 12 C24 5.37 18.63 0 12 0 Z" 
                        fill={node.type === 'future' ? '#475569' : node.riskRating === 'Critical' ? '#ef4444' : '#06b6d4'} 
                        className="opacity-20 animate-pulse" 
                      />
                    )}
                  </g>
                </g>
              );
            })}
          </svg>

          {/* Compass Rose */}
          <div className="absolute bottom-5 right-5 p-2.5 bg-slate-950/90 border border-cyan-900/20 rounded-xl flex flex-col items-center gap-1">
            <span className="font-mono text-[9px] text-slate-500">N</span>
            <div className="w-5 h-5 border border-cyan-500/30 rounded-full flex items-center justify-center">
              <div className="w-0.5 h-3.5 bg-cyan-400 rotate-[22deg]"></div>
            </div>
          </div>

          {/* Legend indicator overlay */}
          <div className="absolute top-5 left-5 p-3.5 bg-slate-950/95 border border-cyan-900/30 rounded-xl space-y-1.5 backdrop-blur-md">
            <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest block mb-1 font-bold">GIS Grid Indicators</span>
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
              <span>Active Node (Normal)</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>High / Alert State</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
              <span>Critical Risk Area</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span>
              <span>Proposed Stations</span>
            </div>
          </div>
        </div>

        {/* Right Side: Detail Sidebar Overlay */}
        <div className="bg-[#0A1120] border border-cyan-900/30 rounded-2xl p-6 shadow-xl shadow-cyan-950/15 flex flex-col justify-between space-y-6">
          <div>
            <div className="flex justify-between items-start border-b border-cyan-900/20 pb-4 mb-4">
              <div>
                <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block font-bold">
                  {getOverlayLabel(selectedNode.type)}
                </span>
                <h3 className="text-xl font-display font-bold text-white tracking-tight mt-1">{selectedNode.name}</h3>
              </div>
              <MapPin className="w-5 h-5 text-cyan-400 shrink-0 mt-1" />
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Geographic Sector</span>
                <p className="text-slate-200 text-xs font-semibold font-sans leading-normal mt-1">{selectedNode.area}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 border-y border-cyan-900/20 py-3">
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Latitude</span>
                  <p className="text-white font-mono text-xs mt-0.5">{selectedNode.lat.toFixed(4)}° N</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Longitude</span>
                  <p className="text-white font-mono text-xs mt-0.5">{selectedNode.lng.toFixed(4)}° E</p>
                </div>
              </div>

              <div className="space-y-3 pt-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Status & Analytics</span>
                
                {selectedNode.type === 'active' ? (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-400">Flood Risk Factor:</span>
                      <span className={`font-bold ${getRiskColor(selectedNode.riskRating).text}`}>{selectedNode.riskRating}</span>
                    </div>
                    {selectedNode.id === 'node-ojo' ? (
                      <>
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-400">Live Water Level:</span>
                          <span className="text-white font-bold">{sensors.waterLevel}%</span>
                        </div>
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-400">Live Flow Velocity:</span>
                          <span className="text-emerald-400 font-bold">{sensors.flowRate} L/min</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-400">Water Level:</span>
                          <span className="text-white">45% (Simulated)</span>
                        </div>
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-400">Flow Velocity:</span>
                          <span className="text-emerald-400">32.8 L/min</span>
                        </div>
                      </>
                    )}
                  </div>
                ) : selectedNode.type === 'future' ? (
                  <div className="p-3 bg-slate-950/80 border border-cyan-900/20 rounded-xl text-xs text-slate-400 font-mono leading-relaxed flex items-start gap-2">
                    <Database className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                    <span>Station currently in development. Funding secured under Lagos Smart Drainage Masterplan Phase II (2026).</span>
                  </div>
                ) : (
                  <div className="p-3 bg-emerald-950/20 border border-emerald-900/20 rounded-xl text-xs text-emerald-400 font-mono leading-relaxed">
                    <span>Primary discharge gates are currently fully open. Backwash locks active. Flow stable at 145.4 L/min peak capacity.</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="p-3 bg-cyan-950/30 border border-cyan-900/30 rounded-xl text-[11px] text-cyan-400/80 font-mono flex items-start gap-2 leading-relaxed">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-cyan-400" />
            <span>GIS coordinates synchronized with Google Maps API and municipal GIS layers. Satellite coordinates verified.</span>
          </div>

        </div>

      </div>

    </div>
  );
}
