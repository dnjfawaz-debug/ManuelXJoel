import { SensorData, ESP32Device, Alert, WeatherData, HistoricalRecord } from '../types';

// Helper to generate a realistic formatted date
export function getFormattedTime(date: Date = new Date()): string {
  return date.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

export function getFormattedDate(date: Date = new Date()): string {
  return date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
}

// Initial Sensor Data for the main dashboard
export const initialSensorData: SensorData = {
  waterLevel: 42,
  rainDetected: false,
  rainIntensity: 0,
  flowRate: 34.5,
  temperature: 28.4,
  humidity: 82,
  wifiSignal: -68,
  deviceStatus: 'online',
  lastUpdated: getFormattedTime()
};

// Initial Connected ESP32 Devices list
export const initialDevices: ESP32Device[] = [
  {
    id: 'esp-01',
    name: 'Ojo Main Inlet Station (A1)',
    status: 'online',
    wifiSignal: -65,
    lastCommunication: 'Just now',
    battery: 94,
    ipAddress: '192.168.1.150',
    firmwareVersion: 'v2.1.4-build08',
    uptime: '12d 4h 12m'
  },
  {
    id: 'esp-02',
    name: 'LASU Campus Drainage Node (B3)',
    status: 'online',
    wifiSignal: -72,
    lastCommunication: 'Just now',
    battery: 88,
    ipAddress: '192.168.1.151',
    firmwareVersion: 'v2.1.4-build08',
    uptime: '5d 21h 3m'
  },
  {
    id: 'esp-03',
    name: 'Alaba Int\'l Market Culvert (C2)',
    status: 'online',
    wifiSignal: -78,
    lastCommunication: '2 mins ago',
    battery: 12, // Low battery warning trigger
    ipAddress: '192.168.1.152',
    firmwareVersion: 'v2.0.9-build02',
    uptime: '45d 16h 55m'
  }
];

// Initial Alerts log
export const initialAlerts: Alert[] = [
  {
    id: 'alt-1',
    type: 'info',
    message: 'System Monitoring Started. Ojo Drainage Grid online.',
    timestamp: '2026-07-20 08:00:00',
    acknowledged: true,
    category: 'system'
  },
  {
    id: 'alt-2',
    type: 'warning',
    message: 'Low Battery Alert: Alaba Culvert Node is at 12% capacity.',
    timestamp: '2026-07-20 09:12:44',
    acknowledged: false,
    category: 'system'
  },
  {
    id: 'alt-3',
    type: 'info',
    message: 'Water flow surge detected: Ojo Main Inlet registered 75.2 L/min.',
    timestamp: '2026-07-20 11:45:00',
    acknowledged: false,
    category: 'flow_rate'
  }
];

// Default Ojo Weather Data
export const defaultWeatherData: WeatherData = {
  temp: 29.0,
  humidity: 85,
  pressure: 1012,
  windSpeed: 16.2, // km/h
  windDirection: 210, // SSW
  clouds: 78,
  description: 'Moderate rain and scattered thunderstorms',
  icon: '10d',
  rainfall: 12.5, // mm
  sunrise: '06:24 AM',
  sunset: '06:58 PM',
  forecast: [
    { time: 'Today', temp: 29.0, icon: '10d', description: 'Moderate Rain' },
    { time: 'Tomorrow', temp: 28.5, icon: '09d', description: 'Showers' },
    { time: 'Wed 22', temp: 27.0, icon: '11d', description: 'Thunderstorm' },
    { time: 'Thu 23', temp: 29.5, icon: '04d', description: 'Partly Cloudy' },
    { time: 'Fri 24', temp: 30.2, icon: '02d', description: 'Mostly Sunny' }
  ]
};

// Generate Historical Chart Data based on time filters
export function generateHistoricalData(filter: 'today' | '7days' | '30days'): HistoricalRecord[] {
  const records: HistoricalRecord[] = [];
  const now = new Date();

  if (filter === 'today') {
    // Hourly logs for today (24 hours)
    for (let i = 23; i >= 0; i--) {
      const logTime = new Date(now.getTime() - i * 60 * 60 * 1000);
      const hourStr = logTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      // Simulate some fluctuations based on a wave
      const cycle = Math.sin((24 - i) / 4);
      const waterLevel = Math.round(40 + cycle * 15 + Math.random() * 5);
      const rainfall = Math.max(0, parseFloat((cycle * 4 + Math.random() * 2).toFixed(1)));
      const flowRate = Math.round(25 + cycle * 12 + Math.random() * 4);
      const temperature = parseFloat((26 + Math.cos((24 - i) / 4) * 3 + Math.random() * 0.5).toFixed(1));
      const humidity = Math.round(80 - Math.cos((24 - i) / 4) * 10 + Math.random() * 3);

      records.push({
        timestamp: hourStr,
        waterLevel,
        rainfall,
        flowRate,
        temperature,
        humidity
      });
    }
  } else if (filter === '7days') {
    // Daily logs for the last 7 days
    for (let i = 6; i >= 0; i--) {
      const logDate = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = logDate.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

      const wave = Math.sin((7 - i) / 1.5);
      const waterLevel = Math.round(45 + wave * 20 + Math.random() * 8);
      const rainfall = Math.max(0, parseFloat((wave * 8 + Math.random() * 5).toFixed(1)));
      const flowRate = Math.round(30 + wave * 15 + Math.random() * 6);
      const temperature = parseFloat((28 + Math.random() * 1.5).toFixed(1));
      const humidity = Math.round(82 + Math.random() * 6);

      records.push({
        timestamp: dateStr,
        waterLevel,
        rainfall,
        flowRate,
        temperature,
        humidity
      });
    }
  } else {
    // Daily logs for the last 30 days
    for (let i = 29; i >= 0; i--) {
      const logDate = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = `${logDate.getMonth() + 1}/${logDate.getDate()}`;

      const wave = Math.sin((30 - i) / 5);
      const waterLevel = Math.round(35 + wave * 25 + Math.random() * 10);
      const rainfall = Math.max(0, parseFloat((wave * 12 + Math.random() * 6).toFixed(1)));
      const flowRate = Math.round(20 + wave * 20 + Math.random() * 8);
      const temperature = parseFloat((27.5 + Math.random() * 2).toFixed(1));
      const humidity = Math.round(80 + Math.random() * 10);

      records.push({
        timestamp: dateStr,
        waterLevel,
        rainfall,
        flowRate,
        temperature,
        humidity
      });
    }
  }

  return records;
}

// Generate reports placeholder data
export interface ReportEvent {
  id: string;
  date: string;
  location: string;
  peakWaterLevel: number;
  totalRainfall: string;
  maxFlowRate: number;
  riskRating: 'Low' | 'Moderate' | 'High' | 'Critical';
  status: 'Resolved' | 'Active' | 'Under Observation';
}

export const mockReportEvents: ReportEvent[] = [
  {
    id: 'REP-2026-001',
    date: '2026-07-18',
    location: 'LASU Campus Outlet B3',
    peakWaterLevel: 84,
    totalRainfall: '14.2 mm',
    maxFlowRate: 82.5,
    riskRating: 'High',
    status: 'Resolved'
  },
  {
    id: 'REP-2026-002',
    date: '2026-07-19',
    location: 'Alaba Int\'l Market Culvert C2',
    peakWaterLevel: 92,
    totalRainfall: '22.8 mm',
    maxFlowRate: 110.4,
    riskRating: 'Critical',
    status: 'Resolved'
  },
  {
    id: 'REP-2026-003',
    date: '2026-07-20',
    location: 'Ojo Main Inlet Station A1',
    peakWaterLevel: 55,
    totalRainfall: '4.5 mm',
    maxFlowRate: 48.0,
    riskRating: 'Moderate',
    status: 'Under Observation'
  }
];
