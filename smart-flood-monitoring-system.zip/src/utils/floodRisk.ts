import { FloodRiskLevel } from '../types';

export interface FloodRiskAssessment {
  level: FloodRiskLevel;
  description: string;
  recommendation: string;
  colorClass: string;
  bgClass: string;
  bannerClass: string;
  pulseClass: string;
}

export function calculateFloodRisk(
  waterLevel: number,
  rainIntensity: number,
  forecastRainProb: number = 0
): FloodRiskAssessment {
  // If water level is extremely high or combining heavy current rain + very high water level
  if (waterLevel >= 90 || (waterLevel >= 85 && (rainIntensity >= 80 || forecastRainProb >= 85))) {
    return {
      level: 'Critical',
      description: 'Critical Flood Warning! Water levels have breached safety margins and major overflowing is imminent or active.',
      recommendation: 'Evacuate low-lying areas immediately. Secure electrical hazards and activate municipal emergency protocols.',
      colorClass: 'text-red-500',
      bgClass: 'bg-red-500/10 border-red-500/30',
      bannerClass: 'bg-gradient-to-r from-red-600 to-red-800 text-white animate-pulse',
      pulseClass: 'bg-red-500 animate-ping',
    };
  }

  // High Risk: Water level > 80% and Rain probability/intensity > 60%
  if (
    waterLevel >= 80 || 
    (waterLevel >= 70 && (rainIntensity >= 60 || forecastRainProb >= 60))
  ) {
    return {
      level: 'High',
      description: 'High Flood Risk! Rising water levels coupled with rainfall indicate high probability of flash flooding.',
      recommendation: 'Stay alert. Monitor drainage paths and prepare essential supplies. Avoid driving through flooded streets.',
      colorClass: 'text-amber-500',
      bgClass: 'bg-amber-500/10 border-amber-500/30',
      bannerClass: 'bg-gradient-to-r from-amber-500 to-amber-600 text-white',
      pulseClass: 'bg-amber-500 animate-pulse',
    };
  }

  // Moderate Risk: Water level between 50-80%
  if (waterLevel >= 50 || rainIntensity >= 50) {
    return {
      level: 'Moderate',
      description: 'Moderate System Activity. Minor water accumulation detected in drainages; drainage pumps operating as standard.',
      recommendation: 'Normal watch is recommended. Clear localized trash from drainage inlets to maintain optimal water flow.',
      colorClass: 'text-yellow-500',
      bgClass: 'bg-yellow-500/10 border-yellow-500/30',
      bannerClass: 'bg-gradient-to-r from-yellow-500 to-amber-500 text-slate-900',
      pulseClass: 'bg-yellow-500',
    };
  }

  // Low Risk: Standard conditions
  return {
    level: 'Low',
    description: 'Normal Operations. Drainage pathways are clear and water levels are well within safe thresholds.',
    recommendation: 'No action required. Regular monitoring is active.',
    colorClass: 'text-cyan-400',
    bgClass: 'bg-cyan-500/10 border-cyan-500/30',
    bannerClass: 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white',
    pulseClass: 'bg-cyan-400',
  };
}
